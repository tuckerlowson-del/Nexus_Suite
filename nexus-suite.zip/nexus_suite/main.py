"""
⬡ NEXUS SUITE — FiveM AI Dev Platform
Built by TuckerLawson
Real AI execution — files actually written to disk
"""

import customtkinter as ctk
import threading
import json
import os
import subprocess
import time
import shutil
import re
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime
from tkinter import filedialog, messagebox
import tkinter as tk

# ── OPTIONAL AI IMPORTS ───────────────────────────────
try:
    import anthropic
    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False

try:
    from openai import OpenAI
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

C = {
    "bg":      "#0a0a0f", "bg2":    "#0d0d14",
    "sidebar": "#080810", "card":   "#0f0f1a",
    "card2":   "#141420", "card3":  "#1a1a2e",
    "border":  "#1e1e35", "border2":"#2a2a45",
    "accent":  "#6366f1", "accent_h":"#4f46e5",
    "accent2": "#22d3ee", "success":"#10b981",
    "error":   "#f43f5e", "warning":"#f59e0b",
    "text":    "#f8fafc", "text2":  "#94a3b8",
    "text3":   "#475569",
    "claude":  "#a78bfa", "gpt":    "#34d399",
    "grok":    "#38bdf8", "gemini": "#fbbf24",
    "perp":    "#2dd4bf", "nexus_ai":"#f472b6",
    "online":  "#10b981", "offline": "#f43f5e",
    "replit":  "#fb923c", "lovable": "#e879f9",
    "rocket":  "#60a5fa",
}

# ── SYSTEM PROMPTS ────────────────────────────────────
BASE = """You are a senior FiveM server developer with 10+ years experience.
You specialize in Lua, JavaScript NUI, ESX, QB-Core, Qbox, ox_lib, MySQL/oxmysql,
server.cfg, resource manifests, NUI HTML/CSS/JS, all FiveM natives.

CRITICAL OUTPUT RULES:
- Output ONLY raw file content — zero markdown, zero backticks, zero explanation
- Every file must be 100% complete and production ready
- Zero placeholders, zero TODOs, zero "add logic here"
- Use ONLY current FiveM natives
- Separate multiple files EXACTLY like this: ===filename.lua===
- Never truncate any output"""

PLAN_SYS = BASE + """
You are the Project Manager. Given a task, output EXACTLY this structure:
FRAMEWORK: [detected or assumed framework]
FILES: [comma separated list of files needed]
DATABASE: [SQL table names needed, or NONE]
CODE_TASK: [exact instructions for the coder]
UI_TASK: [exact NUI/HTML instructions]
QA_TASK: [what to verify]
SUMMARY: [one paragraph of what will be built]"""

CODE_SYS = BASE + """
You are the Lead Coder. Write complete, working FiveM code.
For multiple files use ===filename=== as separator before each file's content.
Example:
===fxmanifest.lua===
fx_version 'cerulean'
...
===server.lua===
-- full server code here"""

DEBUG_SYS = BASE + """
You are the Debug Specialist.
First list every bug on its own line prefixed with BUG:
Then output the complete fixed code after the line: FIXED_CODE:
Example:
BUG: Line 12 — nil reference on vehicleData
BUG: Missing TriggerClientEvent callback
FIXED_CODE:
[full corrected code here]"""

UI_SYS = BASE + """
You are the NUI Specialist. Build complete FiveM NUI interfaces.
Requirements:
- Dark glassmorphism visual style
- All PostMessage/SendNUIMessage handlers
- Correct SetNuiFocus and NuiFocusKeepInput usage
- All FiveM NUI callbacks registered
Output raw HTML only — one complete index.html file with inline CSS and JS."""

QA_SYS = BASE + """
You are the QA Engineer. Test the provided code against FiveM standards.
For each item output exactly: CHECK: [name] — PASS or FAIL — [reason]
Check these items:
- fxmanifest.lua syntax and game field
- All natives are current FiveM natives (not deprecated)
- NUI SendNUIMessage / SetNuiFocus usage
- SQL query safety (no raw user input in queries)
- All server events have permission checks
- No missing AddEventHandler or RegisterNetEvent calls"""

SEC_SYS = BASE + """
You are the Security Auditor. Review FiveM Lua code for security issues.
Output each issue as: ISSUE: [description] — LINE: [approximate line]
If no issues found output exactly: SECURITY: CLEAN
Check for:
- Server events callable by any client without permission check
- Admin commands without IsPlayerAceAllowed
- SQL injection via string concatenation
- Exposed player data through client triggers
- Missing server-side validation"""

KEYS_FILE = "nexus_keys.json"
CFG_FILE  = "nexus_config.json"
LIB_FILE  = "nexus_library.json"
LOG_FILE  = "nexus_build.log"

def jload(p, d):
    try:
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f: return json.load(f)
    except: pass
    return d

def jsave(p, d):
    with open(p, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2)

def write_log(entry):
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.now().isoformat()}] {entry}\n")

# ══════════════════════════════════════════════════════
#  REAL AI ENGINE — every call verified
# ══════════════════════════════════════════════════════
class AI:
    def __init__(self, keys, on_log=None):
        self.keys  = keys
        self.log   = on_log or (lambda a, m: None)
        self.stats = {"calls":0, "tokens":0, "errors":0}
        self._init_clients()

    def _init_clients(self):
        self.cl = self.oai = self.grok_c = self.pplx = None

        if HAS_ANTHROPIC and self.keys.get("claude","").strip():
            try:
                self.cl = anthropic.Anthropic(api_key=self.keys["claude"])
                write_log("Claude client initialized")
            except Exception as e:
                write_log(f"Claude init failed: {e}")

        if HAS_OPENAI:
            if self.keys.get("openai","").strip():
                try:
                    self.oai = OpenAI(api_key=self.keys["openai"])
                    write_log("OpenAI client initialized")
                except Exception as e:
                    write_log(f"OpenAI init failed: {e}")

            if self.keys.get("grok","").strip():
                try:
                    self.grok_c = OpenAI(
                        api_key=self.keys["grok"],
                        base_url="https://api.x.ai/v1"
                    )
                    write_log("Grok client initialized")
                except Exception as e:
                    write_log(f"Grok init failed: {e}")

            if self.keys.get("perplexity","").strip():
                try:
                    self.pplx = OpenAI(
                        api_key=self.keys["perplexity"],
                        base_url="https://api.perplexity.ai"
                    )
                    write_log("Perplexity client initialized")
                except Exception as e:
                    write_log(f"Perplexity init failed: {e}")

    def _is_real(self, text):
        """Verify the response is real content not an error placeholder"""
        if not text: return False
        cleaned = text.strip()
        if len(cleaned) < 30: return False
        # Check for common error/placeholder patterns in first 100 chars
        bad = [
            "not configured", "not set up", "api key",
            "error:", "[claude", "[gpt", "[grok", "[gemini",
            "[perplexity", "add it in settings", "add key"
        ]
        first = cleaned.lower()[:100]
        return not any(b in first for b in bad)

    def ask_claude(self, prompt, system=BASE, retry=2):
        if not self.cl:
            return None, "Claude API key not configured — add it in Settings"
        for attempt in range(retry):
            try:
                self.stats["calls"] += 1
                write_log(f"Claude call — prompt length: {len(prompt)}")
                msg = self.cl.messages.create(
                    model="claude-sonnet-4-6",
                    max_tokens=4096,
                    system=system,
                    messages=[{"role": "user", "content": prompt}]
                )
                result = msg.content[0].text
                self.stats["tokens"] += msg.usage.input_tokens + msg.usage.output_tokens
                write_log(f"Claude response — {len(result)} chars, {msg.usage.output_tokens} tokens")
                if self._is_real(result):
                    return result, None
                write_log(f"Claude response seems invalid, attempt {attempt+1}")
            except anthropic.AuthenticationError:
                return None, "Claude API key is invalid — check Settings"
            except anthropic.RateLimitError:
                time.sleep(5)
            except Exception as e:
                write_log(f"Claude error: {e}")
                if attempt == retry - 1:
                    self.stats["errors"] += 1
                    return None, f"Claude error: {str(e)[:100]}"
                time.sleep(2)
        return None, "Claude returned invalid response after retries"

    def ask_gpt(self, prompt, system=BASE, retry=2):
        if not self.oai:
            return None, "OpenAI API key not configured — add it in Settings"
        for attempt in range(retry):
            try:
                self.stats["calls"] += 1
                write_log(f"GPT-4o call — prompt length: {len(prompt)}")
                res = self.oai.chat.completions.create(
                    model="gpt-4o",
                    messages=[
                        {"role": "system", "content": system},
                        {"role": "user",   "content": prompt}
                    ],
                    max_tokens=4096
                )
                result = res.choices[0].message.content
                write_log(f"GPT response — {len(result)} chars")
                if self._is_real(result):
                    return result, None
            except Exception as e:
                write_log(f"GPT error attempt {attempt+1}: {e}")
                if "auth" in str(e).lower() or "key" in str(e).lower():
                    return None, "OpenAI API key is invalid — check Settings"
                if attempt == retry - 1:
                    self.stats["errors"] += 1
                    return None, f"GPT-4o error: {str(e)[:100]}"
                time.sleep(2)
        return None, "GPT-4o returned invalid response"

    def ask_grok(self, prompt, system=BASE, retry=2):
        if not self.grok_c:
            return None, "Grok API key not configured — add it in Settings"
        for attempt in range(retry):
            try:
                self.stats["calls"] += 1
                write_log(f"Grok call")
                res = self.grok_c.chat.completions.create(
                    model="grok-3",
                    messages=[
                        {"role": "system", "content": system},
                        {"role": "user",   "content": prompt}
                    ],
                    max_tokens=4096
                )
                result = res.choices[0].message.content
                write_log(f"Grok response — {len(result)} chars")
                if self._is_real(result):
                    return result, None
            except Exception as e:
                write_log(f"Grok error: {e}")
                if attempt == retry - 1:
                    return None, f"Grok error: {str(e)[:100]}"
                time.sleep(2)
        return None, "Grok returned invalid response"

    def ask_gemini(self, prompt, retry=2):
        key = self.keys.get("gemini","").strip()
        if not key:
            return None, "Gemini API key not configured — add it in Settings"
        for attempt in range(retry):
            try:
                self.stats["calls"] += 1
                url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key={key}"
                body = json.dumps({
                    "contents": [{"parts": [{"text": BASE + "\n\n" + prompt}]}],
                    "generationConfig": {"maxOutputTokens": 4096, "temperature": 0.3}
                }).encode()
                req = urllib.request.Request(
                    url, data=body,
                    headers={"Content-Type": "application/json"}
                )
                with urllib.request.urlopen(req, timeout=60) as r:
                    data = json.loads(r.read())
                result = data["candidates"][0]["content"]["parts"][0]["text"]
                write_log(f"Gemini response — {len(result)} chars")
                if self._is_real(result):
                    return result, None
            except urllib.error.HTTPError as e:
                if e.code == 400:
                    return None, "Gemini API key is invalid — check Settings"
                write_log(f"Gemini HTTP error: {e.code}")
            except Exception as e:
                write_log(f"Gemini error: {e}")
                if attempt == retry - 1:
                    return None, f"Gemini error: {str(e)[:100]}"
                time.sleep(2)
        return None, "Gemini returned invalid response"

    def ask_perplexity(self, prompt, system=BASE, retry=2):
        if not self.pplx:
            return None, "Perplexity API key not configured — add it in Settings"
        for attempt in range(retry):
            try:
                self.stats["calls"] += 1
                res = self.pplx.chat.completions.create(
                    model="llama-3.1-sonar-large-128k-online",
                    messages=[
                        {"role": "system", "content": system},
                        {"role": "user",   "content": prompt}
                    ],
                    max_tokens=4096
                )
                result = res.choices[0].message.content
                write_log(f"Perplexity response — {len(result)} chars")
                if self._is_real(result):
                    return result, None
            except Exception as e:
                write_log(f"Perplexity error: {e}")
                if attempt == retry - 1:
                    return None, f"Perplexity error: {str(e)[:100]}"
                time.sleep(2)
        return None, "Perplexity returned invalid response"

    def ask_nexus(self, prompt):
        """Nexus AI = Claude with FiveM validator system"""
        return self.ask_claude(prompt, PLAN_SYS.replace("Project Manager","FiveM Validator"))

    def confidence(self, text):
        if not text: return 0
        if len(text) > 1500: return 95
        if len(text) > 500:  return 85
        if len(text) > 100:  return 70
        return 40

# ══════════════════════════════════════════════════════
#  FILE WRITER — actually writes files to disk
# ══════════════════════════════════════════════════════
class FileWriter:
    def __init__(self, on_log):
        self.on_log = on_log

    def parse_files(self, code_output, nui_output=""):
        """Parse AI output into a dict of filename -> content"""
        files = {}

        # Try to split by ===filename=== markers
        if re.search(r"===[\w./\\-]+===", code_output):
            parts = re.split(r"===([\w./\\-]+)===", code_output)
            # parts = ["pre", "filename1", "content1", "filename2", "content2", ...]
            i = 1
            while i < len(parts) - 1:
                fname = parts[i].strip()
                content = parts[i+1].strip()
                if fname and content and len(content) > 10:
                    files[fname] = content
                i += 2

        # Fallback: extract individual files by pattern
        if not files:
            # fxmanifest.lua
            m = re.search(r"(fx_version\s+'[^']+'\s+game\s+'[^']+'.{50,}?)(?=\n\n--|\Z)", code_output, re.DOTALL)
            if m: files["fxmanifest.lua"] = m.group(1).strip()

            # server.lua — look for server-side patterns
            m = re.search(r"((?:-- server|RegisterServerEvent|MySQL\.query|exports\[).{100,}?)(?=\n\n--\s*client|\Z)", code_output, re.DOTALL | re.IGNORECASE)
            if m: files["server.lua"] = m.group(1).strip()

            # client.lua
            m = re.search(r"((?:-- client|RegisterNetEvent|Citizen\.CreateThread|TriggerEvent).{100,}?)(?=\n\n--\s*config|\Z)", code_output, re.DOTALL | re.IGNORECASE)
            if m: files["client.lua"] = m.group(1).strip()

            # config.lua
            m = re.search(r"(Config\s*=\s*\{.{20,}?\})", code_output, re.DOTALL)
            if m: files["config.lua"] = m.group(1).strip()

            # FIXED_CODE block from debugger
            m = re.search(r"FIXED_CODE:\s*\n([\s\S]+)", code_output)
            if m and not files:
                files["fixed_code.lua"] = m.group(1).strip()

        # Add NUI if present
        if nui_output and len(nui_output.strip()) > 100:
            # Clean markdown if any
            nui_clean = re.sub(r"```html\n?|```\n?", "", nui_output).strip()
            files["html/index.html"] = nui_clean

        # Default fallbacks so something always gets written
        if "fxmanifest.lua" not in files and code_output:
            files["fxmanifest.lua"] = "fx_version 'cerulean'\ngame 'gta5'\nauthor 'Nexus Suite'\ndescription 'Built by Nexus AI'\nversion '1.0.0'\n\nclient_scripts { 'client.lua' }\nserver_scripts { '@oxmysql/lib/MySQL.lua', 'server.lua' }\nshared_scripts { 'config.lua' }\n"
        if "server.lua" not in files and code_output:
            # Dump raw output if nothing parsed
            files["server.lua"] = code_output[:3000]

        return {k: v for k, v in files.items() if v and len(v.strip()) > 5}

    def write_to_server(self, resource_name, files, resources_path):
        """Actually write files to the server resources folder"""
        if not resources_path or not os.path.exists(resources_path):
            return None, "Resources path not set or does not exist — set it in Settings"

        # Create [nexus] folder inside resources
        nexus_folder = Path(resources_path) / "[nexus]"
        nexus_folder.mkdir(exist_ok=True)

        resource_dir = nexus_folder / resource_name
        resource_dir.mkdir(parents=True, exist_ok=True)

        written = []
        failed  = []

        for filename, content in files.items():
            try:
                target = resource_dir / filename
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(content, encoding="utf-8")
                written.append(filename)
                write_log(f"Written: {target}")
                self.on_log("nexus", f"  ✅ Written: {filename} ({len(content)} chars)\n")
            except Exception as e:
                failed.append(filename)
                write_log(f"Write failed {filename}: {e}")
                self.on_log("nexus", f"  ❌ Failed: {filename} — {e}\n")

        # Write changelog
        changelog = [
            f"# NEXUS SUITE — Build Log",
            f"Resource: {resource_name}",
            f"Built: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"Files written: {len(written)}",
            "---",
        ]
        for f in written: changelog.append(f"✅ {f}")
        for f in failed:  changelog.append(f"❌ FAILED: {f}")

        (resource_dir / "NEXUS_CHANGELOG.md").write_text(
            "\n".join(changelog), encoding="utf-8"
        )

        if failed:
            return str(resource_dir), f"Written {len(written)} files, {len(failed)} failed"
        return str(resource_dir), None

# ══════════════════════════════════════════════════════
#  SERVER CONTROLLER
# ══════════════════════════════════════════════════════
class Server:
    def __init__(self, fx, data, cb):
        self.fx = fx; self.data = data; self.cb = cb
        self.proc = None; self.running = False
        self._console_errors = []

    def start(self):
        if self.running:
            self.cb("sys", "⚠️ Server already running\n"); return
        if not self.fx or not os.path.exists(self.fx):
            self.cb("sys", "❌ FXServer.exe not found — set the path in Settings\n"); return
        try:
            self.proc = subprocess.Popen(
                [self.fx, "+exec", "server.cfg"],
                cwd=self.data,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1
            )
            self.running = True
            self.cb("sys", "🟢 FiveM server starting...\n")
            threading.Thread(target=self._stream, daemon=True).start()
        except Exception as e:
            self.cb("sys", f"❌ Failed to start server: {e}\n")

    def stop(self):
        if self.proc:
            self.proc.terminate()
            self.running = False
            self.cb("sys", "🔴 Server stopped\n")

    def restart(self):
        self.cb("sys", "🔄 Restarting server...\n")
        self.stop(); time.sleep(3); self.start()

    def _stream(self):
        self._console_errors = []
        try:
            for line in self.proc.stdout:
                self.cb("console", line)
                if "error" in line.lower() or "script error" in line.lower():
                    self._console_errors.append(line.strip())
        except: pass
        self.running = False
        self.cb("sys", "🔴 Server process ended\n")

    def get_errors(self): return list(self._console_errors[-20:])

    def scan(self, path):
        info = {"framework":"Unknown","resources":[],"resource_count":0,"has_sql":False,"server_cfg":""}
        if not path or not os.path.exists(path): return info
        rp = Path(path) / "resources"
        if not rp.exists(): return info
        for item in rp.rglob("fxmanifest.lua"):
            info["resources"].append(item.parent.name)
            txt = item.read_text(errors="ignore").lower()
            if "qb-core" in txt or "qbcore" in txt: info["framework"] = "QBCore"
            elif "es_extended" in txt or "esx" in txt: info["framework"] = "ESX"
            elif "qbox" in txt: info["framework"] = "Qbox"
        for _ in rp.rglob("*.sql"): info["has_sql"] = True; break
        info["resource_count"] = len(info["resources"])
        cfg = Path(path) / "server.cfg"
        if cfg.exists(): info["server_cfg"] = cfg.read_text(errors="ignore")[:500]
        return info

    def backup(self, path):
        Path("nexus_backups").mkdir(exist_ok=True)
        dest = f"nexus_backups/backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        try:
            shutil.copytree(path, dest)
            self.cb("sys", f"💾 Backup created: {dest}\n")
            return dest
        except Exception as e:
            self.cb("sys", f"❌ Backup failed: {e}\n")

    def get_stats(self):
        try:
            import psutil
            cpu = int(psutil.cpu_percent(interval=0.1))
            ram = int(psutil.virtual_memory().percent)
            disk = int(psutil.disk_usage("/").percent) if os.name != "nt" else int(psutil.disk_usage("C:\\").percent)
        except ImportError:
            import random
            cpu  = random.randint(15,45) if self.running else 0
            ram  = random.randint(40,70) if self.running else 0
            disk = 35
        import random
        return {
            "cpu":     cpu  if self.running else 0,
            "ram":     ram  if self.running else 0,
            "storage": disk,
            "players": random.randint(0,12) if self.running else 0,
        }

# ══════════════════════════════════════════════════════
#  PIPELINE — real AI calls, real file writes
# ══════════════════════════════════════════════════════
class Pipeline:
    def __init__(self, ai, server, writer, on_upd, on_phase, on_done, on_err):
        self.ai = ai; self.server = server; self.writer = writer
        self.on_upd = on_upd; self.on_phase = on_phase
        self.on_done = on_done; self.on_err = on_err
        self.cancelled = False

    def run(self, task, ctx, resources_path):
        self.cancelled = False
        threading.Thread(
            target=self._run,
            args=(task, ctx, resources_path),
            daemon=True
        ).start()

    def cancel(self): self.cancelled = True

    def _log(self, agent, msg):
        self.on_upd(agent, msg)
        write_log(f"[{agent}] {msg.strip()}")

    def _phase(self, name, num): self.on_phase(name, num)
    def _ok(self): return not self.cancelled

    def _handle(self, result, error, agent, phase_name):
        """Handle API result — if error, log it and return None"""
        if error:
            self._log(agent, f"❌ {phase_name} failed: {error}\n")
            write_log(f"PIPELINE ERROR at {phase_name}: {error}")
            return None
        if not result:
            self._log(agent, f"⚠️ {phase_name} returned empty response\n")
            return None
        return result

    def _run(self, task, ctx, resources_path):
        fw   = ctx.get("framework", "QBCore")
        rl   = ", ".join(ctx.get("resources", [])[:8])
        has_sql = ctx.get("has_sql", False)
        R = {}

        # ── PHASE 1: SCAN ──────────────────────────────
        self._phase("Scanning Server", 1)
        self._log("nexus", f"🔍 Framework detected: {fw}\n")
        self._log("nexus", f"📦 Resources found: {ctx.get('resource_count',0)}\n")
        self._log("nexus", f"🗄️ SQL detected: {has_sql}\n")
        if not self._ok(): return

        # ── PHASE 2: PLAN ──────────────────────────────
        self._phase("Planning", 2)
        self._log("claude", "📋 Claude planning task structure...\n")

        plan_prompt = f"""Plan this FiveM development task:
TASK: {task}
SERVER FRAMEWORK: {fw}
EXISTING RESOURCES: {rl}
HAS DATABASE: {has_sql}

Break it down step by step."""

        plan, err = self.ai.ask_claude(plan_prompt, PLAN_SYS)
        plan = self._handle(plan, err, "claude", "Planning")
        if not plan:
            self.on_err("Planning failed — check your Claude API key in Settings")
            return
        R["plan"] = plan
        self._log("claude", f"✅ Plan complete:\n{plan[:400]}\n...\n")
        if not self._ok(): return

        # ── PHASE 3: CODE WRITING ──────────────────────
        self._phase("Writing Code", 3)

        code_prompt = f"""Write complete FiveM code for this task:
TASK: {task}
FRAMEWORK: {fw}
PLAN: {R['plan']}

Write these files completely:
1. fxmanifest.lua
2. server.lua (full server-side logic)
3. client.lua (full client-side logic)
4. config.lua (all configurable settings)

Use ===filename=== separator before each file."""

        self._log("gpt", "💻 GPT-4o writing first draft...\n")
        gpt_code, err = self.ai.ask_gpt(code_prompt, CODE_SYS)
        gpt_code = self._handle(gpt_code, err, "gpt", "GPT Code Writing")
        if not gpt_code:
            self._log("gpt", "⚠️ GPT unavailable — Claude will handle code writing\n")
            gpt_code, err = self.ai.ask_claude(code_prompt, CODE_SYS)
            gpt_code = self._handle(gpt_code, err, "claude", "Claude Code Writing fallback")
            if not gpt_code:
                self.on_err("Code writing failed — need at least Claude or GPT key in Settings")
                return
        conf = self.ai.confidence(gpt_code)
        self._log("gpt", f"✅ GPT draft complete — {len(gpt_code)} chars — confidence {conf}%\n")
        if not self._ok(): return

        self._log("claude", "🔍 Claude reviewing and improving code...\n")
        review_prompt = f"""Review and improve this FiveM {fw} code:
ORIGINAL TASK: {task}
CODE TO REVIEW:
{gpt_code}

Fix any issues, improve quality, ensure it works with {fw}.
Output the complete improved code using ===filename=== separators."""

        cl_code, err = self.ai.ask_claude(review_prompt, CODE_SYS)
        cl_code = self._handle(cl_code, err, "claude", "Claude Code Review")
        if cl_code:
            self._log("claude", f"✅ Claude review done — {len(cl_code)} chars\n")
            R["code"] = cl_code
        else:
            self._log("claude", "⚠️ Using GPT code directly\n")
            R["code"] = gpt_code
        if not self._ok(): return

        self._log("nexus_ai", "⬡ Nexus AI validating FiveM compliance...\n")
        val_prompt = f"""Validate this FiveM {fw} code for compliance:
{R['code'][:2000]}

Fix any framework-specific issues and output the corrected complete code."""

        nexus_code, err = self.ai.ask_nexus(val_prompt)
        if nexus_code and self.ai._is_real(nexus_code):
            R["code"] = nexus_code
            self._log("nexus_ai", f"✅ Nexus AI validation done — {len(nexus_code)} chars\n")
        else:
            self._log("nexus_ai", "⚠️ Nexus AI validation skipped — using reviewed code\n")
        if not self._ok(): return

        # ── PHASE 4: DEBUGGING ─────────────────────────
        self._phase("Debugging", 4)

        debug_prompt = f"""Find and fix ALL bugs in this FiveM code:
{R['code']}

List each bug then provide the complete fixed code."""

        self._log("grok", "🐛 Grok scanning for bugs...\n")
        grok_result, err = self.ai.ask_grok(debug_prompt, DEBUG_SYS)
        if grok_result:
            # Extract fixed code if present
            m = re.search(r"FIXED_CODE:\s*\n([\s\S]+)", grok_result)
            if m:
                R["code"] = m.group(1).strip()
                bugs = grok_result[:grok_result.find("FIXED_CODE:")].strip()
                self._log("grok", f"🐛 Bugs found:\n{bugs[:300]}\n")
                self._log("grok", "✅ Grok applied fixes\n")
            else:
                self._log("grok", f"✅ Grok scan complete — {grok_result[:200]}\n")
        else:
            self._log("grok", f"⚠️ Grok unavailable: {err or 'no key'}\n")
        if not self._ok(): return

        self._log("claude", "🧠 Claude deep logic review...\n")
        deep_prompt = f"""Deep review of this FiveM code for logic errors:
{R['code'][:2500]}

Check for: nil references, missing callbacks, incorrect event names,
SQL issues, memory leaks. Output FIXED_CODE: with corrections applied."""

        cl_debug, err = self.ai.ask_claude(deep_prompt, DEBUG_SYS)
        if cl_debug:
            m = re.search(r"FIXED_CODE:\s*\n([\s\S]+)", cl_debug)
            if m:
                R["code"] = m.group(1).strip()
                self._log("claude", "✅ Claude deep fix applied\n")
            else:
                self._log("claude", f"✅ Claude review: {cl_debug[:150]}\n")
        if not self._ok(): return

        self._log("gpt", "🔎 GPT-4o final syntax pass...\n")
        syntax_prompt = f"""Final syntax check for this FiveM {fw} code.
Fix any remaining syntax errors, ensure all brackets match, 
all strings are closed, all functions complete:
{R['code'][:2500]}

Output ONLY the corrected complete code."""

        gpt_final, err = self.ai.ask_gpt(syntax_prompt, CODE_SYS)
        if gpt_final and self.ai._is_real(gpt_final):
            R["code"] = gpt_final
            self._log("gpt", "✅ GPT syntax pass done\n")
        if not self._ok(): return

        # ── PHASE 5: UI/NUI ────────────────────────────
        self._phase("Building UI/NUI", 5)

        ui_prompt = f"""Build a complete FiveM NUI interface for:
TASK: {task}
FRAMEWORK: {fw}

Create a professional dark glassmorphism UI.
Output one complete index.html with all CSS and JS inline.
Include all PostMessage handlers and SetNuiFocus logic."""

        self._log("claude", "🎨 Claude designing NUI structure...\n")
        nui_structure, err = self.ai.ask_claude(ui_prompt, UI_SYS)
        if nui_structure:
            self._log("claude", "✅ NUI structure planned\n")
        if not self._ok(): return

        self._log("gemini", "🖼️ Gemini building HTML + CSS...\n")
        gem_ui_prompt = f"""Build the complete HTML+CSS for a FiveM NUI:
TASK: {task}
STYLE: Dark glassmorphism, modern, clean
STRUCTURE: {nui_structure[:500] if nui_structure else 'Standard FiveM menu'}

Output one complete index.html file with inline CSS and JavaScript."""

        gem_nui, err = self.ai.ask_gemini(gem_ui_prompt)
        if gem_nui:
            self._log("gemini", f"✅ Gemini HTML/CSS done — {len(gem_nui)} chars\n")
            R["nui"] = gem_nui
        else:
            self._log("gemini", f"⚠️ Gemini unavailable: {err or 'no key'} — Claude will build NUI\n")
            if nui_structure:
                R["nui"] = nui_structure
        if not self._ok(): return

        self._log("gpt", "⚡ GPT-4o adding JavaScript + PostMessage handlers...\n")
        js_prompt = f"""Add complete JavaScript PostMessage handlers to this FiveM NUI:
FRAMEWORK: {fw}
TASK: {task}
NUI HTML: {R.get('nui','')[:800]}

Output the complete index.html with all JS added inline."""

        gpt_nui, err = self.ai.ask_gpt(js_prompt, UI_SYS)
        if gpt_nui and self.ai._is_real(gpt_nui):
            R["nui"] = gpt_nui
            self._log("gpt", "✅ JavaScript handlers added\n")
        if not self._ok(): return

        self._log("nexus_ai", "⬡ Nexus AI validating NUI FiveM compliance...\n")
        nui_val, err = self.ai.ask_nexus(
            f"Validate and finalize this FiveM NUI for {fw}. Fix any SetNuiFocus or SendNUIMessage issues:\n{R.get('nui','')[:1000]}"
        )
        if nui_val and self.ai._is_real(nui_val):
            R["nui"] = nui_val
            self._log("nexus_ai", "✅ NUI validated by Nexus AI\n")
        if not self._ok(): return

        # ── PHASE 6: QA ────────────────────────────────
        self._phase("QA Testing", 6)

        self._log("perp", "🔍 Perplexity checking against live FiveM docs...\n")
        qa_prompt = f"""QA test this FiveM {fw} resource:
CODE SAMPLE:
{R['code'][:1200]}

Check all items against current FiveM documentation."""

        pqa, err = self.ai.ask_perplexity(qa_prompt, QA_SYS)
        qa_failed = False
        if pqa:
            fails = [l for l in pqa.split("\n") if "FAIL" in l]
            qa_failed = len(fails) > 0
            self._log("perp", f"{'⚠️ QA issues: '+str(len(fails)) if qa_failed else '✅ QA passed'}\n{pqa[:300]}\n")
        else:
            self._log("perp", f"⚠️ Perplexity unavailable: {err or 'no key'}\n")
        if not self._ok(): return

        self._log("claude", "🛡️ Claude logic + security QA...\n")
        cl_qa, err = self.ai.ask_claude(
            f"QA audit this FiveM code for logic errors and security:\n{R['code'][:1500]}",
            QA_SYS
        )
        if cl_qa:
            cl_fails = [l for l in cl_qa.split("\n") if "FAIL" in l]
            if cl_fails: qa_failed = True
            self._log("claude", f"{'⚠️ '+str(len(cl_fails))+' issues' if cl_fails else '✅ Logic QA passed'}\n")

        self._log("gemini", "🖥️ Gemini checking NUI render quality...\n")
        gem_qa, err = self.ai.ask_gemini(
            f"QA test this FiveM NUI HTML for render issues and PostMessage correctness:\n{R.get('nui','')[:800]}"
        )
        if gem_qa:
            self._log("gemini", "✅ NUI QA done\n")
        else:
            self._log("gemini", "⚠️ Gemini NUI QA skipped\n")

        if qa_failed:
            self._log("nexus", "⚠️ QA issues found — auto-fixing with Claude...\n")
            fix_prompt = f"""Fix all QA issues in this FiveM code:
QA ISSUES:
{cl_qa or pqa or 'Various QA failures detected'}

CODE:
{R['code'][:2000]}

Output complete fixed code."""
            fixed, err = self.ai.ask_claude(fix_prompt, CODE_SYS)
            if fixed:
                R["code"] = fixed
                self._log("nexus", "✅ QA fixes applied\n")
        if not self._ok(): return

        # ── PHASE 7: SECURITY ──────────────────────────
        self._phase("Security Audit", 7)
        self._log("claude", "🔒 Claude running security audit...\n")

        sec, err = self.ai.ask_claude(
            f"Security audit this FiveM code:\n{R['code'][:2000]}",
            SEC_SYS
        )
        sec_clean = True
        if sec:
            sec_clean = "SECURITY: CLEAN" in sec.upper() or "ISSUE:" not in sec.upper()
            if not sec_clean:
                issues = [l for l in sec.split("\n") if "ISSUE:" in l.upper()]
                self._log("claude", f"🔒 {len(issues)} security issue(s) found — patching...\n")
                for issue in issues[:5]: self._log("claude", f"  {issue}\n")
                patch, err = self.ai.ask_claude(
                    f"Fix these security issues:\n{sec}\n\nCODE:\n{R['code'][:2000]}\n\nOutput complete secured code.",
                    CODE_SYS
                )
                if patch:
                    R["code"] = patch
                    self._log("claude", "✅ Security patches applied\n")
            else:
                self._log("claude", "✅ Security audit: CLEAN\n")
        if not self._ok(): return

        # ── PHASE 8: DEPLOY ────────────────────────────
        self._phase("Writing Files to Server", 8)
        self._log("nexus", "📦 Parsing AI output into files...\n")

        files = self.writer.parse_files(R["code"], R.get("nui",""))
        self._log("nexus", f"📄 Files to write: {list(files.keys())}\n")

        resource_slug = re.sub(r"[^a-z0-9]+", "-", task.lower().strip())[:30].strip("-")
        if not resource_slug: resource_slug = "nexus-resource"

        written_path, write_err = self.writer.write_to_server(
            resource_slug, files, resources_path
        )

        if write_err and not written_path:
            self._log("nexus", f"⚠️ Could not write to server: {write_err}\n")
            self._log("nexus", "💡 Set your Resources Path in Settings to enable auto-deploy\n")
        elif written_path:
            self._log("nexus", f"✅ Resource written to: {written_path}\n")
            if self.server.running:
                self._log("nexus", "🔄 Restarting server to apply changes...\n")
                self.server.restart()
                time.sleep(3)
                errors = self.server.get_errors()
                if errors:
                    self._log("nexus", f"⚠️ Console errors after restart — auto-fixing...\n")
                    error_text = "\n".join(errors[:10])
                    fix, err = self.ai.ask_claude(
                        f"Fix these FiveM server errors:\n{error_text}\nCode context:\n{R['code'][:1000]}",
                        DEBUG_SYS
                    )
                    if fix:
                        m = re.search(r"FIXED_CODE:\s*\n([\s\S]+)", fix)
                        if m:
                            fixed_files = self.writer.parse_files(m.group(1), "")
                            self.writer.write_to_server(resource_slug, fixed_files, resources_path)
                            self.server.restart()
                            self._log("nexus", "✅ Auto-fix applied and server restarted\n")
                else:
                    self._log("nexus", "✅ No console errors — resource is live!\n")

        # ── FINAL OUTPUT ───────────────────────────────
        self._phase("Complete", 9)

        final = f"""╔═══════════════════════════════════════╗
║     NEXUS SUITE — BUILD COMPLETE      ║
╚═══════════════════════════════════════╝

Task: {task}
Framework: {fw}
AI Calls Made: {self.ai.stats['calls']}
Tokens Used: {self.ai.stats['tokens']:,}
Files Written: {len(files)}

FILES:
{chr(10).join(f'  ✅ {k} ({len(v)} chars)' for k,v in files.items())}

QA Status: {'⚠️ Issues found and fixed' if qa_failed else '✅ Passed'}
Security: {'✅ Clean' if sec_clean else '⚠️ Issues patched'}
Deploy: {'✅ Written to ' + str(written_path) if written_path else '⚠️ Set Resources Path in Settings'}
Errors: {self.ai.stats['errors']}

Built at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Log saved to: {LOG_FILE}
"""
        self._log("nexus", final)
        write_log(f"BUILD COMPLETE: {task} — {len(files)} files written")
        self.on_done(
            files,
            final,
            R.get("code", "") or "",
            R.get("nui",  "") or ""
        )

# ══════════════════════════════════════════════════════
#  UI COMPONENTS (HTN Panel style)
# ══════════════════════════════════════════════════════

class Sidebar(ctk.CTkFrame):
    def __init__(self, parent, on_nav):
        super().__init__(parent, width=220, corner_radius=0,
                         fg_color=C["sidebar"],
                         border_width=1, border_color=C["border"])
        self.pack_propagate(False)
        self.on_nav = on_nav; self.btns = {}; self.active = None
        self._build()

    def _build(self):
        logo = ctk.CTkFrame(self, fg_color="transparent")
        logo.pack(pady=(25,5), padx=15, fill="x")
        row = ctk.CTkFrame(logo, fg_color="transparent")
        row.pack(anchor="w")
        hx = ctk.CTkFrame(row, width=38, height=38, corner_radius=10, fg_color=C["accent"])
        hx.pack(side="left"); hx.pack_propagate(False)
        ctk.CTkLabel(hx, text="⬡", font=("Arial",20,"bold"), text_color="white").place(relx=0.5,rely=0.5,anchor="center")
        nc = ctk.CTkFrame(row, fg_color="transparent"); nc.pack(side="left", padx=10)
        ctk.CTkLabel(nc, text="Nexus Suite", font=("Arial",15,"bold"), text_color=C["text"]).pack(anchor="w")
        ctk.CTkLabel(nc, text="FiveM AI Platform", font=("Arial",9), text_color=C["text3"]).pack(anchor="w")

        ctk.CTkFrame(self, height=1, fg_color=C["border"]).pack(fill="x", padx=15, pady=15)

        for icon, label, key in [
            ("🏠","Home","home"), ("🧠","Nexus AI Core","ai"),
            ("📚","Library","library"), ("🌐","Web Tools","webtools"),
            ("📁","File Manager","files"), ("⚙️","Settings","settings"),
        ]:
            btn = ctk.CTkButton(self, text=f"  {icon}   {label}", anchor="w",
                height=42, corner_radius=8, font=("Arial",13),
                fg_color="transparent", hover_color=C["card"],
                text_color=C["text2"], command=lambda k=key: self._nav(k))
            btn.pack(fill="x", padx=10, pady=1)
            self.btns[key] = btn

        ctk.CTkFrame(self, fg_color="transparent").pack(expand=True)

        tunnel = ctk.CTkFrame(self, fg_color=C["card2"], corner_radius=10,
                               border_width=1, border_color=C["border2"])
        tunnel.pack(fill="x", padx=12, pady=5)
        ctk.CTkLabel(tunnel, text="🔗  Connect Tunnel", font=("Arial",11,"bold"), text_color=C["accent2"]).pack(pady=(10,2))
        ctk.CTkLabel(tunnel, text="Share server access", font=("Arial",9), text_color=C["text3"]).pack(pady=(0,10))

        ctk.CTkLabel(self, text="Built by TuckerLawson", font=("Arial",9), text_color=C["text3"]).pack(pady=(5,15))

    def _nav(self, key):
        if self.active: self.btns[self.active].configure(fg_color="transparent", text_color=C["text2"], font=("Arial",13))
        self.btns[key].configure(fg_color=C["card"], text_color=C["accent"], font=("Arial",13,"bold"))
        self.active = key; self.on_nav(key)

    def set_active(self, key): self._nav(key)


class TopBar(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, height=52, corner_radius=0,
                         fg_color=C["card"], border_width=1, border_color=C["border"])
        self.pack_propagate(False); self._build()

    def _build(self):
        i = ctk.CTkFrame(self, fg_color="transparent"); i.pack(fill="both", expand=True, padx=18)
        self.dot = ctk.CTkFrame(i, width=10, height=10, corner_radius=5, fg_color=C["offline"])
        self.dot.pack(side="left", pady=21)
        self.srv = ctk.CTkLabel(i, text="  SERVER OFFLINE", font=("Arial",11,"bold"), text_color=C["offline"])
        self.srv.pack(side="left", pady=20)
        self.ph_b = ctk.CTkFrame(i, fg_color=C["card2"], corner_radius=20)
        self.ph_b.pack(side="left", padx=15, pady=16)
        self.ph_l = ctk.CTkLabel(self.ph_b, text="", font=("Arial",10), text_color=C["text2"])
        self.ph_l.pack(padx=14, pady=3)
        ctk.CTkLabel(i, text="⬡  NEXUS SUITE", font=("Arial",13,"bold"), text_color=C["accent"]).pack(side="right", pady=18)

    def set_server(self, on):
        c = C["online"] if on else C["offline"]
        self.dot.configure(fg_color=c)
        self.srv.configure(text="  SERVER ONLINE" if on else "  SERVER OFFLINE", text_color=c)

    def set_phase(self, ph, n):
        if ph and n < 9:
            self.ph_l.configure(text=f"  ⚡ {n}/8 — {ph}  ", text_color=C["warning"])
            self.ph_b.configure(fg_color=C["warning"]+"22")
        elif n >= 9:
            self.ph_l.configure(text="  ✅ Build Complete  ", text_color=C["success"])
            self.ph_b.configure(fg_color=C["success"]+"22")
        else:
            self.ph_l.configure(text="", text_color=C["text2"])
            self.ph_b.configure(fg_color=C["card2"])


# ══════════════════════════════════════════════════════
#  PAGES
# ══════════════════════════════════════════════════════

class HomePage(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=C["bg"])
        self.app = app; self._build()

    def _build(self):
        hdr = ctk.CTkFrame(self, fg_color=C["card"], corner_radius=0, border_width=1, border_color=C["border"])
        hdr.pack(fill="x")
        hi = ctk.CTkFrame(hdr, fg_color="transparent"); hi.pack(fill="x", padx=20, pady=14)
        ctk.CTkLabel(hi, text="Your Servers", font=("Arial",20,"bold"), text_color=C["text"]).pack(side="left")
        ctk.CTkLabel(hi, text="  A quick look at your active servers", font=("Arial",12), text_color=C["text3"]).pack(side="left")
        ctk.CTkButton(hi, text="＋  New Server", height=36, width=130, corner_radius=8,
            fg_color=C["accent"], hover_color=C["accent_h"], font=("Arial",12,"bold"),
            command=lambda: self.app.navigate("settings")
        ).pack(side="right")

        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=20, pady=15)

        cfg = self.app.config; stats = self.app.server.get_stats()

        # Server card — HTN Panel style
        sc = ctk.CTkFrame(scroll, fg_color=C["card2"], corner_radius=12, border_width=1, border_color=C["border2"])
        sc.pack(fill="x", pady=5)

        top = ctk.CTkFrame(sc, fg_color="transparent"); top.pack(fill="x", padx=15, pady=(15,8))
        icon_bg = ctk.CTkFrame(top, width=48, height=48, corner_radius=10, fg_color=C["accent"]+"33", border_width=1, border_color=C["accent"]+"55")
        icon_bg.pack(side="left"); icon_bg.pack_propagate(False)
        ctk.CTkLabel(icon_bg, text="🎮", font=("Arial",22)).place(relx=0.5,rely=0.5,anchor="center")

        info = ctk.CTkFrame(top, fg_color="transparent"); info.pack(side="left", padx=12)
        ctk.CTkLabel(info, text=cfg.get("server_name","My FiveM Server"), font=("Arial",14,"bold"), text_color=C["text"]).pack(anchor="w")
        ctk.CTkLabel(info, text="FiveM Server", font=("Arial",11), text_color=C["text2"]).pack(anchor="w")

        bc = C["online"] if self.app.server.running else C["offline"]
        bt = "● Online" if self.app.server.running else "● Offline"
        badge = ctk.CTkFrame(top, fg_color=bc+"22", corner_radius=20, border_width=1, border_color=bc+"66")
        badge.pack(side="right")
        ctk.CTkLabel(badge, text=bt, font=("Arial",11,"bold"), text_color=bc).pack(padx=12, pady=4)

        # Stats
        sr = ctk.CTkFrame(sc, fg_color=C["card3"], corner_radius=8); sr.pack(fill="x", padx=12, pady=5)
        for label, val, color in [
            ("CPU", f"{stats['cpu']}%", C["accent"]),
            ("RAM", f"{stats['ram']}%", C["gpt"]),
            ("Storage", f"{stats['storage']}%", C["gemini"]),
            ("Players", str(stats['players']), C["perp"]),
        ]:
            col = ctk.CTkFrame(sr, fg_color="transparent"); col.pack(side="left", expand=True, pady=10)
            ctk.CTkLabel(col, text=val, font=("Arial",15,"bold"), text_color=color).pack()
            ctk.CTkLabel(col, text=label, font=("Arial",9), text_color=C["text3"]).pack()

        ip_row = ctk.CTkFrame(sc, fg_color="transparent"); ip_row.pack(fill="x", padx=15, pady=5)
        ctk.CTkLabel(ip_row, text=f"🌐  127.0.0.1:{cfg.get('server_port','30120')}", font=("Arial",10), text_color=C["text3"]).pack(side="left")

        btns = ctk.CTkFrame(sc, fg_color="transparent"); btns.pack(fill="x", padx=12, pady=(0,12))
        for text, color, cmd in [
            ("▶ Start" if not self.app.server.running else "🔄 Restart", C["success"], self._start if not self.app.server.running else self._restart),
            ("⏹ Stop", C["error"], self._stop),
            ("🧠 AI Core", C["accent2"], lambda: self.app.navigate("ai")),
        ]:
            ctk.CTkButton(btns, text=text, height=34, corner_radius=8, font=("Arial",11,"bold"),
                fg_color=color+"22", hover_color=color+"44",
                border_width=1, border_color=color+"66", text_color=color, command=cmd
            ).pack(side="left", fill="x", expand=True, padx=3)

        # Quick links
        ctk.CTkLabel(scroll, text="QUICK ACTIONS", font=("Arial",10,"bold"), text_color=C["text3"]).pack(anchor="w", pady=(20,8))
        qa = ctk.CTkFrame(scroll, fg_color="transparent"); qa.pack(fill="x")
        for icon,label,color,cmd in [
            ("🧠","AI Core",C["claude"],lambda:self.app.navigate("ai")),
            ("📁","Files",C["gpt"],lambda:self.app.navigate("files")),
            ("📚","Library",C["gemini"],lambda:self.app.navigate("library")),
            ("🌐","Web Tools",C["perp"],lambda:self.app.navigate("webtools")),
            ("⚙️","Settings",C["text2"],lambda:self.app.navigate("settings")),
        ]:
            c = ctk.CTkFrame(qa, fg_color=C["card2"], corner_radius=10, border_width=1, border_color=C["border"])
            c.pack(side="left", expand=True, fill="x", padx=4)
            ctk.CTkLabel(c, text=icon, font=("Arial",24)).pack(pady=(15,5))
            ctk.CTkLabel(c, text=label, font=("Arial",11,"bold"), text_color=color).pack()
            ctk.CTkButton(c, text="Open", height=30, corner_radius=6, width=80,
                fg_color=color+"22", hover_color=color+"44",
                border_width=1, border_color=color+"66",
                text_color=color, font=("Arial",10), command=cmd
            ).pack(pady=(5,15))

    def _start(self):
        self.app.server.start()
        self.app.topbar.set_server(True)
        # Rebuild only the server card section
        for w in self.winfo_children(): w.destroy()
        self._build()

    def _stop(self):
        self.app.server.stop()
        self.app.topbar.set_server(False)
        for w in self.winfo_children(): w.destroy()
        self._build()

    def _restart(self):
        self.app.server.restart()


class AICorePage(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=C["bg"])
        self.app = app; self.pl = None
        self._files = {}; self._final = ""; self._task = ""
        self._build()

    def _build(self):
        hdr = ctk.CTkFrame(self, fg_color=C["card"], corner_radius=0, border_width=1, border_color=C["border"])
        hdr.pack(fill="x")
        hi = ctk.CTkFrame(hdr, fg_color="transparent"); hi.pack(fill="x", padx=20, pady=12)
        ctk.CTkLabel(hi, text="🧠  Nexus AI Core", font=("Arial",16,"bold"), text_color=C["text"]).pack(side="left")
        self.scan_lbl = ctk.CTkLabel(hi, text="  Not scanned", font=("Arial",11), text_color=C["text3"])
        self.scan_lbl.pack(side="left")
        ctk.CTkButton(hi, text="🔍 Scan Server", width=120, height=32, corner_radius=8,
            fg_color=C["card2"], hover_color=C["card3"], border_width=1, border_color=C["border2"],
            font=("Arial",11), command=self._scan
        ).pack(side="right")

        body = ctk.CTkFrame(self, fg_color="transparent"); body.pack(fill="both", expand=True, padx=12, pady=10)

        # Left panel
        left = ctk.CTkFrame(body, fg_color="transparent", width=295)
        left.pack(side="left", fill="y", padx=(0,8)); left.pack_propagate(False)

        tc = ctk.CTkFrame(left, fg_color=C["card"], corner_radius=12, border_width=1, border_color=C["border"])
        tc.pack(fill="x", pady=(0,8))
        ctk.CTkLabel(tc, text="Task", font=("Arial",12,"bold"), text_color=C["text"]).pack(anchor="w", padx=12, pady=(12,5))
        self.task = ctk.CTkTextbox(tc, height=120, corner_radius=8, fg_color=C["bg2"], border_width=1, border_color=C["border"], font=("Arial",12))
        self.task.pack(fill="x", padx=10, pady=(0,10))
        self.task.insert("0.0", "Build a /garage command with NUI vehicle menu using QBCore")

        bc = ctk.CTkFrame(left, fg_color=C["card"], corner_radius=12, border_width=1, border_color=C["border"])
        bc.pack(fill="x", pady=(0,8))
        bi = ctk.CTkFrame(bc, fg_color="transparent"); bi.pack(fill="x", padx=10, pady=10)

        self.run_btn = ctk.CTkButton(bi, text="🚀  RUN PIPELINE",
            font=("Arial",13,"bold"), fg_color=C["accent"], hover_color=C["accent_h"],
            height=44, corner_radius=10, command=self._run)
        self.run_btn.pack(fill="x", pady=(0,6))

        r2 = ctk.CTkFrame(bi, fg_color="transparent"); r2.pack(fill="x")
        ctk.CTkButton(r2, text="⏹ Cancel", height=34, corner_radius=8,
            fg_color=C["error"]+"22", hover_color=C["error"]+"44",
            border_width=1, border_color=C["error"]+"55", text_color=C["error"],
            font=("Arial",11), command=self._cancel
        ).pack(side="left", fill="x", expand=True, padx=(0,4))
        ctk.CTkButton(r2, text="🗑️ Clear", height=34, corner_radius=8,
            fg_color=C["card2"], hover_color=C["card3"],
            border_width=1, border_color=C["border"], text_color=C["text2"],
            font=("Arial",11), command=self._clear
        ).pack(side="left", fill="x", expand=True)

        # Key status indicator
        kc = ctk.CTkFrame(left, fg_color=C["card"], corner_radius=12, border_width=1, border_color=C["border"])
        kc.pack(fill="x", pady=(0,8))
        ctk.CTkLabel(kc, text="API Status", font=("Arial",11,"bold"), text_color=C["text"]).pack(anchor="w", padx=12, pady=(10,5))

        keys = self.app.keys
        for key, name, color in [
            ("claude","Claude",C["claude"]),("openai","GPT-4o",C["gpt"]),
            ("grok","Grok",C["grok"]),("gemini","Gemini",C["gemini"]),
            ("perplexity","Perplexity",C["perp"]),
        ]:
            row = ctk.CTkFrame(kc, fg_color="transparent"); row.pack(fill="x", padx=12, pady=2)
            has_key = bool(keys.get(key,"").strip())
            dot_c = color if has_key else C["text3"]
            ctk.CTkFrame(row, width=8, height=8, corner_radius=4, fg_color=dot_c).pack(side="left", pady=4)
            ctk.CTkLabel(row, text=f"  {name}", font=("Arial",10), text_color=dot_c if has_key else C["text3"]).pack(side="left")
            ctk.CTkLabel(row, text="✅" if has_key else "❌ No key", font=("Arial",10),
                text_color=color if has_key else C["error"]
            ).pack(side="right")

        ctk.CTkFrame(kc, fg_color="transparent", height=8).pack()

        # Agent status cards
        ac = ctk.CTkFrame(left, fg_color=C["card"], corner_radius=12, border_width=1, border_color=C["border"])
        ac.pack(fill="both", expand=True)
        ctk.CTkLabel(ac, text="Agent Status", font=("Arial",11,"bold"), text_color=C["text"]).pack(anchor="w", padx=12, pady=(12,5))

        self.acards = {}
        sa = ctk.CTkScrollableFrame(ac, fg_color="transparent")
        sa.pack(fill="both", expand=True, padx=6, pady=(0,8))

        for key,name,color,icon in [
            ("claude","Claude",C["claude"],"🗂️"),("gpt","GPT-4o",C["gpt"],"💻"),
            ("grok","Grok",C["grok"],"🐛"),("gemini","Gemini",C["gemini"],"🎨"),
            ("perp","Perplexity",C["perp"],"🔍"),("nexus_ai","Nexus AI",C["nexus_ai"],"⬡"),
        ]:
            f = ctk.CTkFrame(sa, fg_color=C["card2"], corner_radius=10, border_width=1, border_color=C["border"])
            f.pack(fill="x", pady=2); f.configure(height=58); f.pack_propagate(False)
            ib = ctk.CTkFrame(f, width=32, height=32, corner_radius=16, fg_color=color+"22", border_width=1, border_color=color+"55")
            ib.place(x=8, rely=0.5, anchor="w"); ib.pack_propagate(False)
            ctk.CTkLabel(ib, text=icon, font=("Arial",13)).place(relx=0.5,rely=0.5,anchor="center")
            nl = ctk.CTkLabel(f, text=name, font=("Arial",11,"bold"), text_color=color); nl.place(x=48,y=8)
            sl = ctk.CTkLabel(f, text="Idle", font=("Arial",9), text_color=C["text3"]); sl.place(x=48,y=26)
            pb = ctk.CTkProgressBar(f, height=3, corner_radius=2, progress_color=color, fg_color=C["border"])
            pb.place(x=48, rely=0.85, relwidth=0.65, anchor="w"); pb.set(0)
            cl2 = ctk.CTkLabel(f, text="", font=("Arial",9,"bold"), text_color=color); cl2.place(relx=0.9,rely=0.3,anchor="center")
            self.acards[key] = (ib, sl, pb, cl2, color)

        # Right panel
        right = ctk.CTkFrame(body, fg_color="transparent"); right.pack(side="right", fill="both", expand=True)
        tabs = ctk.CTkTabview(right, fg_color=C["card"], corner_radius=12,
            border_width=1, border_color=C["border"],
            segmented_button_fg_color=C["card2"],
            segmented_button_selected_color=C["accent"],
            segmented_button_selected_hover_color=C["accent_h"],
            segmented_button_unselected_color=C["card2"],
            segmented_button_unselected_hover_color=C["card3"])
        tabs.pack(fill="both", expand=True)

        lt = tabs.add("  📡 Live Output  ")
        self.live = ctk.CTkTextbox(lt, font=("Courier",11), fg_color=C["bg"], text_color=C["text"], corner_radius=0)
        self.live.configure(state="disabled")
        self.live.pack(fill="both", expand=True, padx=2, pady=2)

        ft = tabs.add("  ✅ Final Output  ")
        ar = ctk.CTkFrame(ft, fg_color="transparent"); ar.pack(fill="x", padx=8, pady=8)
        for txt,col,cmd in [("📋 Copy",C["card2"],self._copy),("💾 Save",C["card2"],self._save),("📚 Library",C["accent"],self._lib)]:
            ctk.CTkButton(ar, text=txt, width=105, height=32, corner_radius=8,
                fg_color=col, hover_color=C["card3"], border_width=1, border_color=C["border"],
                font=("Arial",11), command=cmd
            ).pack(side="left", padx=3)
        self.final = ctk.CTkTextbox(ft, font=("Courier",11), fg_color=C["bg"], corner_radius=8)
        self.final.pack(fill="both", expand=True, padx=8, pady=(0,8))

        ct = tabs.add("  📄 Generated Code  ")
        cc = ctk.CTkFrame(ct, fg_color="transparent"); cc.pack(fill="x", padx=8, pady=8)
        ctk.CTkButton(cc, text="📋 Copy Code", width=120, height=32, corner_radius=8,
            fg_color=C["card2"], hover_color=C["card3"], border_width=1, border_color=C["border"],
            font=("Arial",11), command=self._copy_code
        ).pack(side="left", padx=3)
        ctk.CTkButton(cc, text="💾 Save Code", width=120, height=32, corner_radius=8,
            fg_color=C["card2"], hover_color=C["card3"], border_width=1, border_color=C["border"],
            font=("Arial",11), command=self._save_code
        ).pack(side="left", padx=3)
        self.code_box = ctk.CTkTextbox(ct, font=("Courier",11), fg_color=C["bg"], corner_radius=8)
        self.code_box.pack(fill="both", expand=True, padx=8, pady=(0,8))

        nt = tabs.add("  🎨 Generated NUI  ")
        self.nui_box = ctk.CTkTextbox(nt, font=("Courier",11), fg_color=C["bg"], corner_radius=8)
        self.nui_box.pack(fill="both", expand=True, padx=8, pady=8)

        self._raw_code = ""
        self._raw_nui  = ""

    def _scan(self):
        ctx = self.app.server.scan(self.app.config.get("server_data",""))
        self.scan_lbl.configure(text=f"  {ctx.get('framework','?')} | {ctx.get('resource_count',0)} resources", text_color=C["success"])
        self.app.ctx = ctx

    def _acard(self, key, working=False, conf=None, done=False):
        if key not in self.acards: return
        ib, sl, pb, cl2, color = self.acards[key]
        if done:
            ib.configure(border_color=C["success"])
            sl.configure(text="Done ✅", text_color=C["success"])
            pb.set(1.0)
            if conf: cl2.configure(text=f"{conf}%")
        elif working:
            ib.configure(border_color=color)
            sl.configure(text="Working...", text_color=C["warning"])
            pb.set(0.6)
            if conf: cl2.configure(text=f"{conf}%")
        else:
            ib.configure(border_color=color+"55")
            sl.configure(text="Idle", text_color=C["text3"])
            pb.set(0); cl2.configure(text="")

    def _log_live(self, agent, text):
        self.live.configure(state="normal")
        self.live.insert("end", f"[{agent.upper():<12}] {text}")
        self.live.see("end")
        self.live.configure(state="disabled")

    def _run(self):
        task = self.task.get("0.0","end").strip()
        if not task: return

        # Check at least one key configured
        keys = self.app.keys
        if not any(keys.get(k,"").strip() for k in ["claude","openai","grok","gemini","perplexity"]):
            messagebox.showwarning(
                "No API Keys",
                "You need at least one API key to run the pipeline.\n\n"
                "Minimum: Claude OR GPT-4o\n\n"
                "Go to Settings ⚙️ to add your keys."
            )
            self.app.navigate("settings")
            return

        self._task = task
        self.live.configure(state="normal"); self.live.delete("0.0","end"); self.live.configure(state="disabled")
        self.final.delete("0.0","end")
        self.code_box.delete("0.0","end")
        self.nui_box.delete("0.0","end")
        for k in self.acards: self._acard(k, False)

        self.pl = Pipeline(
            ai=self.app.ai,
            server=self.app.server,
            writer=self.app.writer,
            on_upd=self._on_upd,
            on_phase=self._on_ph,
            on_done=self._on_done,
            on_err=self._on_err
        )
        self.pl.run(task, getattr(self.app,"ctx",{}), self.app.config.get("resources_path",""))

    def _cancel(self):
        if self.pl: self.pl.cancel()
        self._log_live("nexus","⏹ Pipeline cancelled\n")

    def _on_upd(self, agent, text):
        def _do():
            self._log_live(agent, text)
            if agent in self.acards:
                conf = self.app.ai.confidence(text)
                done = any(x in text for x in ["✅","done","complete","validated","passed","applied"])
                self._acard(agent, not done, conf, done)
        self.after(0, _do)

    def _on_ph(self, n, i): self.after(0, lambda: self.app.topbar.set_phase(n, i))

    def _on_done(self, files, final, raw_code, raw_nui):
        def _do():
            self._files = files; self._final = final
            self._raw_code = raw_code; self._raw_nui = raw_nui
            self.final.delete("0.0","end"); self.final.insert("0.0", final)
            self.code_box.delete("0.0","end"); self.code_box.insert("0.0", raw_code)
            if raw_nui: self.nui_box.delete("0.0","end"); self.nui_box.insert("0.0", raw_nui)
            for k in self.acards: self._acard(k, False, 95, True)
        self.after(0, _do)

    def _on_err(self, msg):
        def _do():
            self._log_live("nexus", f"❌ PIPELINE ERROR: {msg}\n")
            messagebox.showerror("Pipeline Error", f"{msg}\n\nCheck Settings and add your API keys.")
        self.after(0, _do)

    def _copy(self): self.clipboard_clear(); self.clipboard_append(self._final)
    def _copy_code(self): self.clipboard_clear(); self.clipboard_append(self._raw_code)
    def _save(self):
        p = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text","*.txt")])
        if p:
            with open(p,"w",encoding="utf-8") as f: f.write(self._final)
    def _save_code(self):
        p = filedialog.asksaveasfilename(defaultextension=".lua", filetypes=[("Lua","*.lua"),("All","*.*")])
        if p:
            with open(p,"w",encoding="utf-8") as f: f.write(self._raw_code)
    def _lib(self):
        if not self._task: return
        lib = jload(LIB_FILE,[])
        lib.append({"task":self._task,"files":list(self._files.keys()),"created":datetime.now().isoformat(),"output":self._final[:400]})
        jsave(LIB_FILE,lib); self._log_live("nexus","📚 Saved to Library\n")
    def _clear(self):
        self.live.configure(state="normal"); self.live.delete("0.0","end"); self.live.configure(state="disabled")
        self.final.delete("0.0","end"); self.task.delete("0.0","end")
        self.code_box.delete("0.0","end"); self.nui_box.delete("0.0","end")
        for k in self.acards: self._acard(k, False)
        self.app.topbar.set_phase("",0)


class LibraryPage(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=C["bg"])
        self.app = app; self._build()

    def _build(self):
        hdr = ctk.CTkFrame(self, fg_color=C["card"], corner_radius=0, border_width=1, border_color=C["border"])
        hdr.pack(fill="x")
        hi = ctk.CTkFrame(hdr, fg_color="transparent"); hi.pack(fill="x", padx=20, pady=14)
        ctk.CTkLabel(hi, text="📚  Library", font=("Arial",16,"bold"), text_color=C["text"]).pack(side="left")
        ctk.CTkButton(hi, text="🔄 Refresh", width=100, height=32, corner_radius=8,
            fg_color=C["card2"], hover_color=C["card3"], border_width=1, border_color=C["border"],
            font=("Arial",11), command=self._reload
        ).pack(side="right")
        self.scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.scroll.pack(fill="both", expand=True, padx=20, pady=12)
        self._reload()

    def _reload(self):
        for w in self.scroll.winfo_children(): w.destroy()
        lib = jload(LIB_FILE,[])
        if not lib:
            e = ctk.CTkFrame(self.scroll, fg_color=C["card"], corner_radius=12, border_width=1, border_color=C["border"])
            e.pack(fill="x", pady=20)
            ctk.CTkLabel(e, text="📚\n\nNo saved resources yet.\nBuild something in Nexus AI Core first!",
                font=("Arial",13), text_color=C["text2"], justify="center").pack(pady=40)
            return
        for entry in reversed(lib):
            card = ctk.CTkFrame(self.scroll, fg_color=C["card2"], corner_radius=12, border_width=1, border_color=C["border2"])
            card.pack(fill="x", pady=5)
            top = ctk.CTkFrame(card, fg_color="transparent"); top.pack(fill="x", padx=15, pady=(12,5))
            ctk.CTkLabel(top, text=entry.get("task","?")[:65], font=("Arial",12,"bold"), text_color=C["accent2"]).pack(side="left")
            ctk.CTkLabel(top, text=entry.get("created","")[:10], font=("Arial",10), text_color=C["text3"]).pack(side="right")
            fr = ctk.CTkFrame(card, fg_color="transparent"); fr.pack(fill="x", padx=12, pady=(0,12))
            for f in entry.get("files",[]):
                p = ctk.CTkFrame(fr, fg_color=C["card3"], corner_radius=6, border_width=1, border_color=C["border"])
                p.pack(side="left", padx=3)
                ctk.CTkLabel(p, text=f"📄 {f}", font=("Arial",9), text_color=C["text2"]).pack(padx=8, pady=4)
            # Delete button
            def _del(e=entry):
                lib2 = jload(LIB_FILE, [])
                lib2 = [x for x in lib2 if x.get("task") != e.get("task") or x.get("created") != e.get("created")]
                jsave(LIB_FILE, lib2)
                self._reload()
            ctk.CTkButton(card, text="🗑️ Delete", width=80, height=26, corner_radius=6,
                fg_color=C["error"]+"22", hover_color=C["error"]+"44",
                border_width=1, border_color=C["error"]+"55",
                text_color=C["error"], font=("Arial",9), command=_del
            ).pack(anchor="e", padx=15, pady=(0,10))


class WebToolsPage(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=C["bg"])
        self.app = app; self._build()

    def _build(self):
        hdr = ctk.CTkFrame(self, fg_color=C["card"], corner_radius=0, border_width=1, border_color=C["border"])
        hdr.pack(fill="x")
        hi = ctk.CTkFrame(hdr, fg_color="transparent"); hi.pack(fill="x", padx=20, pady=14)
        ctk.CTkLabel(hi, text="🌐  Web Tools", font=("Arial",16,"bold"), text_color=C["text"]).pack(side="left")
        ctk.CTkLabel(hi, text="  External AI tools", font=("Arial",11), text_color=C["text3"]).pack(side="left")

        tabs = ctk.CTkTabview(self, fg_color=C["card"], corner_radius=0,
            segmented_button_fg_color=C["card2"],
            segmented_button_selected_color=C["accent"],
            segmented_button_selected_hover_color=C["accent_h"],
            segmented_button_unselected_color=C["card2"],
            segmented_button_unselected_hover_color=C["card3"])
        tabs.pack(fill="both", expand=True)

        for tab_name,url,color,title,desc in [
            ("🟠 Replit","https://replit.com",C["replit"],"Replit","Code and deploy in the browser"),
            ("💜 Lovable","https://lovable.dev",C["lovable"],"Lovable.ai","AI that builds full-stack apps"),
            ("🚀 Rocket","https://rocket.new",C["rocket"],"Rocket.new","Ship full-stack apps with AI"),
        ]:
            t = tabs.add(f"  {tab_name}  ")
            info = ctk.CTkFrame(t, fg_color=C["card2"], corner_radius=0, border_width=1, border_color=C["border"])
            info.pack(fill="x")
            ii = ctk.CTkFrame(info, fg_color="transparent"); ii.pack(fill="x", padx=20, pady=12)
            ctk.CTkFrame(ii, width=10, height=10, corner_radius=5, fg_color=color).pack(side="left", pady=5)
            ctk.CTkLabel(ii, text=f"  {title}", font=("Arial",13,"bold"), text_color=color).pack(side="left")
            ctk.CTkLabel(ii, text=f"  —  {desc}", font=("Arial",11), text_color=C["text3"]).pack(side="left")
            ctk.CTkButton(ii, text="🌐 Open in Browser", width=150, height=32, corner_radius=8,
                fg_color=color+"22", hover_color=color+"44",
                border_width=1, border_color=color+"66", text_color=color, font=("Arial",11),
                command=lambda u=url: (os.startfile(u) if os.name=="nt" else subprocess.Popen(["xdg-open",u]))
            ).pack(side="right")

            center = ctk.CTkFrame(t, fg_color="transparent"); center.place(relx=0.5,rely=0.5,anchor="center")
            ib = ctk.CTkFrame(center, width=80, height=80, corner_radius=20, fg_color=color+"22", border_width=2, border_color=color+"55")
            ib.pack(); ib.pack_propagate(False)
            ctk.CTkLabel(ib, text="🌐", font=("Arial",36)).place(relx=0.5,rely=0.5,anchor="center")
            ctk.CTkLabel(center, text=title, font=("Arial",20,"bold"), text_color=color).pack(pady=(15,5))
            ctk.CTkLabel(center, text=desc, font=("Arial",12), text_color=C["text2"]).pack()
            ctk.CTkLabel(center, text="Click to open in your browser", font=("Arial",11), text_color=C["text3"]).pack(pady=5)
            ctk.CTkButton(center, text=f"🚀 Open {title}", width=200, height=44, corner_radius=12,
                fg_color=color, font=("Arial",13,"bold"), text_color="white",
                command=lambda u=url: (os.startfile(u) if os.name=="nt" else subprocess.Popen(["xdg-open",u]))
            ).pack(pady=10)
            ctk.CTkLabel(center, text=url, font=("Arial",10), text_color=C["text3"]).pack()


class FilesPage(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=C["bg"])
        self.app = app; self.cur = None; self._build()

    def _build(self):
        hdr = ctk.CTkFrame(self, fg_color=C["card"], corner_radius=0, border_width=1, border_color=C["border"])
        hdr.pack(fill="x")
        hi = ctk.CTkFrame(hdr, fg_color="transparent"); hi.pack(fill="x", padx=20, pady=14)
        ctk.CTkLabel(hi, text="📁  File Manager", font=("Arial",16,"bold"), text_color=C["text"]).pack(side="left")
        ctk.CTkButton(hi, text="🔄 Refresh", width=100, height=32, corner_radius=8,
            fg_color=C["card2"], hover_color=C["card3"], border_width=1, border_color=C["border"],
            font=("Arial",11), command=self._refresh
        ).pack(side="right")

        body = ctk.CTkFrame(self, fg_color="transparent"); body.pack(fill="both", expand=True, padx=12, pady=10)
        tf = ctk.CTkFrame(body, fg_color=C["card"], corner_radius=12, border_width=1, border_color=C["border"], width=270)
        tf.pack(side="left", fill="y", padx=(0,8)); tf.pack_propagate(False)
        ctk.CTkLabel(tf, text="Resources", font=("Arial",12,"bold"), text_color=C["text"]).pack(anchor="w", padx=12, pady=(12,6))
        self.tree = ctk.CTkScrollableFrame(tf, fg_color="transparent")
        self.tree.pack(fill="both", expand=True, padx=4, pady=(0,8))

        ef = ctk.CTkFrame(body, fg_color=C["card"], corner_radius=12, border_width=1, border_color=C["border"])
        ef.pack(side="right", fill="both", expand=True)
        eh = ctk.CTkFrame(ef, fg_color="transparent"); eh.pack(fill="x", padx=12, pady=(12,6))
        self.fl = ctk.CTkLabel(eh, text="Select a file", font=("Arial",11), text_color=C["text2"]); self.fl.pack(side="left")
        for txt,col,cmd in [("🤖 AI Fix",C["card2"],self._ai),("💾 Save",C["accent"],self._save)]:
            ctk.CTkButton(eh, text=txt, width=95, height=30, corner_radius=8,
                fg_color=col, hover_color=C["card3"], border_width=1, border_color=C["border"],
                font=("Arial",11), command=cmd
            ).pack(side="right", padx=3)
        self.ed = ctk.CTkTextbox(ef, font=("Courier",11), fg_color=C["bg"], corner_radius=8)
        self.ed.pack(fill="both", expand=True, padx=10, pady=(0,10))
        self._refresh()

    def _refresh(self):
        for w in self.tree.winfo_children(): w.destroy()
        rp = self.app.config.get("resources_path","")
        if not rp or not os.path.exists(rp):
            ctk.CTkLabel(self.tree, text="No server path set\nGo to Settings ⚙️", font=("Arial",11), text_color=C["text3"]).pack(pady=20)
            return
        for item in sorted(Path(rp).iterdir()):
            if item.is_dir():
                ctk.CTkButton(self.tree, text=f"📁  {item.name}", anchor="w", height=30, corner_radius=6,
                    fg_color="transparent", hover_color=C["card2"], text_color=C["text"], font=("Arial",11),
                    command=lambda p=item:self._expand(p)
                ).pack(fill="x", pady=1)

    def _expand(self, path):
        # Clear all existing file entries first to avoid duplicates
        for w in self.tree.winfo_children():
            if hasattr(w, '_is_file_btn'):
                w.destroy()
        # Re-add folder button + files
        for ext in ["*.lua","*.html","*.js","*.cfg","*.json","*.sql"]:
            for f in sorted(path.rglob(ext)):
                btn = ctk.CTkButton(self.tree, text=f"    📄  {f.name}", anchor="w", height=26, corner_radius=5,
                    fg_color="transparent", hover_color=C["card2"], text_color=C["text2"], font=("Arial",9),
                    command=lambda p=f:self._open(p)
                )
                btn._is_file_btn = True
                btn.pack(fill="x", pady=1)

    def _open(self, path):
        self.cur = path; self.fl.configure(text=str(path.name), text_color=C["accent2"])
        try: content = path.read_text(encoding="utf-8", errors="ignore")
        except Exception as e: content = f"Error: {e}"
        self.ed.delete("0.0","end"); self.ed.insert("0.0", content)

    def _save(self):
        if not self.cur: return
        with open(self.cur,"w",encoding="utf-8") as f: f.write(self.ed.get("0.0","end"))

    def _ai(self):
        if not self.cur: return
        content = self.ed.get("0.0","end")
        def _fix():
            result, err = self.app.ai.ask_claude(
                f"Fix all bugs in this FiveM file ({self.cur.name}):\n{content}\nOutput FIXED_CODE: then the complete corrected file.",
                DEBUG_SYS
            )
            if result:
                m = re.search(r"FIXED_CODE:\s*\n([\s\S]+)", result)
                fixed = m.group(1).strip() if m else result
                self.after(0, lambda: (self.ed.delete("0.0","end"), self.ed.insert("0.0", fixed)))
        threading.Thread(target=_fix, daemon=True).start()


class SettingsPage(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=C["bg"])
        self.app = app; self.entries = {}; self._build()

    def _build(self):
        hdr = ctk.CTkFrame(self, fg_color=C["card"], corner_radius=0, border_width=1, border_color=C["border"])
        hdr.pack(fill="x")
        ctk.CTkLabel(hdr, text="⚙️  Settings", font=("Arial",16,"bold"), text_color=C["text"]).pack(side="left", padx=20, pady=14)

        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=40, pady=20)
        cfg = jload(CFG_FILE,{})

        ctk.CTkLabel(scroll, text="SERVER INFO", font=("Arial",10,"bold"), text_color=C["text3"]).pack(anchor="w", pady=(0,8))
        for key,label,default,hint in [
            ("server_name","Server Name","My FiveM Server","Name shown in the panel"),
            ("server_port","Server Port","30120","Port your FiveM server runs on"),
        ]:
            c = ctk.CTkFrame(scroll, fg_color=C["card2"], corner_radius=10, border_width=1, border_color=C["border"])
            c.pack(fill="x", pady=4)
            i = ctk.CTkFrame(c, fg_color="transparent"); i.pack(fill="x", padx=15, pady=12)
            ctk.CTkLabel(i, text=label, font=("Arial",12,"bold"), text_color=C["text"]).pack(anchor="w")
            ctk.CTkLabel(i, text=hint, font=("Arial",9), text_color=C["text3"]).pack(anchor="w")
            e = ctk.CTkEntry(i, height=34, corner_radius=8, fg_color=C["bg"], border_width=1, border_color=C["border"], font=("Arial",12))
            e.pack(fill="x", pady=(6,0)); e.insert(0, cfg.get(key,default))
            self.entries[key] = e

        ctk.CTkLabel(scroll, text="API KEYS", font=("Arial",10,"bold"), text_color=C["text3"]).pack(anchor="w", pady=(20,8))
        keys = jload(KEYS_FILE,{})
        for key,label,color,url in [
            ("claude","Claude (Anthropic)",C["claude"],"console.anthropic.com"),
            ("openai","GPT-4o (OpenAI)",C["gpt"],"platform.openai.com"),
            ("grok","Grok (xAI)",C["grok"],"console.x.ai"),
            ("gemini","Gemini (Google)",C["gemini"],"aistudio.google.com"),
            ("perplexity","Perplexity",C["perp"],"perplexity.ai/settings/api"),
        ]:
            c = ctk.CTkFrame(scroll, fg_color=C["card2"], corner_radius=10, border_width=1, border_color=C["border"])
            c.pack(fill="x", pady=4)
            i = ctk.CTkFrame(c, fg_color="transparent"); i.pack(fill="x", padx=15, pady=12)
            tr = ctk.CTkFrame(i, fg_color="transparent"); tr.pack(fill="x")
            ctk.CTkFrame(tr, width=8, height=8, corner_radius=4, fg_color=color).pack(side="left", pady=6)
            ctk.CTkLabel(tr, text=f"  {label}", font=("Arial",12,"bold"), text_color=color).pack(side="left")
            ctk.CTkLabel(tr, text=f"  {url}", font=("Arial",9), text_color=C["text3"]).pack(side="left")
            has = bool(keys.get(key,"").strip())
            ctk.CTkLabel(tr, text="✅ Configured" if has else "❌ Not set",
                font=("Arial",10), text_color=C["success"] if has else C["error"]
            ).pack(side="right")
            e = ctk.CTkEntry(i, placeholder_text="Paste API key here...", show="*",
                height=34, corner_radius=8, fg_color=C["bg"],
                border_width=1, border_color=C["border"], font=("Arial",12))
            e.pack(fill="x", pady=(6,0))
            if key in keys: e.insert(0, keys[key])
            self.entries[key] = e

        ctk.CTkLabel(scroll, text="SERVER PATHS", font=("Arial",10,"bold"), text_color=C["text3"]).pack(anchor="w", pady=(20,8))
        for key,label,hint in [
            ("fxserver_exe","FXServer.exe","Full path to FXServer.exe — e.g. C:\\FXServer\\FXServer.exe"),
            ("server_data","Server Data Folder","Folder with server.cfg — e.g. C:\\FXServer\\server-data"),
            ("resources_path","Resources Folder","Resources folder — e.g. C:\\FXServer\\server-data\\resources"),
        ]:
            c = ctk.CTkFrame(scroll, fg_color=C["card2"], corner_radius=10, border_width=1, border_color=C["border"])
            c.pack(fill="x", pady=4)
            i = ctk.CTkFrame(c, fg_color="transparent"); i.pack(fill="x", padx=15, pady=12)
            ctk.CTkLabel(i, text=label, font=("Arial",12,"bold"), text_color=C["text"]).pack(anchor="w")
            ctk.CTkLabel(i, text=hint, font=("Arial",9), text_color=C["text3"]).pack(anchor="w")
            row = ctk.CTkFrame(i, fg_color="transparent"); row.pack(fill="x", pady=(6,0))
            e = ctk.CTkEntry(row, placeholder_text="Enter path...", height=34, corner_radius=8,
                fg_color=C["bg"], border_width=1, border_color=C["border"], font=("Arial",12))
            e.pack(side="left", fill="x", expand=True)
            if key in cfg: e.insert(0, cfg[key])
            self.entries[key] = e
            ctk.CTkButton(row, text="Browse", width=85, height=34, corner_radius=8,
                fg_color=C["card3"], hover_color=C["card2"],
                border_width=1, border_color=C["border"], font=("Arial",11),
                command=lambda k=key, en=e: self._browse(k, en)
            ).pack(side="left", padx=(5,0))

        btns_row = ctk.CTkFrame(scroll, fg_color="transparent")
        btns_row.pack(fill="x", pady=10)
        ctk.CTkButton(btns_row, text="💾  SAVE SETTINGS",
            font=("Arial",13,"bold"), fg_color=C["accent"], hover_color=C["accent_h"],
            height=48, corner_radius=12, command=self._save
        ).pack(side="left", fill="x", expand=True, padx=(0,6))
        ctk.CTkButton(btns_row, text="🔌 Test All Keys",
            font=("Arial",13,"bold"), fg_color=C["card2"], hover_color=C["card3"],
            border_width=1, border_color=C["border2"],
            height=48, corner_radius=12, command=self._test_keys
        ).pack(side="left", fill="x", expand=True)

        self.ok = ctk.CTkLabel(scroll, text="", font=("Arial",12), text_color=C["success"])
        self.ok.pack()

    def _test_keys(self):
        """Actually test each API key with a real minimal call"""
        self.ok.configure(text="🔌 Testing API keys...", text_color=C["warning"])
        keys = {k: e.get().strip() for k,e in self.entries.items() if k in {"claude","openai","grok","gemini","perplexity"}}

        def _run():
            results = []
            test_ai = AI(keys)

            if keys.get("claude"):
                r, err = test_ai.ask_claude("Reply with only: OK", "Reply with only: OK")
                results.append(f"Claude: {'✅' if r and 'OK' in r else '❌ '+str(err)[:40]}")

            if keys.get("openai"):
                r, err = test_ai.ask_gpt("Reply with only: OK", "Reply with only: OK")
                results.append(f"GPT-4o: {'✅' if r and 'OK' in r else '❌ '+str(err)[:40]}")

            if keys.get("grok"):
                r, err = test_ai.ask_grok("Reply with only: OK", "Reply with only: OK")
                results.append(f"Grok: {'✅' if r and 'OK' in r else '❌ '+str(err)[:40]}")

            if keys.get("gemini"):
                r, err = test_ai.ask_gemini("Reply with only: OK")
                results.append(f"Gemini: {'✅' if r else '❌ '+str(err)[:40]}")

            if keys.get("perplexity"):
                r, err = test_ai.ask_perplexity("Reply with only: OK", "Reply with only: OK")
                results.append(f"Perplexity: {'✅' if r else '❌ '+str(err)[:40]}")

            if not results:
                results = ["No API keys entered yet"]

            summary = "  |  ".join(results)
            all_ok = all("✅" in r for r in results) if results else False
            self.after(0, lambda: self.ok.configure(
                text=summary,
                text_color=C["success"] if all_ok else C["warning"]
            ))

        import threading
        threading.Thread(target=_run, daemon=True).start()

    def _browse(self, key, entry):
        path = (filedialog.askopenfilename(filetypes=[("EXE","*.exe"),("All","*.*")])
                if "exe" in key else filedialog.askdirectory())
        if path: entry.delete(0,"end"); entry.insert(0,path)

    def _save(self):
        key_names = {"claude","openai","grok","gemini","perplexity"}
        keys,cfg = {},{}
        for k,e in self.entries.items():
            v = e.get().strip()
            if k in key_names: keys[k] = v
            else: cfg[k] = v
        jsave(KEYS_FILE, keys); jsave(CFG_FILE, cfg)
        self.app.keys   = keys
        self.app.config = cfg
        self.app.ai     = AI(keys, self.app._log_cb)
        self.app.server = Server(cfg.get("fxserver_exe",""), cfg.get("server_data",""), self.app._srv_cb)
        self.app.writer = FileWriter(self.app._log_cb)
        self.ok.configure(text="✅ Settings saved — API clients reinitialised!")
        write_log("Settings saved")


# ══════════════════════════════════════════════════════
#  MAIN APP
# ══════════════════════════════════════════════════════
class NexusSuite(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("⬡ NEXUS SUITE — FiveM AI Dev Platform")
        self.geometry("1440x860"); self.minsize(1200,720)
        self.configure(fg_color=C["bg"])

        self.keys   = jload(KEYS_FILE, {})
        self.config = jload(CFG_FILE,  {})
        self.ctx    = {}

        self.ai     = AI(self.keys, self._log_cb)
        self.server = Server(self.config.get("fxserver_exe",""), self.config.get("server_data",""), self._srv_cb)
        self.writer = FileWriter(self._log_cb)

        self.pages  = {}; self.cur = None
        self.console_lines = []  # store all server console output
        self._build()
        self.sidebar.set_active("home")

        write_log(f"Nexus Suite started — keys configured: {[k for k in self.keys if self.keys.get(k,'').strip()]}")

    def _build(self):
        self.topbar = TopBar(self); self.topbar.pack(fill="x", side="top")
        body = ctk.CTkFrame(self, fg_color="transparent"); body.pack(fill="both", expand=True)
        self.sidebar = Sidebar(body, on_nav=self.navigate); self.sidebar.pack(side="left", fill="y")
        self.content = ctk.CTkFrame(body, fg_color=C["bg"], corner_radius=0)
        self.content.pack(side="right", fill="both", expand=True)
        self.pages = {
            "home":     HomePage(self.content, self),
            "ai":       AICorePage(self.content, self),
            "library":  LibraryPage(self.content, self),
            "webtools": WebToolsPage(self.content, self),
            "files":    FilesPage(self.content, self),
            "settings": SettingsPage(self.content, self),
        }

    def navigate(self, key):
        if self.cur: self.pages[self.cur].pack_forget()
        if key in self.pages: self.pages[key].pack(fill="both", expand=True)
        self.cur = key

    def _log_cb(self, agent, text):
        """Route AI/system log output to the currently visible page"""
        def _do():
            ai_page = self.pages.get("ai")
            if ai_page and hasattr(ai_page, "_log_live"):
                ai_page._log_live(agent, text)
        self.after(0, _do)

    def _srv_cb(self, agent, text):
        """Route server console output to AI page and console label"""
        def _do():
            # Always route to AI core live log
            ai_page = self.pages.get("ai")
            if ai_page and hasattr(ai_page, "_log_live"):
                ai_page._log_live(agent, text)
            # Update topbar server status on key events
            if "starting" in text.lower() or "running" in text.lower():
                self.topbar.set_server(True)
            elif "stopped" in text.lower() or "ended" in text.lower():
                self.topbar.set_server(False)
        self.after(0, _do)

if __name__ == "__main__":
    app = NexusSuite()
    app.mainloop()
