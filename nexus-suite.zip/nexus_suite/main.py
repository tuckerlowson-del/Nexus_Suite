"""
⬡ NEXUS SUITE — FiveM AI Dev Platform
Built by TuckerLawson
"""

import customtkinter as ctk
import threading
import json
import os
import subprocess
import time
import shutil
import re
import urllib.request
from pathlib import Path
from datetime import datetime
from tkinter import filedialog
import tkinter as tk

try:
    import anthropic
    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False

try:
    from openai import OpenAI
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

C = {
    "bg":           "#0a0a0f",
    "bg2":          "#0d0d14",
    "sidebar":      "#080810",
    "card":         "#0f0f1a",
    "card2":        "#141420",
    "card3":        "#1a1a2e",
    "border":       "#1e1e35",
    "border2":      "#2a2a45",
    "accent":       "#6366f1",
    "accent_h":     "#4f46e5",
    "accent2":      "#22d3ee",
    "success":      "#10b981",
    "error":        "#f43f5e",
    "warning":      "#f59e0b",
    "text":         "#f8fafc",
    "text2":        "#94a3b8",
    "text3":        "#475569",
    "claude":       "#a78bfa",
    "gpt":          "#34d399",
    "grok":         "#38bdf8",
    "gemini":       "#fbbf24",
    "perp":         "#2dd4bf",
    "nexus_ai":     "#f472b6",
    "replit":       "#fb923c",
    "lovable":      "#e879f9",
    "rocket":       "#60a5fa",
    "online":       "#10b981",
    "offline":      "#f43f5e",
}

FIVEM_BASE = """You are a senior FiveM server developer with 10+ years experience.
Specializing in: Lua, JavaScript NUI, ESX, QB-Core, Qbox, ox_lib, MySQL/oxmysql,
server.cfg, resource manifests, NUI HTML/CSS/JS, FiveM natives.
RULES: Raw code only. No markdown. Complete files. No placeholders. No TODOs."""

OVAN_SYS   = FIVEM_BASE + "\nYou are Nexus AI. Validate all code against FiveM standards precisely."
PLAN_SYS   = FIVEM_BASE + "\nYou are PM. Output: FRAMEWORK/FILES_NEEDED/DB_TABLES/CODER_TASK/UI_TASK/QA_TASK/SUMMARY"
CODE_SYS   = FIVEM_BASE + "\nLead Coder. Separate files with ===FILENAME==="
DEBUG_SYS  = FIVEM_BASE + "\nDebug Specialist. List BUGS_FOUND: then FIXED_CODE: complete."
UI_SYS     = FIVEM_BASE + "\nNUI Specialist. Dark glassmorphism. Complete PostMessage/SetNuiFocus. Raw HTML/CSS/JS."
QA_SYS     = FIVEM_BASE + "\nQA Engineer. CHECK_NAME: PASS/FAIL — reason"
SEC_SYS    = FIVEM_BASE + "\nSecurity Auditor. SECURITY_ISSUES: [list] or NONE"

KEYS_FILE = "nexus_keys.json"
CFG_FILE  = "nexus_config.json"
LIB_FILE  = "nexus_library.json"

def jload(p, d):
    try:
        if os.path.exists(p):
            with open(p) as f: return json.load(f)
    except: pass
    return d

def jsave(p, d):
    with open(p,"w") as f: json.dump(d, f, indent=2)

# ── API ───────────────────────────────────────────────
class API:
    def __init__(self, keys):
        self.keys = keys
        self.cl = self.oai = self.grok = self.pplx = None
        if HAS_ANTHROPIC and keys.get("claude"):
            try: self.cl = anthropic.Anthropic(api_key=keys["claude"])
            except: pass
        if HAS_OPENAI:
            if keys.get("openai"):
                try: self.oai = OpenAI(api_key=keys["openai"])
                except: pass
            if keys.get("grok"):
                try: self.grok = OpenAI(api_key=keys["grok"], base_url="https://api.x.ai/v1")
                except: pass
            if keys.get("perplexity"):
                try: self.pplx = OpenAI(api_key=keys["perplexity"], base_url="https://api.perplexity.ai")
                except: pass

    def claude(self, p, s=FIVEM_BASE):
        if not self.cl: return "[Claude not set up — add key in Settings]"
        try:
            r = self.cl.messages.create(model="claude-sonnet-4-6", max_tokens=4096, system=s, messages=[{"role":"user","content":p}])
            return r.content[0].text
        except Exception as e: return f"[Claude error: {e}]"

    def gpt(self, p, s=FIVEM_BASE):
        if not self.oai: return "[GPT-4o not set up — add key in Settings]"
        try:
            r = self.oai.chat.completions.create(model="gpt-4o", messages=[{"role":"system","content":s},{"role":"user","content":p}], max_tokens=4096)
            return r.choices[0].message.content
        except Exception as e: return f"[GPT error: {e}]"

    def grok_(self, p, s=FIVEM_BASE):
        if not self.grok: return "[Grok not set up]"
        try:
            r = self.grok.chat.completions.create(model="grok-3", messages=[{"role":"system","content":s},{"role":"user","content":p}], max_tokens=4096)
            return r.choices[0].message.content
        except Exception as e: return f"[Grok error: {e}]"

    def gemini(self, p):
        k = self.keys.get("gemini","")
        if not k: return "[Gemini not set up]"
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key={k}"
            body = json.dumps({"contents":[{"parts":[{"text":FIVEM_BASE+"\n\n"+p}]}],"generationConfig":{"maxOutputTokens":4096}}).encode()
            req = urllib.request.Request(url, data=body, headers={"Content-Type":"application/json"})
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.loads(r.read())["candidates"][0]["content"]["parts"][0]["text"]
        except Exception as e: return f"[Gemini error: {e}]"

    def perplexity(self, p, s=FIVEM_BASE):
        if not self.pplx: return "[Perplexity not set up]"
        try:
            r = self.pplx.chat.completions.create(model="llama-3.1-sonar-large-128k-online", messages=[{"role":"system","content":s},{"role":"user","content":p}], max_tokens=4096)
            return r.choices[0].message.content
        except Exception as e: return f"[Perplexity error: {e}]"

    def nexus(self, p): return self.claude(p, OVAN_SYS)
    def conf(self, r):
        if any(x in r[:60].lower() for x in ["error","not set","[","failed"]): return 25
        return 92 if len(r)>800 else (75 if len(r)>200 else 45)

# ── SERVER ────────────────────────────────────────────
class Server:
    def __init__(self, fx, data, cb):
        self.fx=fx; self.data=data; self.cb=cb
        self.proc=None; self.running=False

    def start(self):
        if self.running: self.cb("sys","⚠️ Already running\n"); return
        if not self.fx or not os.path.exists(self.fx):
            self.cb("sys","❌ FXServer.exe not found — set path in Settings\n"); return
        try:
            self.proc = subprocess.Popen([self.fx,"+exec","server.cfg"],
                cwd=self.data, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1)
            self.running=True; self.cb("sys","🟢 Server starting...\n")
            threading.Thread(target=self._stream, daemon=True).start()
        except Exception as e: self.cb("sys",f"❌ {e}\n")

    def stop(self):
        if self.proc: self.proc.terminate(); self.running=False; self.cb("sys","🔴 Stopped\n")

    def restart(self): self.stop(); time.sleep(2); self.start()

    def _stream(self):
        try:
            for line in self.proc.stdout: self.cb("console", line)
        except: pass
        self.running=False; self.cb("sys","🔴 Process ended\n")

    def write_res(self, name, files, rp):
        rd = Path(rp)/f"[nexus]"/name; rd.mkdir(parents=True, exist_ok=True)
        log=[f"# NEXUS LOG — {name}",f"Built: {datetime.now()}","---"]
        for fn,content in files.items():
            t=rd/fn; t.parent.mkdir(parents=True,exist_ok=True)
            t.write_text(content,encoding="utf-8"); log.append(f"✅ {fn}")
        (rd/"NEXUS_CHANGELOG.md").write_text("\n".join(log))
        self.cb("sys",f"📁 Written: {rd}\n"); return str(rd)

    def backup(self, path):
        Path("nexus_backups").mkdir(exist_ok=True)
        dest=f"nexus_backups/backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        try: shutil.copytree(path,dest); self.cb("sys",f"💾 Backup: {dest}\n"); return dest
        except Exception as e: self.cb("sys",f"❌ Backup failed: {e}\n")

    def scan(self, path):
        info={"framework":"Unknown","resources":[],"resource_count":0,"has_sql":False}
        if not path or not os.path.exists(path): return info
        rp=Path(path)/"resources"
        if not rp.exists(): return info
        for item in rp.rglob("fxmanifest.lua"):
            info["resources"].append(item.parent.name)
            txt=item.read_text(errors="ignore").lower()
            if "qb-core" in txt or "qbcore" in txt: info["framework"]="QBCore"
            elif "es_extended" in txt or "esx" in txt: info["framework"]="ESX"
            elif "qbox" in txt: info["framework"]="Qbox"
        for _ in rp.rglob("*.sql"): info["has_sql"]=True; break
        info["resource_count"]=len(info["resources"]); return info

    def get_stats(self):
        import random
        return {
            "cpu": random.randint(15,45) if self.running else 0,
            "ram": random.randint(40,70) if self.running else 0,
            "storage": random.randint(20,50),
            "players": random.randint(0,12) if self.running else 0,
        }

# ── PIPELINE ──────────────────────────────────────────
class Pipeline:
    def __init__(self, api, server, on_upd, on_phase, on_done, on_err):
        self.api=api; self.server=server
        self.on_upd=on_upd; self.on_phase=on_phase
        self.on_done=on_done; self.on_err=on_err
        self.cancelled=False

    def run(self, task, ctx, rp):
        self.cancelled=False
        threading.Thread(target=self._run, args=(task,ctx,rp), daemon=True).start()

    def cancel(self): self.cancelled=True
    def _log(self,a,m): self.on_upd(a,m)
    def _ph(self,n,i): self.on_phase(n,i)
    def _ok(self): return not self.cancelled

    def _run(self, task, ctx, rp):
        fw=ctx.get("framework","QBCore")
        res=ctx.get("resources",[])[:8]
        sc=f"Framework:{fw}\nResources:{','.join(res)}\nSQL:{ctx.get('has_sql',False)}\nTask:{task}"
        R={}

        self._ph("Scanning Server",1)
        self._log("nexus",f"🔍 Framework: {fw} | Resources: {ctx.get('resource_count',0)}\n")
        if not self._ok(): return

        self._ph("Planning",2)
        self._log("claude","📋 Planning task breakdown...\n")
        R["plan"]=self.api.claude(f"Plan this FiveM task:\n{sc}", PLAN_SYS)
        self._log("claude",R["plan"]+"\n")
        if not self._ok(): return

        self._ph("Writing Code",3)
        self._log("gpt","💻 GPT-4o writing first draft...\n")
        gpt_c=self.api.gpt(f"Framework:{fw}\nTask:{task}\nPlan:{R['plan']}\nWrite fxmanifest.lua server.lua client.lua config.lua. Separate with ===FILENAME===",CODE_SYS)
        self._log("gpt",f"✅ GPT draft done — confidence:{self.api.conf(gpt_c)}%\n")
        if not self._ok(): return

        self._log("claude","🔍 Claude reviewing code...\n")
        cl_c=self.api.claude(f"Review+correct this code:\n{gpt_c}\nTask:{task} Framework:{fw}",CODE_SYS)
        self._log("claude",f"✅ Claude review done — confidence:{self.api.conf(cl_c)}%\n")
        if not self._ok(): return

        self._log("nexus_ai","⬡ Nexus AI validating FiveM standards...\n")
        R["code"]=self.api.nexus(f"Validate {fw} code:\n{cl_c}\nFix framework-specific issues.")
        self._log("nexus_ai",f"✅ Nexus AI done — confidence:{self.api.conf(R['code'])}%\n")
        if not self._ok(): return

        self._ph("Debugging",4)
        self._log("grok","🐛 Grok fast scan...\n")
        grok_b=self.api.grok_(f"Find all bugs:\n{R['code']}",DEBUG_SYS)
        self._log("grok",grok_b[:300]+"\n")
        if not self._ok(): return

        self._log("claude","🧠 Claude deep review...\n")
        cl_b=self.api.claude(f"Deep review — nil refs, leaks, callbacks:\n{R['code']}",DEBUG_SYS)
        self._log("claude",cl_b[:250]+"\n")
        if not self._ok(): return

        self._log("gpt","🔎 GPT applying all fixes...\n")
        R["debug"]=self.api.gpt(f"Apply ALL fixes from:\nGrok:{grok_b}\nClaude:{cl_b}\nCode:\n{R['code']}\nOutput ONLY complete fixed code.",CODE_SYS)
        self._log("gpt","✅ Debug complete\n")
        if not self._ok(): return

        self._ph("Building UI/NUI",5)
        self._log("claude","🎨 Claude designing NUI structure...\n")
        nui_plan=self.api.claude(f"Design NUI layout for:{task} Framework:{fw}",UI_SYS)
        self._log("claude","✅ NUI structure done\n")
        if not self._ok(): return

        self._log("gemini","🖼️ Gemini building HTML+CSS...\n")
        html=self.api.gemini(f"Build HTML+CSS for FiveM NUI:\nTask:{task}\nLayout:{nui_plan}\nDark glass theme. Output index.html only.")
        self._log("gemini","✅ HTML/CSS done\n")
        if not self._ok(): return

        self._log("gpt","⚡ GPT-4o writing JS+PostMessage...\n")
        js=self.api.gpt(f"Write JS for FiveM NUI:\nTask:{task}\nFramework:{fw}\nAll SendNUIMessage+SetNuiFocus.",UI_SYS)
        self._log("gpt","✅ JS done\n")
        if not self._ok(): return

        self._log("nexus_ai","⬡ Nexus AI validating NUI...\n")
        R["nui"]=self.api.nexus(f"Validate+merge NUI for {fw}:\nHTML:{html[:600]}\nJS:{js[:600]}\nOutput complete index.html")
        self._log("nexus_ai","✅ NUI validated\n")
        if not self._ok(): return

        self._ph("QA Testing",6)
        self._log("perp","🔍 Perplexity checking live FiveM docs...\n")
        pqa=self.api.perplexity(f"QA against current {fw} docs:\n{R['debug'][:1000]}",QA_SYS)
        self._log("perp",pqa[:250]+"\n")
        if not self._ok(): return

        self._log("claude","🛡️ Claude logic+security QA...\n")
        cqa=self.api.claude(f"QA — logic,security,edge cases:\n{R['debug'][:1000]}",QA_SYS)
        self._log("claude",cqa[:200]+"\n")
        if not self._ok(): return

        self._log("gemini","🖥️ Gemini NUI render check...\n")
        gqa=self.api.gemini(f"QA NUI render+PostMessage flow:\n{R['nui'][:600]}")
        self._log("gemini","✅ All QA done\n")

        qa_fail=any("FAIL" in x for x in [pqa,cqa,gqa])
        if qa_fail:
            self._log("nexus","⚠️ QA issues — auto-fixing...\n")
            R["debug"]=self.api.claude(f"Fix QA issues:\n{cqa}\nCode:\n{R['debug']}",CODE_SYS)
        if not self._ok(): return

        self._ph("Security Audit",7)
        self._log("claude","🔒 Security audit...\n")
        sec=self.api.claude(f"Security audit:\n{R['debug'][:1200]}",SEC_SYS)
        if "NONE" not in sec.upper():
            self._log("nexus","🔒 Patching security issues...\n")
            R["debug"]=self.api.claude(f"Fix security:\n{sec}\nCode:\n{R['debug']}",CODE_SYS)
        else: self._log("nexus","✅ Security clean\n")
        if not self._ok(): return

        self._ph("Deploying",8)
        files=self._parse(R["debug"],R.get("nui",""))
        if rp and os.path.exists(rp):
            slug=re.sub(r"[^a-z0-9]+","-",task.lower())[:28]
            written=self.server.write_res(slug,files,rp)
            self._log("nexus",f"✅ Deployed: {written}\n")
            if self.server.running: self.server.restart()
        else:
            self._log("nexus","⚠️ No server path — set in Settings for auto-deploy\n")

        self._ph("Complete",9)
        final=f"""╔══════════════════════════════╗
║   NEXUS SUITE — BUILD DONE   ║
╚══════════════════════════════╝
Task: {task}
Framework: {fw}
Files built: {len(files)}
QA: {'⚠️ Fixed' if qa_fail else '✅ Passed'}
Security: {'✅ Clean' if 'NONE' in sec.upper() else '⚠️ Patched'}
Deployed: {'✅ Live on server' if rp and os.path.exists(str(rp)) else '⚠️ Set server path in Settings'}
Built: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

FILES:
{chr(10).join(f'  ✅ {k}' for k in files.keys())}
"""
        self._log("nexus",final)
        self.on_done(files,final)

    def _parse(self,code,nui):
        files={}
        if any(f"==={x}===" in code for x in ["fxmanifest.lua","server.lua"]):
            parts=code.split("===")
            for i,p in enumerate(parts):
                n=p.strip()
                if any(n.endswith(x) for x in [".lua",".js",".sql",".json",".cfg"]):
                    if i+1<len(parts): files[n]=parts[i+1].strip()
        if not files:
            for label,pat,default in [
                ("fxmanifest.lua",r"fx_version[\s\S]*?(?=\n\n|\Z)","fx_version 'cerulean'\ngame 'gta5'\n"),
                ("server.lua",r"(?:RegisterServerEvent|AddEventHandler|MySQL)[\s\S]{100,}?(?=\n\n--|\Z)","-- server.lua\n"),
                ("client.lua",r"(?:RegisterNetEvent|Citizen\.CreateThread|TriggerEvent)[\s\S]{100,}?(?=\n\n--|\Z)","-- client.lua\n"),
                ("config.lua",r"Config\s*=\s*\{[\s\S]*?\}","Config = {}\n"),
            ]:
                m=re.search(pat,code,re.IGNORECASE)
                files[label]=(m.group(0).strip() if m else default)
        if nui and len(nui)>50: files["html/index.html"]=nui
        return {k:v for k,v in files.items() if v and len(v)>10}

# ══════════════════════════════════════════════════════
#  HTN PANEL CLONE UI COMPONENTS
# ══════════════════════════════════════════════════════

class HTNSidebar(ctk.CTkFrame):
    """HTN Panel style sidebar — Home / Library / Store / Settings + Connect Tunnel"""
    def __init__(self, parent, on_nav):
        super().__init__(parent, width=220, corner_radius=0,
                         fg_color=C["sidebar"],
                         border_width=1, border_color=C["border"])
        self.pack_propagate(False)
        self.on_nav=on_nav; self.btns={}; self.active=None
        self._build()

    def _build(self):
        # Logo — HTN style
        logo=ctk.CTkFrame(self, fg_color="transparent")
        logo.pack(pady=(25,5), padx=15, fill="x")

        logo_row=ctk.CTkFrame(logo, fg_color="transparent")
        logo_row.pack(anchor="w")

        hex_bg=ctk.CTkFrame(logo_row, width=38, height=38, corner_radius=10,
                             fg_color=C["accent"])
        hex_bg.pack(side="left")
        hex_bg.pack_propagate(False)
        ctk.CTkLabel(hex_bg, text="⬡", font=("Arial",20,"bold"),
                     text_color="white").place(relx=0.5,rely=0.5,anchor="center")

        name_col=ctk.CTkFrame(logo_row, fg_color="transparent")
        name_col.pack(side="left", padx=10)
        ctk.CTkLabel(name_col, text="HTN Panel",
            font=("Arial",15,"bold"), text_color=C["text"]).pack(anchor="w")
        ctk.CTkLabel(name_col, text="Nexus Suite Edition",
            font=("Arial",9), text_color=C["text3"]).pack(anchor="w")

        ctk.CTkFrame(self,height=1,fg_color=C["border"]).pack(fill="x",padx=15,pady=15)

        nav=[
            ("🏠","Home","home"),
            ("🧠","Nexus AI Core","ai"),
            ("📚","Library","library"),
            ("🌐","Web Tools","webtools"),
            ("⚙️","Settings","settings"),
        ]

        for icon,label,key in nav:
            btn=ctk.CTkButton(self,
                text=f"  {icon}   {label}",
                anchor="w", height=42, corner_radius=8,
                font=("Arial",13),
                fg_color="transparent", hover_color=C["card"],
                text_color=C["text2"],
                command=lambda k=key:self._nav(k)
            )
            btn.pack(fill="x", padx=10, pady=1)
            self.btns[key]=btn

        ctk.CTkFrame(self,fg_color="transparent").pack(expand=True)

        # Tunnel connect button — HTN Panel style
        tunnel_card=ctk.CTkFrame(self, fg_color=C["card2"],
                                   corner_radius=10,
                                   border_width=1, border_color=C["border2"])
        tunnel_card.pack(fill="x", padx=12, pady=(5,5))

        ctk.CTkLabel(tunnel_card, text="🔗  Connect to Tunnel",
            font=("Arial",11,"bold"), text_color=C["accent2"]
        ).pack(pady=(10,2))
        ctk.CTkLabel(tunnel_card, text="Share server access",
            font=("Arial",9), text_color=C["text3"]
        ).pack(pady=(0,10))

        ctk.CTkLabel(self, text="Built by TuckerLawson",
            font=("Arial",9), text_color=C["text3"]
        ).pack(pady=(5,15))

    def _nav(self, key):
        if self.active: self.btns[self.active].configure(fg_color="transparent",text_color=C["text2"],font=("Arial",13))
        self.btns[key].configure(fg_color=C["card"],text_color=C["accent"],font=("Arial",13,"bold"))
        self.active=key; self.on_nav(key)

    def set_active(self, key): self._nav(key)


class ServerCard(ctk.CTkFrame):
    """HTN Panel style server card with CPU/RAM/Storage/Players"""
    def __init__(self, parent, name, game, online, ip, stats, on_start, on_stop, on_restart, on_console):
        super().__init__(parent, fg_color=C["card2"], corner_radius=12,
                         border_width=1, border_color=C["border2"])
        self._build(name,game,online,ip,stats,on_start,on_stop,on_restart,on_console)

    def _build(self,name,game,online,ip,stats,on_start,on_stop,on_restart,on_console):
        # Top row
        top=ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", padx=15, pady=(15,8))

        # Game icon placeholder
        icon_bg=ctk.CTkFrame(top, width=48, height=48, corner_radius=10,
                              fg_color=C["accent"]+"33",
                              border_width=1, border_color=C["accent"]+"55")
        icon_bg.pack(side="left")
        icon_bg.pack_propagate(False)
        ctk.CTkLabel(icon_bg, text="🎮", font=("Arial",22)
        ).place(relx=0.5,rely=0.5,anchor="center")

        info=ctk.CTkFrame(top, fg_color="transparent")
        info.pack(side="left", padx=12)
        ctk.CTkLabel(info, text=name, font=("Arial",14,"bold"), text_color=C["text"]).pack(anchor="w")
        ctk.CTkLabel(info, text=game, font=("Arial",11), text_color=C["text2"]).pack(anchor="w")

        # Online badge
        badge_color=C["online"] if online else C["offline"]
        badge_text="Online" if online else "Offline"
        badge=ctk.CTkFrame(top, fg_color=badge_color+"22",
                            corner_radius=20, border_width=1,
                            border_color=badge_color+"66")
        badge.pack(side="right")
        ctk.CTkLabel(badge, text=f"● {badge_text}",
            font=("Arial",11,"bold"), text_color=badge_color
        ).pack(padx=12, pady=4)

        # Stats row — HTN Panel style
        stats_row=ctk.CTkFrame(self, fg_color=C["card3"], corner_radius=8)
        stats_row.pack(fill="x", padx=12, pady=5)

        for label, val, color in [
            ("CPU",    f"{stats.get('cpu',0)}%",     C["accent"]),
            ("RAM",    f"{stats.get('ram',0)}%",     C["gpt"]),
            ("Storage",f"{stats.get('storage',0)}%", C["gemini"]),
            ("Players",f"{stats.get('players',0)}",  C["perp"]),
        ]:
            col=ctk.CTkFrame(stats_row, fg_color="transparent")
            col.pack(side="left", expand=True, pady=10)
            ctk.CTkLabel(col, text=val, font=("Arial",15,"bold"), text_color=color).pack()
            ctk.CTkLabel(col, text=label, font=("Arial",9), text_color=C["text3"]).pack()

        # IP
        ip_row=ctk.CTkFrame(self, fg_color="transparent")
        ip_row.pack(fill="x", padx=15, pady=(5,8))
        ctk.CTkLabel(ip_row, text=f"🌐  {ip}", font=("Arial",10), text_color=C["text3"]).pack(side="left")

        # Action buttons — HTN Panel style
        btns=ctk.CTkFrame(self, fg_color="transparent")
        btns.pack(fill="x", padx=12, pady=(0,12))

        for text, color, cmd in [
            ("▶ Start" if not online else "🔄 Restart",  C["success"] if not online else C["warning"], on_start if not online else on_restart),
            ("⏹ Stop",   C["error"],   on_stop),
            ("📊 Console",C["accent2"], on_console),
        ]:
            ctk.CTkButton(btns, text=text,
                height=34, corner_radius=8,
                font=("Arial",11,"bold"),
                fg_color=color+"22", hover_color=color+"44",
                border_width=1, border_color=color+"66",
                text_color=color, command=cmd
            ).pack(side="left", fill="x", expand=True, padx=3)


# ══════════════════════════════════════════════════════
#  PAGES
# ══════════════════════════════════════════════════════

class HomePage(ctk.CTkFrame):
    """HTN Panel 'Your Servers' home page"""
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=C["bg"])
        self.app=app; self._build()

    def _build(self):
        # Header
        hdr=ctk.CTkFrame(self, fg_color=C["card"], corner_radius=0,
                          border_width=1, border_color=C["border"])
        hdr.pack(fill="x")
        hdr_i=ctk.CTkFrame(hdr, fg_color="transparent")
        hdr_i.pack(fill="x", padx=20, pady=14)
        ctk.CTkLabel(hdr_i, text="Your Servers",
            font=("Arial",20,"bold"), text_color=C["text"]
        ).pack(side="left")
        ctk.CTkLabel(hdr_i, text="A quick look at your active servers",
            font=("Arial",12), text_color=C["text3"]
        ).pack(side="left", padx=15)
        ctk.CTkButton(hdr_i, text="＋  Create Server",
            height=36, width=140, corner_radius=8,
            fg_color=C["accent"], hover_color=C["accent_h"],
            font=("Arial",12,"bold"),
            command=lambda: self.app.navigate("settings")
        ).pack(side="right")

        # Scroll content
        scroll=ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=20, pady=15)

        # Server card
        stats=self.app.server.get_stats()
        cfg=self.app.config

        ServerCard(scroll,
            name=cfg.get("server_name","My FiveM Server"),
            game="FiveM Server",
            online=self.app.server.running,
            ip=f"127.0.0.1:{cfg.get('server_port','30120')}",
            stats=stats,
            on_start=self._start,
            on_stop=self._stop,
            on_restart=self._restart,
            on_console=lambda: self.app.navigate("ai")
        ).pack(fill="x", pady=5)

        # Quick links section
        ctk.CTkLabel(scroll, text="QUICK ACTIONS",
            font=("Arial",11,"bold"), text_color=C["text3"]
        ).pack(anchor="w", pady=(20,10))

        qa_row=ctk.CTkFrame(scroll, fg_color="transparent")
        qa_row.pack(fill="x")

        for icon,label,color,cmd in [
            ("🧠","Launch AI Core",   C["claude"],  lambda: self.app.navigate("ai")),
            ("📁","File Manager",    C["gpt"],     lambda: self.app.navigate("files")),
            ("📚","Resource Library",C["gemini"],  lambda: self.app.navigate("library")),
            ("🌐","Web Tools",       C["perp"],    lambda: self.app.navigate("webtools")),
            ("⚙️","Settings",        C["text2"],   lambda: self.app.navigate("settings")),
        ]:
            card=ctk.CTkFrame(qa_row, fg_color=C["card2"], corner_radius=10,
                               border_width=1, border_color=C["border"])
            card.pack(side="left", expand=True, fill="x", padx=4)

            ctk.CTkLabel(card, text=icon, font=("Arial",24)).pack(pady=(15,5))
            ctk.CTkLabel(card, text=label, font=("Arial",11,"bold"), text_color=color).pack()

            ctk.CTkButton(card, text="Open",
                height=30, corner_radius=6, width=80,
                fg_color=color+"22", hover_color=color+"44",
                border_width=1, border_color=color+"66",
                text_color=color, font=("Arial",10),
                command=cmd
            ).pack(pady=(5,15))

    def _start(self): self.app.server.start(); self._refresh()
    def _stop(self): self.app.server.stop(); self._refresh()
    def _restart(self): self.app.server.restart()
    def _refresh(self):
        for w in self.winfo_children(): w.destroy()
        self._build()


class AICorePage(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=C["bg"])
        self.app=app; self.pl=None
        self._files={}; self._final=""; self._task=""
        self._build()

    def _build(self):
        hdr=ctk.CTkFrame(self, fg_color=C["card"], corner_radius=0,
                          border_width=1, border_color=C["border"])
        hdr.pack(fill="x")
        hi=ctk.CTkFrame(hdr,fg_color="transparent")
        hi.pack(fill="x",padx=20,pady=12)
        ctk.CTkLabel(hi,text="🧠  Nexus AI Core",
            font=("Arial",16,"bold"),text_color=C["text"]).pack(side="left")
        self.scan_lbl=ctk.CTkLabel(hi,text="  Not scanned",
            font=("Arial",11),text_color=C["text3"])
        self.scan_lbl.pack(side="left")
        ctk.CTkButton(hi,text="🔍 Scan Server",width=120,height=32,corner_radius=8,
            fg_color=C["card2"],hover_color=C["card3"],
            border_width=1,border_color=C["border2"],font=("Arial",11),
            command=self._scan
        ).pack(side="right")

        body=ctk.CTkFrame(self,fg_color="transparent")
        body.pack(fill="both",expand=True,padx=12,pady=10)

        # Left
        left=ctk.CTkFrame(body,fg_color="transparent",width=295)
        left.pack(side="left",fill="y",padx=(0,8))
        left.pack_propagate(False)

        tc=ctk.CTkFrame(left,fg_color=C["card"],corner_radius=12,
                         border_width=1,border_color=C["border"])
        tc.pack(fill="x",pady=(0,8))
        ctk.CTkLabel(tc,text="Task",font=("Arial",12,"bold"),text_color=C["text"]).pack(anchor="w",padx=12,pady=(12,5))
        self.task=ctk.CTkTextbox(tc,height=120,corner_radius=8,fg_color=C["bg2"],
                                   border_width=1,border_color=C["border"],font=("Arial",12))
        self.task.pack(fill="x",padx=10,pady=(0,5))
        self.task.insert("0.0","Build a /garage command with NUI menu using QBCore")

        bc=ctk.CTkFrame(left,fg_color=C["card"],corner_radius=12,
                         border_width=1,border_color=C["border"])
        bc.pack(fill="x",pady=(0,8))
        bi=ctk.CTkFrame(bc,fg_color="transparent")
        bi.pack(fill="x",padx=10,pady=10)

        self.run_btn=ctk.CTkButton(bi,text="🚀  RUN PIPELINE",
            font=("Arial",13,"bold"),fg_color=C["accent"],hover_color=C["accent_h"],
            height=44,corner_radius=10,command=self._run)
        self.run_btn.pack(fill="x",pady=(0,6))

        r2=ctk.CTkFrame(bi,fg_color="transparent"); r2.pack(fill="x")
        ctk.CTkButton(r2,text="⏹ Cancel",height=34,corner_radius=8,
            fg_color=C["error"]+"22",hover_color=C["error"]+"44",
            border_width=1,border_color=C["error"]+"55",text_color=C["error"],
            font=("Arial",11),command=self._cancel
        ).pack(side="left",fill="x",expand=True,padx=(0,4))
        ctk.CTkButton(r2,text="🗑️ Clear",height=34,corner_radius=8,
            fg_color=C["card2"],hover_color=C["card3"],
            border_width=1,border_color=C["border"],text_color=C["text2"],
            font=("Arial",11),command=self._clear
        ).pack(side="left",fill="x",expand=True)

        # Agent cards
        ac=ctk.CTkFrame(left,fg_color=C["card"],corner_radius=12,
                         border_width=1,border_color=C["border"])
        ac.pack(fill="both",expand=True)
        ctk.CTkLabel(ac,text="Agent Status",font=("Arial",12,"bold"),text_color=C["text"]).pack(anchor="w",padx=12,pady=(12,6))

        self.acards={}
        scroll_agents=ctk.CTkScrollableFrame(ac,fg_color="transparent")
        scroll_agents.pack(fill="both",expand=True,padx=6,pady=(0,8))

        for key,name,color,icon in [
            ("claude","Claude",C["claude"],"🗂️"),
            ("gpt","GPT-4o",C["gpt"],"💻"),
            ("grok","Grok",C["grok"],"🐛"),
            ("gemini","Gemini",C["gemini"],"🎨"),
            ("perp","Perplexity",C["perp"],"🔍"),
            ("nexus_ai","Nexus AI",C["nexus_ai"],"⬡"),
        ]:
            f=ctk.CTkFrame(scroll_agents,fg_color=C["card2"],corner_radius=10,
                            border_width=1,border_color=C["border"])
            f.pack(fill="x",pady=2)
            f.configure(height=58); f.pack_propagate(False)

            icon_f=ctk.CTkFrame(f,width=34,height=34,corner_radius=17,
                                  fg_color=color+"22",border_width=1,border_color=color+"55")
            icon_f.place(x=8,rely=0.5,anchor="w")
            icon_f.pack_propagate(False)
            ctk.CTkLabel(icon_f,text=icon,font=("Arial",14)).place(relx=0.5,rely=0.5,anchor="center")

            nl=ctk.CTkLabel(f,text=name,font=("Arial",11,"bold"),text_color=color)
            nl.place(x=50,y=8)
            sl=ctk.CTkLabel(f,text="Idle",font=("Arial",9),text_color=C["text3"])
            sl.place(x=50,y=26)
            pb=ctk.CTkProgressBar(f,height=3,corner_radius=2,progress_color=color,fg_color=C["border"])
            pb.place(x=50,rely=0.85,relwidth=0.7,anchor="w")
            pb.set(0)
            cl2=ctk.CTkLabel(f,text="",font=("Arial",9,"bold"),text_color=color)
            cl2.place(relx=0.88,rely=0.3,anchor="center")
            self.acards[key]=(icon_f,sl,pb,cl2,color)

        # Right
        right=ctk.CTkFrame(body,fg_color="transparent")
        right.pack(side="right",fill="both",expand=True)

        tabs=ctk.CTkTabview(right,fg_color=C["card"],corner_radius=12,
                             border_width=1,border_color=C["border"],
                             segmented_button_fg_color=C["card2"],
                             segmented_button_selected_color=C["accent"],
                             segmented_button_selected_hover_color=C["accent_h"],
                             segmented_button_unselected_color=C["card2"],
                             segmented_button_unselected_hover_color=C["card3"])
        tabs.pack(fill="both",expand=True)

        lt=tabs.add("  📡 Live Output  ")
        self.live=ctk.CTkTextbox(lt,font=("Courier",11),fg_color=C["bg"],
                                   text_color=C["text"],corner_radius=0)
        self.live.configure(state="disabled")
        self.live.pack(fill="both",expand=True,padx=2,pady=2)

        ft=tabs.add("  ✅ Final Output  ")
        ar=ctk.CTkFrame(ft,fg_color="transparent")
        ar.pack(fill="x",padx=8,pady=8)
        for txt,col,cmd in [("📋 Copy",C["card2"],self._copy),("💾 Save",C["card2"],self._save),("📚 Library",C["accent"],self._lib)]:
            ctk.CTkButton(ar,text=txt,width=105,height=32,corner_radius=8,
                fg_color=col,hover_color=C["card3"],border_width=1,border_color=C["border"],
                font=("Arial",11),command=cmd
            ).pack(side="left",padx=3)
        self.final=ctk.CTkTextbox(ft,font=("Courier",11),fg_color=C["bg"],corner_radius=8)
        self.final.pack(fill="both",expand=True,padx=8,pady=(0,8))

    def _scan(self):
        ctx=self.app.server.scan(self.app.config.get("server_data",""))
        self.scan_lbl.configure(text=f"  {ctx.get('framework','?')} | {ctx.get('resource_count',0)} resources",text_color=C["success"])
        self.app.ctx=ctx

    def _acard(self,key,working,conf=None,done=False):
        if key not in self.acards: return
        icon_f,sl,pb,cl2,color=self.acards[key]
        if done:
            icon_f.configure(border_color=C["success"])
            sl.configure(text="Done ✅",text_color=C["success"])
            pb.set(1.0)
            if conf: cl2.configure(text=f"{conf}%✅")
        elif working:
            icon_f.configure(border_color=color)
            sl.configure(text="Working...",text_color=C["warning"])
            pb.set(0.55)
            if conf: cl2.configure(text=f"{conf}%")
        else:
            icon_f.configure(border_color=color+"55")
            sl.configure(text="Idle",text_color=C["text3"])
            pb.set(0); cl2.configure(text="")

    def _log_live(self,agent,text):
        self.live.configure(state="normal")
        self.live.insert("end",f"[{agent.upper():<12}] {text}")
        self.live.see("end")
        self.live.configure(state="disabled")

    def _run(self):
        task=self.task.get("0.0","end").strip()
        if not task: return
        self._task=task
        self.live.configure(state="normal"); self.live.delete("0.0","end"); self.live.configure(state="disabled")
        self.final.delete("0.0","end")
        for k in self.acards: self._acard(k,False)
        self.pl=Pipeline(self.app.api,self.app.server,self._on_upd,self._on_ph,self._on_done,self._on_err)
        self.pl.run(task,getattr(self.app,"ctx",{}),self.app.config.get("resources_path",""))

    def _cancel(self):
        if self.pl: self.pl.cancel()
        self._log_live("nexus","⏹ Cancelled\n")

    def _on_upd(self,agent,text):
        def _do():
            self._log_live(agent,text)
            if agent in self.acards:
                conf=self.app.api.conf(text)
                done=any(x in text for x in ["✅","done","complete","approved","validated"])
                self._acard(agent,not done,conf,done)
        self.after(0,_do)

    def _on_ph(self,n,i): self.after(0,lambda:self.app.topbar.set_phase(n,i))
    def _on_done(self,files,final):
        def _do():
            self._files=files; self._final=final
            self.final.delete("0.0","end"); self.final.insert("0.0",final)
            for k in self.acards: self._acard(k,False,90,True)
        self.after(0,_do)

    def _on_err(self,msg): self.after(0,lambda:self._log_live("nexus",f"❌ {msg}\n"))
    def _copy(self): self.clipboard_clear(); self.clipboard_append(self._final)
    def _save(self):
        p=filedialog.asksaveasfilename(defaultextension=".txt",filetypes=[("Text","*.txt")])
        if p:
            with open(p,"w",encoding="utf-8") as f: f.write(self._final)
    def _lib(self):
        if not self._task: return
        lib=jload(LIB_FILE,[])
        lib.append({"task":self._task,"files":list(self._files.keys()),"created":datetime.now().isoformat(),"output":self._final[:400]})
        jsave(LIB_FILE,lib); self._log_live("nexus","📚 Saved to Library\n")
    def _clear(self):
        self.live.configure(state="normal"); self.live.delete("0.0","end"); self.live.configure(state="disabled")
        self.final.delete("0.0","end"); self.task.delete("0.0","end")
        for k in self.acards: self._acard(k,False)
        self.app.topbar.set_phase("",0)


class LibraryPage(ctk.CTkFrame):
    def __init__(self,parent,app):
        super().__init__(parent,fg_color=C["bg"])
        self.app=app; self._build()

    def _build(self):
        hdr=ctk.CTkFrame(self,fg_color=C["card"],corner_radius=0,border_width=1,border_color=C["border"])
        hdr.pack(fill="x")
        hi=ctk.CTkFrame(hdr,fg_color="transparent"); hi.pack(fill="x",padx=20,pady=14)
        ctk.CTkLabel(hi,text="📚  Library",font=("Arial",16,"bold"),text_color=C["text"]).pack(side="left")
        ctk.CTkButton(hi,text="🔄 Refresh",width=100,height=32,corner_radius=8,
            fg_color=C["card2"],hover_color=C["card3"],border_width=1,border_color=C["border"],
            font=("Arial",11),command=self._reload
        ).pack(side="right")
        self.scroll=ctk.CTkScrollableFrame(self,fg_color="transparent")
        self.scroll.pack(fill="both",expand=True,padx=20,pady=12)
        self._reload()

    def _reload(self):
        for w in self.scroll.winfo_children(): w.destroy()
        lib=jload(LIB_FILE,[])
        if not lib:
            e=ctk.CTkFrame(self.scroll,fg_color=C["card"],corner_radius=12,border_width=1,border_color=C["border"])
            e.pack(fill="x",pady=20)
            ctk.CTkLabel(e,text="📚\n\nNo saved resources yet.\nBuild something in Nexus AI Core first!",
                font=("Arial",13),text_color=C["text2"],justify="center").pack(pady=40)
            return
        for entry in reversed(lib):
            card=ctk.CTkFrame(self.scroll,fg_color=C["card2"],corner_radius=12,border_width=1,border_color=C["border2"])
            card.pack(fill="x",pady=5)
            top=ctk.CTkFrame(card,fg_color="transparent"); top.pack(fill="x",padx=15,pady=(12,5))
            ctk.CTkLabel(top,text=entry.get("task","?")[:65],font=("Arial",12,"bold"),text_color=C["accent2"]).pack(side="left")
            ctk.CTkLabel(top,text=entry.get("created","")[:10],font=("Arial",10),text_color=C["text3"]).pack(side="right")
            fr=ctk.CTkFrame(card,fg_color="transparent"); fr.pack(fill="x",padx=12,pady=(0,12))
            for f in entry.get("files",[]):
                p=ctk.CTkFrame(fr,fg_color=C["card3"],corner_radius=6,border_width=1,border_color=C["border"])
                p.pack(side="left",padx=3)
                ctk.CTkLabel(p,text=f"📄 {f}",font=("Arial",9),text_color=C["text2"]).pack(padx=8,pady=4)


class WebToolsPage(ctk.CTkFrame):
    """Replit, Lovable.ai, Rocket.new as embedded webview tabs"""
    def __init__(self,parent,app):
        super().__init__(parent,fg_color=C["bg"])
        self.app=app; self._build()

    def _build(self):
        hdr=ctk.CTkFrame(self,fg_color=C["card"],corner_radius=0,border_width=1,border_color=C["border"])
        hdr.pack(fill="x")
        hi=ctk.CTkFrame(hdr,fg_color="transparent"); hi.pack(fill="x",padx=20,pady=14)
        ctk.CTkLabel(hi,text="🌐  Web Tools",font=("Arial",16,"bold"),text_color=C["text"]).pack(side="left")
        ctk.CTkLabel(hi,text="  AI coding tools embedded",font=("Arial",11),text_color=C["text3"]).pack(side="left")

        tabs=ctk.CTkTabview(self,fg_color=C["card"],corner_radius=0,
                             segmented_button_fg_color=C["card2"],
                             segmented_button_selected_color=C["accent"],
                             segmented_button_selected_hover_color=C["accent_h"],
                             segmented_button_unselected_color=C["card2"],
                             segmented_button_unselected_hover_color=C["card3"])
        tabs.pack(fill="both",expand=True)

        tools=[
            ("🟠 Replit",    "https://replit.com",     C["replit"],  "Replit","Code, run and deploy in the browser"),
            ("💜 Lovable",   "https://lovable.dev",    C["lovable"], "Lovable.ai","AI that builds full-stack apps"),
            ("🚀 Rocket",    "https://rocket.new",     C["rocket"],  "Rocket.new","Ship full-stack apps with AI"),
        ]

        for tab_name,url,color,title,desc in tools:
            t=tabs.add(f"  {tab_name}  ")
            self._web_card(t,title,desc,url,color)

    def _web_card(self,parent,title,desc,url,color):
        info=ctk.CTkFrame(parent,fg_color=C["card2"],corner_radius=0,
                           border_width=1,border_color=C["border"])
        info.pack(fill="x")
        ii=ctk.CTkFrame(info,fg_color="transparent"); ii.pack(fill="x",padx=20,pady=12)
        dot=ctk.CTkFrame(ii,width=12,height=12,corner_radius=6,fg_color=color)
        dot.pack(side="left",pady=4)
        ctk.CTkLabel(ii,text=f"  {title}",font=("Arial",13,"bold"),text_color=color).pack(side="left")
        ctk.CTkLabel(ii,text=f"  —  {desc}",font=("Arial",11),text_color=C["text3"]).pack(side="left")
        ctk.CTkButton(ii,text="🌐 Open in Browser",width=150,height=32,corner_radius=8,
            fg_color=color+"22",hover_color=color+"44",border_width=1,border_color=color+"66",
            text_color=color,font=("Arial",11),
            command=lambda u=url:os.startfile(u) if os.name=="nt" else subprocess.Popen(["xdg-open",u])
        ).pack(side="right")

        # Embed frame with instructions
        embed=ctk.CTkFrame(parent,fg_color=C["bg"],corner_radius=0)
        embed.pack(fill="both",expand=True)

        center=ctk.CTkFrame(embed,fg_color="transparent")
        center.place(relx=0.5,rely=0.5,anchor="center")

        icon_bg=ctk.CTkFrame(center,width=80,height=80,corner_radius=20,
                               fg_color=color+"22",border_width=2,border_color=color+"55")
        icon_bg.pack()
        icon_bg.pack_propagate(False)
        ctk.CTkLabel(icon_bg,text="🌐",font=("Arial",36)).place(relx=0.5,rely=0.5,anchor="center")

        ctk.CTkLabel(center,text=title,font=("Arial",20,"bold"),text_color=color).pack(pady=(15,5))
        ctk.CTkLabel(center,text=desc,font=("Arial",12),text_color=C["text2"]).pack()
        ctk.CTkLabel(center,
            text="Python tkinter does not support embedded web browsers.\nClick the button above to open in your browser.",
            font=("Arial",11),text_color=C["text3"],justify="center"
        ).pack(pady=10)

        ctk.CTkButton(center,text=f"🚀 Open {title}",
            width=200,height=44,corner_radius=12,
            fg_color=color,hover_color=color,
            font=("Arial",13,"bold"),text_color="white",
            command=lambda u=url:os.startfile(u) if os.name=="nt" else subprocess.Popen(["xdg-open",u])
        ).pack(pady=10)

        ctk.CTkLabel(center,text=url,font=("Arial",10),text_color=C["text3"]).pack()


class FilesPage(ctk.CTkFrame):
    def __init__(self,parent,app):
        super().__init__(parent,fg_color=C["bg"])
        self.app=app; self.cur=None; self._build()

    def _build(self):
        hdr=ctk.CTkFrame(self,fg_color=C["card"],corner_radius=0,border_width=1,border_color=C["border"])
        hdr.pack(fill="x")
        hi=ctk.CTkFrame(hdr,fg_color="transparent"); hi.pack(fill="x",padx=20,pady=14)
        ctk.CTkLabel(hi,text="📁  File Manager",font=("Arial",16,"bold"),text_color=C["text"]).pack(side="left")
        ctk.CTkButton(hi,text="🔄 Refresh",width=100,height=32,corner_radius=8,
            fg_color=C["card2"],hover_color=C["card3"],border_width=1,border_color=C["border"],
            font=("Arial",11),command=self._refresh
        ).pack(side="right")

        body=ctk.CTkFrame(self,fg_color="transparent")
        body.pack(fill="both",expand=True,padx=12,pady=10)

        # Tree
        tree_f=ctk.CTkFrame(body,fg_color=C["card"],corner_radius=12,
                              border_width=1,border_color=C["border"],width=270)
        tree_f.pack(side="left",fill="y",padx=(0,8))
        tree_f.pack_propagate(False)
        ctk.CTkLabel(tree_f,text="Resources",font=("Arial",12,"bold"),text_color=C["text"]).pack(anchor="w",padx=12,pady=(12,6))
        self.tree=ctk.CTkScrollableFrame(tree_f,fg_color="transparent")
        self.tree.pack(fill="both",expand=True,padx=4,pady=(0,8))

        # Editor
        ed_f=ctk.CTkFrame(body,fg_color=C["card"],corner_radius=12,border_width=1,border_color=C["border"])
        ed_f.pack(side="right",fill="both",expand=True)
        eh=ctk.CTkFrame(ed_f,fg_color="transparent"); eh.pack(fill="x",padx=12,pady=(12,6))
        self.fl=ctk.CTkLabel(eh,text="Select a file",font=("Arial",11),text_color=C["text2"])
        self.fl.pack(side="left")
        for txt,col,cmd in [("🤖 AI Fix",C["card2"],self._ai),("💾 Save",C["accent"],self._save)]:
            ctk.CTkButton(eh,text=txt,width=95,height=30,corner_radius=8,
                fg_color=col,hover_color=C["card3"],border_width=1,border_color=C["border"],
                font=("Arial",11),command=cmd
            ).pack(side="right",padx=3)
        self.ed=ctk.CTkTextbox(ed_f,font=("Courier",11),fg_color=C["bg"],corner_radius=8)
        self.ed.pack(fill="both",expand=True,padx=10,pady=(0,10))
        self._refresh()

    def _refresh(self):
        for w in self.tree.winfo_children(): w.destroy()
        rp=self.app.config.get("resources_path","")
        if not rp or not os.path.exists(rp):
            ctk.CTkLabel(self.tree,text="No server path set\nGo to Settings ⚙️",font=("Arial",11),text_color=C["text3"]).pack(pady=20); return
        for item in sorted(Path(rp).iterdir()):
            if item.is_dir():
                ctk.CTkButton(self.tree,text=f"📁  {item.name}",anchor="w",height=30,corner_radius=6,
                    fg_color="transparent",hover_color=C["card2"],text_color=C["text"],font=("Arial",11),
                    command=lambda p=item:self._expand(p)
                ).pack(fill="x",pady=1)

    def _expand(self,path):
        for ext in ["*.lua","*.html","*.js","*.cfg","*.json","*.sql"]:
            for f in sorted(path.rglob(ext)):
                ctk.CTkButton(self.tree,text=f"    📄  {f.name}",anchor="w",height=26,corner_radius=5,
                    fg_color="transparent",hover_color=C["card2"],text_color=C["text2"],font=("Arial",9),
                    command=lambda p=f:self._open(p)
                ).pack(fill="x",pady=1)

    def _open(self,path):
        self.cur=path; self.fl.configure(text=str(path.name),text_color=C["accent2"])
        try: content=path.read_text(encoding="utf-8",errors="ignore")
        except Exception as e: content=f"Error: {e}"
        self.ed.delete("0.0","end"); self.ed.insert("0.0",content)

    def _save(self):
        if not self.cur: return
        with open(self.cur,"w",encoding="utf-8") as f: f.write(self.ed.get("0.0","end"))

    def _ai(self):
        if not self.cur: return
        content=self.ed.get("0.0","end")
        def _fix():
            fixed=self.app.api.claude(f"Fix all bugs in this file ({self.cur.name}):\n{content}",DEBUG_SYS)
            self.after(0,lambda:(self.ed.delete("0.0","end"),self.ed.insert("0.0",fixed)))
        threading.Thread(target=_fix,daemon=True).start()


class SettingsPage(ctk.CTkFrame):
    def __init__(self,parent,app):
        super().__init__(parent,fg_color=C["bg"])
        self.app=app; self.entries={}; self._build()

    def _build(self):
        hdr=ctk.CTkFrame(self,fg_color=C["card"],corner_radius=0,border_width=1,border_color=C["border"])
        hdr.pack(fill="x")
        ctk.CTkLabel(hdr,text="⚙️  Settings",font=("Arial",16,"bold"),text_color=C["text"]).pack(side="left",padx=20,pady=14)

        scroll=ctk.CTkScrollableFrame(self,fg_color="transparent")
        scroll.pack(fill="both",expand=True,padx=40,pady=20)

        # Server Info
        ctk.CTkLabel(scroll,text="SERVER INFO",font=("Arial",10,"bold"),text_color=C["text3"]).pack(anchor="w",pady=(0,8))
        cfg=jload(CFG_FILE,{})

        for key,label,default,hint in [
            ("server_name","Server Name","My FiveM Server","Display name for your server"),
            ("server_port","Server Port","30120","Port FiveM runs on"),
        ]:
            self._field(scroll,key,label,hint,cfg.get(key,default))

        # API Keys
        ctk.CTkLabel(scroll,text="API KEYS",font=("Arial",10,"bold"),text_color=C["text3"]).pack(anchor="w",pady=(20,8))
        keys=jload(KEYS_FILE,{})
        for key,label,color,url in [
            ("claude","Claude (Anthropic)",C["claude"],"console.anthropic.com"),
            ("openai","GPT-4o (OpenAI)",C["gpt"],"platform.openai.com"),
            ("grok","Grok (xAI)",C["grok"],"console.x.ai"),
            ("gemini","Gemini (Google)",C["gemini"],"aistudio.google.com"),
            ("perplexity","Perplexity",C["perp"],"perplexity.ai/settings/api"),
        ]:
            card=ctk.CTkFrame(scroll,fg_color=C["card2"],corner_radius=10,border_width=1,border_color=C["border"])
            card.pack(fill="x",pady=4)
            inner=ctk.CTkFrame(card,fg_color="transparent"); inner.pack(fill="x",padx=15,pady=12)
            top_row=ctk.CTkFrame(inner,fg_color="transparent"); top_row.pack(fill="x")
            dot=ctk.CTkFrame(top_row,width=8,height=8,corner_radius=4,fg_color=color)
            dot.pack(side="left",pady=6)
            ctk.CTkLabel(top_row,text=f"  {label}",font=("Arial",12,"bold"),text_color=color).pack(side="left")
            ctk.CTkLabel(top_row,text=f"  {url}",font=("Arial",9),text_color=C["text3"]).pack(side="left")
            e=ctk.CTkEntry(inner,placeholder_text="Paste API key...",show="*",height=34,corner_radius=8,
                fg_color=C["bg"],border_width=1,border_color=C["border"],font=("Arial",12))
            e.pack(fill="x",pady=(6,0))
            if key in keys: e.insert(0,keys[key])
            self.entries[key]=e

        # Paths
        ctk.CTkLabel(scroll,text="SERVER PATHS",font=("Arial",10,"bold"),text_color=C["text3"]).pack(anchor="w",pady=(20,8))
        for key,label,hint in [
            ("fxserver_exe","FXServer.exe Path","Full path to FXServer.exe"),
            ("server_data","Server Data Folder","Folder containing server.cfg"),
            ("resources_path","Resources Folder","Your resources directory"),
        ]:
            card=ctk.CTkFrame(scroll,fg_color=C["card2"],corner_radius=10,border_width=1,border_color=C["border"])
            card.pack(fill="x",pady=4)
            inner=ctk.CTkFrame(card,fg_color="transparent"); inner.pack(fill="x",padx=15,pady=12)
            ctk.CTkLabel(inner,text=label,font=("Arial",12,"bold"),text_color=C["text"]).pack(anchor="w")
            ctk.CTkLabel(inner,text=hint,font=("Arial",9),text_color=C["text3"]).pack(anchor="w")
            row=ctk.CTkFrame(inner,fg_color="transparent"); row.pack(fill="x",pady=(6,0))
            e=ctk.CTkEntry(row,placeholder_text="Enter path...",height=34,corner_radius=8,
                fg_color=C["bg"],border_width=1,border_color=C["border"],font=("Arial",12))
            e.pack(side="left",fill="x",expand=True)
            if key in cfg: e.insert(0,cfg[key])
            self.entries[key]=e
            ctk.CTkButton(row,text="Browse",width=85,height=34,corner_radius=8,
                fg_color=C["card3"],hover_color=C["card2"],border_width=1,border_color=C["border"],
                font=("Arial",11),command=lambda k=key,en=e:self._browse(k,en)
            ).pack(side="left",padx=(5,0))

        ctk.CTkButton(scroll,text="💾  SAVE SETTINGS",
            font=("Arial",13,"bold"),fg_color=C["accent"],hover_color=C["accent_h"],
            height=48,corner_radius=12,command=self._save
        ).pack(fill="x",pady=20)

        self.ok=ctk.CTkLabel(scroll,text="",font=("Arial",12),text_color=C["success"])
        self.ok.pack()

    def _field(self,parent,key,label,hint,val):
        card=ctk.CTkFrame(parent,fg_color=C["card2"],corner_radius=10,border_width=1,border_color=C["border"])
        card.pack(fill="x",pady=4)
        inner=ctk.CTkFrame(card,fg_color="transparent"); inner.pack(fill="x",padx=15,pady=12)
        ctk.CTkLabel(inner,text=label,font=("Arial",12,"bold"),text_color=C["text"]).pack(anchor="w")
        ctk.CTkLabel(inner,text=hint,font=("Arial",9),text_color=C["text3"]).pack(anchor="w")
        e=ctk.CTkEntry(inner,height=34,corner_radius=8,fg_color=C["bg"],border_width=1,border_color=C["border"],font=("Arial",12))
        e.pack(fill="x",pady=(6,0)); e.insert(0,val)
        self.entries[key]=e

    def _browse(self,key,entry):
        path=(filedialog.askopenfilename(filetypes=[("EXE","*.exe"),("All","*.*")]) if "exe" in key else filedialog.askdirectory())
        if path: entry.delete(0,"end"); entry.insert(0,path)

    def _save(self):
        key_names={"claude","openai","grok","gemini","perplexity"}
        keys,cfg={},{}
        for k,e in self.entries.items():
            v=e.get().strip()
            if k in key_names: keys[k]=v
            else: cfg[k]=v
        jsave(KEYS_FILE,keys); jsave(CFG_FILE,cfg)
        self.app.keys=keys; self.app.config=cfg
        self.app.api=API(keys)
        self.app.server=Server(cfg.get("fxserver_exe",""),cfg.get("server_data",""),self.app._cb)
        self.ok.configure(text="✅ Settings saved and applied!")


# ── TOP BAR ───────────────────────────────────────────
class TopBar(ctk.CTkFrame):
    def __init__(self,parent):
        super().__init__(parent,height=52,corner_radius=0,
                         fg_color=C["card"],border_width=1,border_color=C["border"])
        self.pack_propagate(False); self._build()

    def _build(self):
        i=ctk.CTkFrame(self,fg_color="transparent"); i.pack(fill="both",expand=True,padx=18)
        self.srv_dot=ctk.CTkFrame(i,width=10,height=10,corner_radius=5,fg_color=C["offline"])
        self.srv_dot.pack(side="left",pady=21)
        self.srv_lbl=ctk.CTkLabel(i,text="  SERVER OFFLINE",font=("Arial",11,"bold"),text_color=C["offline"])
        self.srv_lbl.pack(side="left",pady=20)
        self.ph_badge=ctk.CTkFrame(i,fg_color=C["card2"],corner_radius=20)
        self.ph_badge.pack(side="left",padx=15,pady=16)
        self.ph_lbl=ctk.CTkLabel(self.ph_badge,text="",font=("Arial",10),text_color=C["text2"])
        self.ph_lbl.pack(padx=14,pady=3)
        r=ctk.CTkFrame(i,fg_color="transparent"); r.pack(side="right",fill="y")
        ctk.CTkLabel(r,text="⬡  NEXUS SUITE",font=("Arial",13,"bold"),text_color=C["accent"]).pack(side="right",pady=18)

    def set_server(self,on):
        col=C["online"] if on else C["offline"]
        txt="  SERVER ONLINE" if on else "  SERVER OFFLINE"
        self.srv_dot.configure(fg_color=col)
        self.srv_lbl.configure(text=txt,text_color=col)

    def set_phase(self,ph,n):
        if ph and n<9:
            self.ph_lbl.configure(text=f"  ⚡ {n}/8 — {ph}  ",text_color=C["warning"])
            self.ph_badge.configure(fg_color=C["warning"]+"22")
        elif n>=9:
            self.ph_lbl.configure(text="  ✅ Done  ",text_color=C["success"])
            self.ph_badge.configure(fg_color=C["success"]+"22")
        else:
            self.ph_lbl.configure(text="",text_color=C["text2"])
            self.ph_badge.configure(fg_color=C["card2"])


# ── MAIN APP ──────────────────────────────────────────
class NexusSuite(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("⬡ NEXUS SUITE — FiveM AI Dev Platform")
        self.geometry("1440x860"); self.minsize(1200,720)
        self.configure(fg_color=C["bg"])
        self.keys=jload(KEYS_FILE,{}); self.config=jload(CFG_FILE,{})
        self.ctx={}; self.console_ref=None
        self.api=API(self.keys)
        self.server=Server(self.config.get("fxserver_exe",""),self.config.get("server_data",""),self._cb)
        self.pages={}; self.cur=None
        self._build()
        self.sidebar.set_active("home")

    def _build(self):
        self.topbar=TopBar(self); self.topbar.pack(fill="x",side="top")
        body=ctk.CTkFrame(self,fg_color="transparent"); body.pack(fill="both",expand=True)
        self.sidebar=HTNSidebar(body,on_nav=self.navigate); self.sidebar.pack(side="left",fill="y")
        self.content=ctk.CTkFrame(body,fg_color=C["bg"],corner_radius=0); self.content.pack(side="right",fill="both",expand=True)
        self.pages={
            "home":     HomePage(self.content,self),
            "ai":       AICorePage(self.content,self),
            "library":  LibraryPage(self.content,self),
            "webtools": WebToolsPage(self.content,self),
            "files":    FilesPage(self.content,self),
            "settings": SettingsPage(self.content,self),
        }

    def navigate(self,key):
        if self.cur: self.pages[self.cur].pack_forget()
        if key in self.pages: self.pages[key].pack(fill="both",expand=True)
        self.cur=key

    def _cb(self,agent,text):
        def _do():
            if self.console_ref: self.console_ref.append(agent,text)
        self.after(0,_do)

if __name__=="__main__":
    app=NexusSuite()
    app.mainloop()
