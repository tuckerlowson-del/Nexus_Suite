"""
⬡ NEXUS SUITE — FiveM AI Dev Platform
Built by TuckerLawson
"""

import customtkinter as ctk
import threading
import json
import os
import subprocess
import time
import shutil
import re
import urllib.request
from pathlib import Path
from datetime import datetime
from tkinter import filedialog, messagebox
import tkinter as tk
import math

try:
    import anthropic
    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False

try:
    from openai import OpenAI
    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# ── COLORS ────────────────────────────────────────────
C = {
    "bg":           "#060610",
    "bg2":          "#0a0a1a",
    "sidebar":      "#080815",
    "card":         "#0e0e20",
    "card2":        "#13132a",
    "card3":        "#181835",
    "border":       "#1a1a3a",
    "border2":      "#252550",
    "accent":       "#7c3aed",
    "accent_hover": "#6d28d9",
    "accent2":      "#06b6d4",
    "accent3":      "#a855f7",
    "success":      "#10b981",
    "error":        "#ef4444",
    "warning":      "#f59e0b",
    "text":         "#f1f5f9",
    "text2":        "#94a3b8",
    "text3":        "#475569",
    "claude":       "#a78bfa",
    "gpt":          "#34d399",
    "grok":         "#60a5fa",
    "gemini":       "#fbbf24",
    "perplexity":   "#2dd4bf",
    "nexus_ai":     "#f472b6",
    "nexus":        "#7c3aed",
    "white":        "#ffffff",
}

FIVEM_BASE = """You are a senior FiveM server developer with 10+ years experience.
Specializing in: Lua, JavaScript NUI, ESX, QB-Core, Qbox, ox_lib, MySQL/oxmysql,
server.cfg optimization, resource manifests, NUI HTML/CSS/JS, all FiveM natives.
RULES: Output ONLY raw code. No markdown fences. Complete production-ready files only.
No placeholders. No TODOs. Correct fxmanifest.lua always. Current FiveM natives only."""

OVAN_SYSTEM = FIVEM_BASE + "\nYou are Nexus AI, a FiveM specialist. Validate all code against FiveM standards."
PLANNER_SYSTEM = FIVEM_BASE + "\nYou are Project Manager. Output structured plan: FRAMEWORK/FILES_NEEDED/DATABASE_TABLES/CODER_TASK/UI_TASK/QA_TASK/SUMMARY"
CODER_SYSTEM = FIVEM_BASE + "\nYou are Lead Coder. Output ONLY the requested file raw code. Separate files with ===FILENAME==="
DEBUGGER_SYSTEM = FIVEM_BASE + "\nYou are Debug Specialist. List BUGS_FOUND then output FIXED_CODE complete."
UI_SYSTEM = FIVEM_BASE + "\nYou are NUI Specialist. Dark glassmorphism theme. Complete PostMessage/SetNuiFocus handlers. Raw HTML/CSS/JS only."
QA_SYSTEM = FIVEM_BASE + "\nYou are QA Engineer. Output CHECK_NAME: PASS/FAIL — reason for each check."
SECURITY_SYSTEM = FIVEM_BASE + "\nYou are Security Auditor. Check SQL injection, unprotected events, permission gates. Output SECURITY_ISSUES: [list] or NONE"

KEYS_FILE = "nexus_keys.json"
CONFIG_FILE = "nexus_config.json"
LIBRARY_FILE = "nexus_library.json"

def load_json(path, default):
    if os.path.exists(path):
        try:
            with open(path) as f: return json.load(f)
        except: return default
    return default

def save_json(path, data):
    with open(path, "w") as f: json.dump(data, f, indent=2)

# ── API ENGINE ────────────────────────────────────────
class NexusAPI:
    def __init__(self, keys):
        self.keys = keys
        self._init()

    def _init(self):
        self.claude_client = None
        self.openai_client = None
        self.grok_client = None
        self.perplexity_client = None
        if HAS_ANTHROPIC and self.keys.get("claude"):
            try: self.claude_client = anthropic.Anthropic(api_key=self.keys["claude"])
            except: pass
        if HAS_OPENAI:
            if self.keys.get("openai"):
                try: self.openai_client = OpenAI(api_key=self.keys["openai"])
                except: pass
            if self.keys.get("grok"):
                try: self.grok_client = OpenAI(api_key=self.keys["grok"], base_url="https://api.x.ai/v1")
                except: pass
            if self.keys.get("perplexity"):
                try: self.perplexity_client = OpenAI(api_key=self.keys["perplexity"], base_url="https://api.perplexity.ai")
                except: pass

    def ask_claude(self, prompt, system=FIVEM_BASE):
        if not self.claude_client: return "[Claude not configured]"
        try:
            msg = self.claude_client.messages.create(model="claude-sonnet-4-6", max_tokens=4096, system=system, messages=[{"role":"user","content":prompt}])
            return msg.content[0].text
        except Exception as e: return f"[Claude error: {e}]"

    def ask_gpt(self, prompt, system=FIVEM_BASE):
        if not self.openai_client: return "[GPT-4o not configured]"
        try:
            res = self.openai_client.chat.completions.create(model="gpt-4o", messages=[{"role":"system","content":system},{"role":"user","content":prompt}], max_tokens=4096)
            return res.choices[0].message.content
        except Exception as e: return f"[GPT error: {e}]"

    def ask_grok(self, prompt, system=FIVEM_BASE):
        if not self.grok_client: return "[Grok not configured]"
        try:
            res = self.grok_client.chat.completions.create(model="grok-3", messages=[{"role":"system","content":system},{"role":"user","content":prompt}], max_tokens=4096)
            return res.choices[0].message.content
        except Exception as e: return f"[Grok error: {e}]"

    def ask_gemini(self, prompt):
        key = self.keys.get("gemini","")
        if not key: return "[Gemini not configured]"
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key={key}"
            body = json.dumps({"contents":[{"parts":[{"text":FIVEM_BASE+"\n\n"+prompt}]}],"generationConfig":{"maxOutputTokens":4096}}).encode()
            req = urllib.request.Request(url, data=body, headers={"Content-Type":"application/json"})
            with urllib.request.urlopen(req, timeout=60) as r:
                data = json.loads(r.read())
            return data["candidates"][0]["content"]["parts"][0]["text"]
        except Exception as e: return f"[Gemini error: {e}]"

    def ask_perplexity(self, prompt, system=FIVEM_BASE):
        if not self.perplexity_client: return "[Perplexity not configured]"
        try:
            res = self.perplexity_client.chat.completions.create(model="llama-3.1-sonar-large-128k-online", messages=[{"role":"system","content":system},{"role":"user","content":prompt}], max_tokens=4096)
            return res.choices[0].message.content
        except Exception as e: return f"[Perplexity error: {e}]"

    def ask_nexus(self, prompt): return self.ask_claude(prompt, system=OVAN_SYSTEM)
    def confidence(self, r):
        if any(x in r[:60].lower() for x in ["error","not configured","[","failed"]): return 30
        if len(r) < 100: return 45
        if len(r) > 800: return 92
        return 78

# ── SERVER CTRL ───────────────────────────────────────
class ServerCtrl:
    def __init__(self, fx_path, data_path, on_out):
        self.fx_path = fx_path
        self.data_path = data_path
        self.on_out = on_out
        self.process = None
        self.running = False

    def start(self):
        if self.running: self.on_out("system","⚠️ Already running\n"); return
        if not self.fx_path or not os.path.exists(self.fx_path):
            self.on_out("system","❌ FXServer.exe not found — set path in Setup\n"); return
        try:
            self.process = subprocess.Popen([self.fx_path,"+exec","server.cfg"], cwd=self.data_path, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            self.running = True
            self.on_out("system","🟢 Server starting...\n")
            threading.Thread(target=self._stream, daemon=True).start()
        except Exception as e: self.on_out("system",f"❌ Start failed: {e}\n")

    def stop(self):
        if self.process: self.process.terminate(); self.running = False; self.on_out("system","🔴 Server stopped\n")

    def restart(self): self.stop(); time.sleep(2); self.start()

    def _stream(self):
        try:
            for line in self.process.stdout: self.on_out("console", line)
        except: pass
        self.running = False
        self.on_out("system","🔴 Server ended\n")

    def write_resource(self, name, files, res_path):
        rd = Path(res_path) / "[nexus]" / name
        rd.mkdir(parents=True, exist_ok=True)
        log = [f"# NEXUS CHANGELOG — {name}", f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", "---"]
        for fname, content in files.items():
            target = rd / fname
            target.parent.mkdir(parents=True, exist_ok=True)
            with open(target,"w",encoding="utf-8") as f: f.write(content)
            log.append(f"✅ {fname}")
        with open(rd/"NEXUS_CHANGELOG.md","w") as f: f.write("\n".join(log))
        self.on_out("system",f"📁 Written: {rd}\n")
        return str(rd)

    def backup(self, path):
        Path("nexus_backups").mkdir(exist_ok=True)
        dest = f"nexus_backups/backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        try: shutil.copytree(path, dest); self.on_out("system",f"💾 Backup: {dest}\n"); return dest
        except Exception as e: self.on_out("system",f"❌ Backup failed: {e}\n"); return None

    def scan(self, path):
        info = {"framework":"Unknown","resources":[],"resource_count":0,"has_sql":False}
        if not path or not os.path.exists(path): return info
        rp = Path(path)/"resources"
        if not rp.exists(): return info
        for item in rp.rglob("fxmanifest.lua"):
            info["resources"].append(item.parent.name)
            txt = item.read_text(errors="ignore").lower()
            if "qb-core" in txt or "qbcore" in txt: info["framework"] = "QBCore"
            elif "es_extended" in txt or "esx" in txt: info["framework"] = "ESX"
            elif "qbox" in txt: info["framework"] = "Qbox"
        for _ in rp.rglob("*.sql"): info["has_sql"] = True; break
        info["resource_count"] = len(info["resources"])
        return info

# ── PIPELINE ──────────────────────────────────────────
class Pipeline:
    def __init__(self, api, server, on_update, on_phase, on_done, on_error):
        self.api = api; self.server = server
        self.on_update = on_update; self.on_phase = on_phase
        self.on_done = on_done; self.on_error = on_error
        self.cancelled = False

    def run(self, task, ctx, res_path):
        self.cancelled = False
        threading.Thread(target=self._run, args=(task,ctx,res_path), daemon=True).start()

    def cancel(self): self.cancelled = True

    def _log(self, agent, msg): self.on_update(agent, msg)
    def _phase(self, n, i): self.on_phase(n, i)
    def _check(self): return not self.cancelled

    def _run(self, task, ctx, res_path):
        fw = ctx.get("framework","QBCore")
        res_list = ", ".join(ctx.get("resources",[])[:10])
        scan_ctx = f"Framework: {fw}\nResources: {res_list}\nHas SQL: {ctx.get('has_sql',False)}\nTask: {task}"
        results = {}

        self._phase("Server Scan",1)
        self._log("nexus",f"🔍 Framework: {fw} | Resources: {ctx.get('resource_count',0)}\n")
        if not self._check(): return

        self._phase("Planning",2)
        self._log("claude","📋 Claude planning task...\n")
        plan = self.api.ask_claude(f"Plan this FiveM task:\n{scan_ctx}", system=PLANNER_SYSTEM)
        results["plan"] = plan
        self._log("claude", plan+"\n")
        if not self._check(): return

        self._phase("Code Writing",3)
        self._log("gpt","💻 GPT-4o writing first draft...\n")
        gpt_code = self.api.ask_gpt(f"Framework: {fw}\nTask: {task}\nPlan: {plan}\nWrite fxmanifest.lua, server.lua, client.lua, config.lua. Separate with ===FILENAME===", system=CODER_SYSTEM)
        self._log("gpt",f"✅ GPT draft done ({self.api.confidence(gpt_code)}% confidence)\n")
        if not self._check(): return

        self._log("claude","🔍 Claude reviewing GPT code...\n")
        cl_review = self.api.ask_claude(f"Review and correct this FiveM code:\n{gpt_code}\nTask: {task}\nFramework: {fw}", system=CODER_SYSTEM)
        self._log("claude",f"✅ Claude review done ({self.api.confidence(cl_review)}%)\n")
        if not self._check(): return

        self._log("nexus_ai","🟣 Nexus AI validating FiveM standards...\n")
        nexus_val = self.api.ask_nexus(f"Validate this {fw} code:\n{cl_review}\nFix any framework-specific issues.")
        self._log("nexus_ai",f"✅ Nexus AI validation done ({self.api.confidence(nexus_val)}%)\n")
        results["code"] = nexus_val
        if not self._check(): return

        self._phase("Debugging",4)
        self._log("grok","🐛 Grok fast bug scan...\n")
        grok_bugs = self.api.ask_grok(f"Find all bugs:\n{results['code']}", system=DEBUGGER_SYSTEM)
        self._log("grok", grok_bugs[:400]+"\n")
        if not self._check(): return

        self._log("claude","🧠 Claude deep logic review...\n")
        cl_bugs = self.api.ask_claude(f"Deep logic review — nil refs, callbacks, memory leaks:\n{results['code']}", system=DEBUGGER_SYSTEM)
        self._log("claude", cl_bugs[:300]+"\n")
        if not self._check(): return

        self._log("gpt","🔎 GPT-4o applying all fixes...\n")
        gpt_fix = self.api.ask_gpt(f"Apply all bug fixes from:\nGrok: {grok_bugs}\nClaude: {cl_bugs}\n\nCode:\n{results['code']}\nOutput ONLY complete fixed code.", system=CODER_SYSTEM)
        self._log("gpt","✅ All debug fixes applied\n")
        results["debugged"] = gpt_fix
        if not self._check(): return

        self._phase("UI/NUI Building",5)
        self._log("claude","🎨 Claude designing NUI structure...\n")
        nui_plan = self.api.ask_claude(f"Design NUI layout for: {task}\nFramework: {fw}", system=UI_SYSTEM)
        self._log("claude","✅ NUI structure designed\n")
        if not self._check(): return

        self._log("gemini","🖼️ Gemini building HTML + CSS...\n")
        html_css = self.api.ask_gemini(f"Build HTML+CSS for FiveM NUI:\nTask: {task}\nLayout: {nui_plan}\nDark glassmorphism. Output index.html only.")
        self._log("gemini","✅ HTML/CSS done\n")
        if not self._check(): return

        self._log("gpt","⚡ GPT-4o writing JS + PostMessage handlers...\n")
        js = self.api.ask_gpt(f"Write JS for FiveM NUI:\nTask: {task}\nFramework: {fw}\nLayout: {nui_plan}\nAll SendNUIMessage + SetNuiFocus logic.", system=UI_SYSTEM)
        self._log("gpt","✅ JavaScript done\n")
        if not self._check(): return

        self._log("nexus_ai","🟣 Nexus AI validating NUI...\n")
        nui_final = self.api.ask_nexus(f"Validate and merge NUI for {fw}:\nHTML: {html_css[:800]}\nJS: {js[:800]}\nOutput complete merged index.html")
        self._log("nexus_ai","✅ NUI validated\n")
        results["nui"] = nui_final
        if not self._check(): return

        self._phase("QA Testing",6)
        self._log("perplexity","🔍 Perplexity checking live FiveM docs...\n")
        pplx_qa = self.api.ask_perplexity(f"QA check against current FiveM {fw} docs:\n{results['debugged'][:1200]}", system=QA_SYSTEM)
        self._log("perplexity", pplx_qa[:300]+"\n")
        if not self._check(): return

        self._log("claude","🛡️ Claude logic + security QA...\n")
        cl_qa = self.api.ask_claude(f"QA — logic, security, edge cases:\n{results['debugged'][:1200]}", system=QA_SYSTEM)
        self._log("claude", cl_qa[:250]+"\n")
        if not self._check(): return

        self._log("gemini","🖥️ Gemini NUI render check...\n")
        gem_qa = self.api.ask_gemini(f"QA NUI render + PostMessage flow:\n{results['nui'][:800]}")
        self._log("gemini","✅ QA complete\n")

        qa_failed = any("FAIL" in r for r in [pplx_qa, cl_qa, gem_qa])
        if qa_failed:
            self._log("nexus","⚠️ QA issues — auto-fixing...\n")
            results["debugged"] = self.api.ask_claude(f"Fix QA issues:\n{cl_qa}\nCode:\n{results['debugged']}", system=CODER_SYSTEM)
        if not self._check(): return

        self._phase("Security Audit",7)
        self._log("claude","🔒 Security audit...\n")
        sec = self.api.ask_claude(f"Security audit:\n{results['debugged'][:1500]}", system=SECURITY_SYSTEM)
        if "NONE" not in sec.upper():
            self._log("nexus",f"🔒 Security issues found — patching...\n")
            results["debugged"] = self.api.ask_claude(f"Fix security:\n{sec}\nCode:\n{results['debugged']}", system=CODER_SYSTEM)
        else:
            self._log("nexus","✅ Security clean\n")
        if not self._check(): return

        self._phase("Deploying",8)
        self._log("nexus","📦 Parsing files...\n")
        files = self._parse(results["debugged"], results.get("nui",""))

        if res_path and os.path.exists(res_path):
            slug = re.sub(r"[^a-z0-9]+","-", task.lower())[:28]
            written = self.server.write_resource(slug, files, res_path)
            self._log("nexus",f"✅ Deployed to: {written}\n")
            if self.server.running: self.server.restart()
        else:
            self._log("nexus","⚠️ No server path — set in Setup for auto-deploy\n")

        self._phase("Complete",9)
        final = f"""╔══════════════════════════════════╗
║    NEXUS SUITE — BUILD COMPLETE  ║
╚══════════════════════════════════╝

Task: {task}
Framework: {fw}
Files: {len(files)}
QA: {'⚠️ Fixed' if qa_failed else '✅ Passed'}
Security: {'✅ Clean' if 'NONE' in sec.upper() else '⚠️ Patched'}
Deploy: {'✅ Live' if res_path and os.path.exists(str(res_path)) else '⚠️ Manual needed'}
Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

FILES GENERATED:
{chr(10).join(f'  ✅ {k}' for k in files.keys())}
"""
        self._log("nexus", final)
        self.on_done(files, final)

    def _parse(self, code, nui):
        files = {}
        if "===fxmanifest.lua===" in code or "===server.lua===" in code:
            parts = code.split("===")
            for i, p in enumerate(parts):
                name = p.strip()
                if any(name.endswith(x) for x in [".lua",".js",".sql",".json"]):
                    if i+1 < len(parts): files[name] = parts[i+1].strip()
        if not files:
            files["fxmanifest.lua"] = self._extract(code, r"fx_version[\s\S]*?(?=\n\n|\Z)") or "fx_version 'cerulean'\ngame 'gta5'\n"
            files["server.lua"] = self._extract(code, r"(?:--\s*server|RegisterServerEvent|AddEventHandler)[\s\S]*?(?=\n--\s*client|\Z)") or "-- server.lua\n"
            files["client.lua"] = self._extract(code, r"(?:--\s*client|RegisterNetEvent|Citizen.CreateThread)[\s\S]*?(?=\n--\s*config|\Z)") or "-- client.lua\n"
            files["config.lua"] = self._extract(code, r"Config\s*=\s*\{[\s\S]*?\}") or "Config = {}\n"
        if nui and len(nui) > 50: files["html/index.html"] = nui
        return {k:v for k,v in files.items() if v and len(v) > 10}

    def _extract(self, text, pattern):
        m = re.search(pattern, text, re.IGNORECASE)
        return m.group(0).strip() if m else ""

# ══════════════════════════════════════════════════════
#  UI COMPONENTS
# ══════════════════════════════════════════════════════

class GlowButton(ctk.CTkButton):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)

class NexusCard(ctk.CTkFrame):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, fg_color=C["card"], corner_radius=16,
                         border_width=1, border_color=C["border"], **kwargs)

class SectionLabel(ctk.CTkLabel):
    def __init__(self, parent, text, **kwargs):
        super().__init__(parent, text=text,
                         font=("Arial", 11, "bold"),
                         text_color=C["text3"],
                         **kwargs)

class Sidebar(ctk.CTkFrame):
    def __init__(self, parent, on_nav):
        super().__init__(parent, width=240, corner_radius=0,
                         fg_color=C["sidebar"],
                         border_width=1, border_color=C["border"])
        self.pack_propagate(False)
        self.on_nav = on_nav
        self.buttons = {}
        self.active = None
        self._build()

    def _build(self):
        # Logo area
        logo = ctk.CTkFrame(self, fg_color="transparent")
        logo.pack(pady=(30,20), padx=20, fill="x")

        hex_label = ctk.CTkLabel(logo, text="⬡",
            font=("Arial", 36, "bold"), text_color=C["accent"])
        hex_label.pack()

        ctk.CTkLabel(logo, text="NEXUS SUITE",
            font=("Arial", 16, "bold"),
            text_color=C["white"],
            letter_spacing=3
        ).pack()

        ctk.CTkLabel(logo, text="FiveM AI Platform",
            font=("Arial", 10),
            text_color=C["text3"]
        ).pack()

        ctk.CTkFrame(self, height=1, fg_color=C["border"]).pack(fill="x", padx=20, pady=10)

        SectionLabel(self, "  MAIN NAVIGATION").pack(anchor="w", padx=20, pady=(10,5))

        nav = [
            ("⬡", "Home",         "home",    C["accent"]),
            ("🧠", "Nexus AI Core","ai",      C["claude"]),
            ("🖥️", "Server Panel", "panel",   C["gpt"]),
            ("📊", "Live Console", "console", C["grok"]),
            ("📁", "File Manager", "files",   C["gemini"]),
            ("📚", "Resource Lib", "library", C["perplexity"]),
            ("⚙️", "Setup",        "setup",   C["nexus_ai"]),
        ]

        for icon, label, key, color in nav:
            frame = ctk.CTkFrame(self, fg_color="transparent")
            frame.pack(fill="x", padx=12, pady=2)

            indicator = ctk.CTkFrame(frame, width=3, corner_radius=2,
                                      fg_color="transparent")
            indicator.pack(side="left", fill="y", padx=(0,8))

            btn = ctk.CTkButton(frame,
                text=f" {icon}   {label}",
                anchor="w",
                font=("Arial", 13),
                fg_color="transparent",
                hover_color=C["card"],
                text_color=C["text2"],
                height=44,
                corner_radius=10,
                command=lambda k=key, c=color, ind=indicator, b=None: self._nav(k, c, ind)
            )
            btn.pack(fill="x")
            self.buttons[key] = (btn, indicator, color)

        ctk.CTkFrame(self, fg_color="transparent").pack(expand=True)

        # Agent status mini display
        ctk.CTkFrame(self, height=1, fg_color=C["border"]).pack(fill="x", padx=20, pady=5)

        status_frame = NexusCard(self)
        status_frame.configure(corner_radius=12)
        status_frame.pack(fill="x", padx=12, pady=(5,15))

        ctk.CTkLabel(status_frame, text="AGENTS ONLINE",
            font=("Arial", 9, "bold"),
            text_color=C["text3"]
        ).pack(pady=(10,5))

        agents_row = ctk.CTkFrame(status_frame, fg_color="transparent")
        agents_row.pack(pady=(0,10))

        agent_dots = [
            (C["claude"],"C"), (C["gpt"],"G"), (C["grok"],"X"),
            (C["gemini"],"Ge"),(C["perplexity"],"P"),(C["nexus_ai"],"N")
        ]
        for color, letter in agent_dots:
            dot_frame = ctk.CTkFrame(agents_row, width=28, height=28,
                                      corner_radius=14, fg_color=color+"33",
                                      border_width=1, border_color=color)
            dot_frame.pack(side="left", padx=2)
            dot_frame.pack_propagate(False)
            ctk.CTkLabel(dot_frame, text=letter,
                font=("Arial", 8, "bold"), text_color=color
            ).place(relx=0.5, rely=0.5, anchor="center")

        ctk.CTkLabel(self, text="Built by TuckerLawson",
            font=("Arial", 9),
            text_color=C["text3"]
        ).pack(pady=(0,15))

    def _nav(self, key, color, indicator):
        for k,(b,ind,c) in self.buttons.items():
            b.configure(fg_color="transparent", text_color=C["text2"],
                       font=("Arial",13))
            ind.configure(fg_color="transparent")

        btn, ind, c = self.buttons[key]
        btn.configure(fg_color=C["card2"], text_color=C["white"],
                     font=("Arial",13,"bold"))
        ind.configure(fg_color=color)
        self.active = key
        self.on_nav(key)

    def set_active(self, key):
        color = self.buttons[key][2]
        ind = self.buttons[key][1]
        self._nav(key, color, ind)


class TopBar(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, height=56, corner_radius=0,
                         fg_color=C["card"],
                         border_width=1, border_color=C["border"])
        self.pack_propagate(False)
        self._build()

    def _build(self):
        inner = ctk.CTkFrame(self, fg_color="transparent")
        inner.pack(fill="both", expand=True, padx=20)

        left = ctk.CTkFrame(inner, fg_color="transparent")
        left.pack(side="left", fill="y")

        self.server_indicator = ctk.CTkFrame(left, width=10, height=10,
                                              corner_radius=5, fg_color=C["error"])
        self.server_indicator.pack(side="left", pady=23)

        self.server_label = ctk.CTkLabel(left, text="  SERVER OFFLINE",
            font=("Arial", 12, "bold"), text_color=C["error"])
        self.server_label.pack(side="left", pady=22)

        self.phase_badge = ctk.CTkFrame(left, fg_color=C["card2"],
                                         corner_radius=20)
        self.phase_badge.pack(side="left", padx=15, pady=18)

        self.phase_label = ctk.CTkLabel(self.phase_badge, text="",
            font=("Arial", 11), text_color=C["text2"])
        self.phase_label.pack(padx=15, pady=4)

        right = ctk.CTkFrame(inner, fg_color="transparent")
        right.pack(side="right", fill="y")

        title_frame = ctk.CTkFrame(right, fg_color="transparent")
        title_frame.pack(side="right", pady=16)

        ctk.CTkLabel(title_frame, text="⬡ ",
            font=("Arial", 18, "bold"), text_color=C["accent"]
        ).pack(side="left")
        ctk.CTkLabel(title_frame, text="NEXUS SUITE",
            font=("Arial", 14, "bold"), text_color=C["white"]
        ).pack(side="left")
        ctk.CTkLabel(title_frame, text=" v1.0",
            font=("Arial", 11), text_color=C["text3"]
        ).pack(side="left")

    def set_server(self, online):
        color = C["success"] if online else C["error"]
        text = "  SERVER ONLINE" if online else "  SERVER OFFLINE"
        self.server_indicator.configure(fg_color=color)
        self.server_label.configure(text=text, text_color=color)

    def set_phase(self, phase, num):
        if phase and num < 9:
            self.phase_label.configure(
                text=f"  ⚡ Phase {num}/8 — {phase}  ",
                text_color=C["warning"])
            self.phase_badge.configure(fg_color=C["warning"]+"22",
                                        border_width=1, border_color=C["warning"]+"44")
        elif num >= 9:
            self.phase_label.configure(text="  ✅ Build Complete  ", text_color=C["success"])
            self.phase_badge.configure(fg_color=C["success"]+"22",
                                        border_width=1, border_color=C["success"]+"44")
        else:
            self.phase_label.configure(text="", text_color=C["text2"])
            self.phase_badge.configure(fg_color=C["card2"], border_width=0)


class AgentStatusCard(ctk.CTkFrame):
    def __init__(self, parent, key, name, color, icon):
        super().__init__(parent, fg_color=C["card2"], corner_radius=12,
                         border_width=1, border_color=C["border"])
        self.color = color
        self.key = key
        self._build(name, color, icon)

    def _build(self, name, color, icon):
        self.configure(height=70)
        self.pack_propagate(False)

        left = ctk.CTkFrame(self, fg_color="transparent")
        left.pack(side="left", fill="y", padx=(12,8))

        self.icon_frame = ctk.CTkFrame(left, width=36, height=36,
                                        corner_radius=18,
                                        fg_color=color+"22",
                                        border_width=1, border_color=color+"55")
        self.icon_frame.pack(pady=17)
        self.icon_frame.pack_propagate(False)

        ctk.CTkLabel(self.icon_frame, text=icon,
                     font=("Arial", 14)).place(relx=0.5,rely=0.5,anchor="center")

        right = ctk.CTkFrame(self, fg_color="transparent")
        right.pack(side="left", fill="both", expand=True, pady=10)

        ctk.CTkLabel(right, text=name,
                     font=("Arial", 11, "bold"),
                     text_color=color).pack(anchor="w")

        self.status_label = ctk.CTkLabel(right, text="Idle",
                                          font=("Arial", 10),
                                          text_color=C["text3"])
        self.status_label.pack(anchor="w")

        self.progress = ctk.CTkProgressBar(right, height=4,
                                            corner_radius=2,
                                            progress_color=color,
                                            fg_color=C["border"])
        self.progress.pack(fill="x", pady=(4,0), padx=(0,12))
        self.progress.set(0)

        self.conf_label = ctk.CTkLabel(self, text="",
                                        font=("Arial", 10, "bold"),
                                        text_color=color)
        self.conf_label.pack(side="right", padx=12)

    def set_working(self, conf=None):
        self.icon_frame.configure(fg_color=self.color+"44",
                                   border_color=self.color)
        self.status_label.configure(text="Working...", text_color=C["warning"])
        self.progress.set(0.6)
        if conf: self.conf_label.configure(text=f"{conf}%")

    def set_done(self, conf=None):
        self.icon_frame.configure(fg_color=self.color+"33",
                                   border_color=C["success"])
        self.status_label.configure(text="Done ✅", text_color=C["success"])
        self.progress.set(1.0)
        if conf: self.conf_label.configure(text=f"{conf}% ✅")

    def set_idle(self):
        self.icon_frame.configure(fg_color=self.color+"22",
                                   border_color=self.color+"55")
        self.status_label.configure(text="Idle", text_color=C["text3"])
        self.progress.set(0)
        self.conf_label.configure(text="")


class LogConsole(ctk.CTkTextbox):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, font=("JetBrains Mono", 11),
                         fg_color=C["bg"], text_color=C["text"],
                         corner_radius=0, **kwargs)
        self.configure(state="disabled")

    def log(self, agent, text):
        self.configure(state="normal")
        prefix = f"[{agent.upper():<12}] "
        self.insert("end", prefix + text)
        self.see("end")
        self.configure(state="disabled")

    def clear(self):
        self.configure(state="normal")
        self.delete("0.0","end")
        self.configure(state="disabled")


# ══════════════════════════════════════════════════════
#  PAGES
# ══════════════════════════════════════════════════════

class HomePage(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=C["bg"])
        self.app = app
        self._build()

    def _build(self):
        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True)

        # Hero
        hero = ctk.CTkFrame(scroll, fg_color="transparent")
        hero.pack(pady=(60,30), padx=60, fill="x")

        badge = ctk.CTkFrame(hero, fg_color=C["accent"]+"22",
                              corner_radius=20, border_width=1,
                              border_color=C["accent"]+"44")
        badge.pack()
        ctk.CTkLabel(badge, text="⬡  FiveM AI Development Platform",
            font=("Arial", 12), text_color=C["accent"]
        ).pack(padx=20, pady=6)

        ctk.CTkLabel(hero, text="NEXUS SUITE",
            font=("Arial", 56, "bold"), text_color=C["white"]
        ).pack(pady=(20,5))

        ctk.CTkLabel(hero, text="6 AIs. 8 Phases. One EXE.",
            font=("Arial", 22), text_color=C["accent2"]
        ).pack()

        ctk.CTkLabel(hero,
            text="Build, debug, test and deploy FiveM scripts automatically.\nAll for free.",
            font=("Arial", 14), text_color=C["text2"], justify="center"
        ).pack(pady=15)

        btn_row = ctk.CTkFrame(hero, fg_color="transparent")
        btn_row.pack(pady=20)

        ctk.CTkButton(btn_row,
            text="🚀  Start Building",
            font=("Arial", 14, "bold"),
            fg_color=C["accent"], hover_color=C["accent_hover"],
            height=50, width=200, corner_radius=25,
            command=lambda: self.app.navigate("ai")
        ).pack(side="left", padx=8)

        ctk.CTkButton(btn_row,
            text="⚙️  Setup API Keys",
            font=("Arial", 14),
            fg_color=C["card2"], hover_color=C["card3"],
            border_width=1, border_color=C["border2"],
            height=50, width=180, corner_radius=25,
            command=lambda: self.app.navigate("setup")
        ).pack(side="left", padx=8)

        # Stats bar
        stats = NexusCard(scroll)
        stats.pack(fill="x", padx=60, pady=10)

        stats_inner = ctk.CTkFrame(stats, fg_color="transparent")
        stats_inner.pack(fill="x", padx=30, pady=20)

        for i, (num, label, color) in enumerate([
            ("6","AI Agents",C["claude"]),
            ("8","Build Phases",C["gpt"]),
            ("100%","Auto Deploy",C["grok"]),
            ("FREE","Forever",C["accent"]),
        ]):
            col = ctk.CTkFrame(stats_inner, fg_color="transparent")
            col.pack(side="left", expand=True)
            ctk.CTkLabel(col, text=num,
                font=("Arial", 32, "bold"), text_color=color
            ).pack()
            ctk.CTkLabel(col, text=label,
                font=("Arial", 11), text_color=C["text2"]
            ).pack()
            if i < 3:
                ctk.CTkFrame(stats_inner, width=1, fg_color=C["border"]
                ).pack(side="left", fill="y", pady=10)

        # Feature cards
        ctk.CTkLabel(scroll, text="FEATURES",
            font=("Arial", 11, "bold"), text_color=C["text3"]
        ).pack(pady=(30,10))

        cards_row = ctk.CTkFrame(scroll, fg_color="transparent")
        cards_row.pack(fill="x", padx=60, pady=5)

        features = [
            ("🧠","Nexus AI Core","8-phase multi-agent pipeline. All AIs collaborate to build your scripts.",C["claude"]),
            ("🖥️","Server Panel","Full server control. Start, stop, edit configs and manage backups.",C["gpt"]),
            ("🔄","Self-Fix Loop","Console monitoring with automatic error detection and AI fixes.",C["grok"]),
            ("📚","Resource Library","Every built script saved locally. Import to any server anytime.",C["gemini"]),
        ]

        for i, (icon, title, desc, color) in enumerate(features):
            card = NexusCard(cards_row)
            card.grid(row=0, column=i, padx=6, sticky="nsew")
            cards_row.columnconfigure(i, weight=1)

            top = ctk.CTkFrame(card, width=50, height=50, corner_radius=12,
                                fg_color=color+"22", border_width=1, border_color=color+"44")
            top.pack(pady=(20,10), padx=20, anchor="w")
            top.pack_propagate(False)
            ctk.CTkLabel(top, text=icon, font=("Arial",22)).place(relx=0.5,rely=0.5,anchor="center")

            ctk.CTkLabel(card, text=title,
                font=("Arial", 13, "bold"), text_color=C["white"]
            ).pack(anchor="w", padx=20)
            ctk.CTkLabel(card, text=desc,
                font=("Arial", 11), text_color=C["text2"],
                justify="left", wraplength=180
            ).pack(anchor="w", padx=20, pady=(5,20))

        # Agent showcase
        ctk.CTkLabel(scroll, text="AI AGENTS",
            font=("Arial", 11, "bold"), text_color=C["text3"]
        ).pack(pady=(30,10))

        agents_grid = ctk.CTkFrame(scroll, fg_color="transparent")
        agents_grid.pack(fill="x", padx=60, pady=5)

        agents = [
            ("Claude","Planner + Reviewer + Security",C["claude"],"🗂️"),
            ("GPT-4o","Lead Coder + Syntax Debug",C["gpt"],"💻"),
            ("Grok","Fast Bug Scanner",C["grok"],"🐛"),
            ("Gemini","HTML/CSS + UI QA",C["gemini"],"🎨"),
            ("Perplexity","Live Docs QA",C["perplexity"],"🔍"),
            ("Nexus AI","FiveM Validator",C["nexus_ai"],"🟣"),
        ]

        for i, (name, role, color, icon) in enumerate(agents):
            row, col = divmod(i, 3)
            card = NexusCard(agents_grid)
            card.grid(row=row, column=col, padx=6, pady=6, sticky="nsew")
            agents_grid.columnconfigure(col, weight=1)

            inner = ctk.CTkFrame(card, fg_color="transparent")
            inner.pack(fill="x", padx=15, pady=15)

            dot = ctk.CTkFrame(inner, width=10, height=10,
                                corner_radius=5, fg_color=color)
            dot.pack(side="left", pady=5)

            ctk.CTkLabel(inner, text=f"  {icon} {name}",
                font=("Arial", 13, "bold"), text_color=color
            ).pack(side="left")

            ctk.CTkLabel(card, text=role,
                font=("Arial", 11), text_color=C["text2"]
            ).pack(anchor="w", padx=15, pady=(0,15))


class AICorePage(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=C["bg"])
        self.app = app
        self.pipeline = None
        self._files = {}
        self._final = ""
        self._task = ""
        self._build()

    def _build(self):
        # Header bar
        hdr = ctk.CTkFrame(self, fg_color=C["card"], corner_radius=0,
                            border_width=1, border_color=C["border"])
        hdr.pack(fill="x")

        hdr_inner = ctk.CTkFrame(hdr, fg_color="transparent")
        hdr_inner.pack(fill="x", padx=20, pady=12)

        ctk.CTkLabel(hdr_inner, text="⬡  NEXUS AI CORE",
            font=("Arial", 16, "bold"), text_color=C["white"]
        ).pack(side="left")

        self.scan_pill = ctk.CTkFrame(hdr_inner, fg_color=C["card2"],
                                       corner_radius=20, border_width=1,
                                       border_color=C["border2"])
        self.scan_pill.pack(side="left", padx=15)
        self.scan_label = ctk.CTkLabel(self.scan_pill,
            text="  Server: Not scanned  ",
            font=("Arial", 11), text_color=C["text2"])
        self.scan_label.pack(padx=5, pady=4)

        ctk.CTkButton(hdr_inner, text="🔍 Scan Server",
            width=120, height=32, corner_radius=16,
            fg_color=C["card2"], hover_color=C["card3"],
            border_width=1, border_color=C["border2"],
            font=("Arial", 11),
            command=self._scan
        ).pack(side="right")

        # Body
        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=15, pady=12)

        # LEFT PANEL
        left = ctk.CTkFrame(body, fg_color="transparent", width=310)
        left.pack(side="left", fill="y", padx=(0,10))
        left.pack_propagate(False)

        # Task input card
        task_card = NexusCard(left)
        task_card.pack(fill="x", pady=(0,10))

        ctk.CTkLabel(task_card, text="Your Task",
            font=("Arial", 13, "bold"), text_color=C["white"]
        ).pack(anchor="w", padx=15, pady=(15,8))

        self.task_input = ctk.CTkTextbox(task_card, height=130,
                                          corner_radius=10,
                                          fg_color=C["bg2"],
                                          font=("Arial", 12),
                                          border_width=1,
                                          border_color=C["border"])
        self.task_input.pack(fill="x", padx=12, pady=(0,5))
        self.task_input.insert("0.0","Build a /garage command with NUI vehicle menu using QBCore")

        # Action buttons
        btn_card = NexusCard(left)
        btn_card.pack(fill="x", pady=(0,10))

        btns_inner = ctk.CTkFrame(btn_card, fg_color="transparent")
        btns_inner.pack(fill="x", padx=12, pady=12)

        self.run_btn = ctk.CTkButton(btns_inner,
            text="🚀  RUN PIPELINE",
            font=("Arial", 13, "bold"),
            fg_color=C["accent"], hover_color=C["accent_hover"],
            height=46, corner_radius=12,
            command=self._run
        )
        self.run_btn.pack(fill="x", pady=(0,8))

        row2 = ctk.CTkFrame(btns_inner, fg_color="transparent")
        row2.pack(fill="x")

        ctk.CTkButton(row2, text="⏹ Cancel",
            font=("Arial", 11), fg_color=C["error"]+"33",
            hover_color=C["error"]+"55",
            border_width=1, border_color=C["error"]+"66",
            text_color=C["error"],
            height=36, corner_radius=10,
            command=self._cancel
        ).pack(side="left", fill="x", expand=True, padx=(0,5))

        ctk.CTkButton(row2, text="🗑️ Clear",
            font=("Arial", 11), fg_color=C["card2"],
            hover_color=C["card3"],
            border_width=1, border_color=C["border"],
            text_color=C["text2"],
            height=36, corner_radius=10,
            command=self._clear
        ).pack(side="left", fill="x", expand=True)

        # Agents card
        agents_card = NexusCard(left)
        agents_card.pack(fill="x", pady=(0,10))

        ctk.CTkLabel(agents_card, text="Agent Status",
            font=("Arial", 13, "bold"), text_color=C["white"]
        ).pack(anchor="w", padx=15, pady=(15,8))

        self.agent_cards = {}
        agent_data = [
            ("claude",     "Claude",     C["claude"],     "🗂️"),
            ("gpt",        "GPT-4o",     C["gpt"],        "💻"),
            ("grok",       "Grok",       C["grok"],       "🐛"),
            ("gemini",     "Gemini",     C["gemini"],     "🎨"),
            ("perplexity", "Perplexity", C["perplexity"], "🔍"),
            ("nexus_ai",   "Nexus AI",   C["nexus_ai"],   "⬡"),
        ]

        for key, name, color, icon in agent_data:
            card = AgentStatusCard(agents_card, key, name, color, icon)
            card.pack(fill="x", padx=10, pady=3)
            self.agent_cards[key] = card

        ctk.CTkFrame(agents_card, fg_color="transparent", height=10).pack()

        # RIGHT PANEL
        right = ctk.CTkFrame(body, fg_color="transparent")
        right.pack(side="right", fill="both", expand=True)

        tabs = ctk.CTkTabview(right, fg_color=C["card"],
                               corner_radius=12,
                               border_width=1, border_color=C["border"],
                               segmented_button_fg_color=C["card2"],
                               segmented_button_selected_color=C["accent"],
                               segmented_button_selected_hover_color=C["accent_hover"],
                               segmented_button_unselected_color=C["card2"],
                               segmented_button_unselected_hover_color=C["card3"])
        tabs.pack(fill="both", expand=True)

        # Live output tab
        live_tab = tabs.add("  📡 Live Output  ")
        self.live_log = LogConsole(live_tab)
        self.live_log.pack(fill="both", expand=True, padx=2, pady=2)

        # Final output tab
        final_tab = tabs.add("  ✅ Final Output  ")

        action_row = ctk.CTkFrame(final_tab, fg_color="transparent")
        action_row.pack(fill="x", padx=10, pady=8)

        for text, color, cmd in [
            ("📋 Copy", C["card2"], self._copy),
            ("💾 Save", C["card2"], self._save),
            ("📚 Library", C["accent"], self._library),
        ]:
            ctk.CTkButton(action_row, text=text,
                width=110, height=34, corner_radius=8,
                fg_color=color, hover_color=C["card3"],
                border_width=1, border_color=C["border"],
                font=("Arial", 11),
                command=cmd
            ).pack(side="left", padx=4)

        self.final_box = ctk.CTkTextbox(final_tab,
                                         font=("JetBrains Mono", 11),
                                         fg_color=C["bg"],
                                         corner_radius=8)
        self.final_box.pack(fill="both", expand=True, padx=8, pady=(0,8))

    def _scan(self):
        ctx = self.app.server_ctrl.scan(self.app.config.get("server_data",""))
        fw = ctx.get("framework","Unknown")
        n = ctx.get("resource_count",0)
        self.scan_label.configure(
            text=f"  {fw}  |  {n} resources  ",
            text_color=C["success"])
        self.scan_pill.configure(border_color=C["success"]+"66")
        self.app.server_context = ctx

    def _run(self):
        task = self.task_input.get("0.0","end").strip()
        if not task: return
        self._task = task
        self.live_log.clear()
        self.final_box.delete("0.0","end")
        for c in self.agent_cards.values(): c.set_idle()

        self.pipeline = Pipeline(
            api=self.app.api,
            server=self.app.server_ctrl,
            on_update=self._on_update,
            on_phase=self._on_phase,
            on_done=self._on_done,
            on_error=self._on_error
        )
        self.pipeline.run(task, getattr(self.app,"server_context",{}),
                          self.app.config.get("resources_path",""))

    def _cancel(self):
        if self.pipeline: self.pipeline.cancel()
        self.live_log.log("nexus","⏹ Cancelled\n")

    def _on_update(self, agent, text):
        def _do():
            self.live_log.log(agent, text)
            if agent in self.agent_cards:
                conf = self.app.api.confidence(text)
                if any(x in text for x in ["✅","done","complete","approved"]):
                    self.agent_cards[agent].set_done(conf)
                else:
                    self.agent_cards[agent].set_working(conf)
        self.after(0, _do)

    def _on_phase(self, name, num):
        self.after(0, lambda: self.app.topbar.set_phase(name, num))

    def _on_done(self, files, final):
        def _do():
            self._files = files
            self._final = final
            self.final_box.delete("0.0","end")
            self.final_box.insert("0.0", final)
            for c in self.agent_cards.values(): c.set_done()
        self.after(0, _do)

    def _on_error(self, msg):
        self.after(0, lambda: self.live_log.log("nexus", f"❌ {msg}\n"))

    def _copy(self):
        self.clipboard_clear()
        self.clipboard_append(self._final)

    def _save(self):
        p = filedialog.asksaveasfilename(defaultextension=".txt",
            filetypes=[("Text","*.txt"),("All","*.*")])
        if p:
            with open(p,"w",encoding="utf-8") as f: f.write(self._final)

    def _library(self):
        if not self._task: return
        lib = load_json(LIBRARY_FILE, [])
        lib.append({"task":self._task,"files":list(self._files.keys()),
                    "created":datetime.now().isoformat(),"output":self._final[:500]})
        save_json(LIBRARY_FILE, lib)
        self.live_log.log("nexus","📚 Saved to Resource Library\n")

    def _clear(self):
        self.live_log.clear()
        self.final_box.delete("0.0","end")
        self.task_input.delete("0.0","end")
        for c in self.agent_cards.values(): c.set_idle()
        self.app.topbar.set_phase("",0)


class ServerPanelPage(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=C["bg"])
        self.app = app
        self._build()

    def _build(self):
        hdr = ctk.CTkFrame(self, fg_color=C["card"], corner_radius=0,
                            border_width=1, border_color=C["border"])
        hdr.pack(fill="x")
        ctk.CTkLabel(hdr, text="⬡  SERVER PANEL",
            font=("Arial", 16, "bold"), text_color=C["white"]
        ).pack(side="left", padx=20, pady=14)

        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=15, pady=12)

        # Left controls
        left = ctk.CTkFrame(body, fg_color="transparent", width=280)
        left.pack(side="left", fill="y", padx=(0,10))
        left.pack_propagate(False)

        # Server status card
        status_card = NexusCard(left)
        status_card.pack(fill="x", pady=(0,10))

        ctk.CTkLabel(status_card, text="Server Status",
            font=("Arial", 13, "bold"), text_color=C["white"]
        ).pack(anchor="w", padx=15, pady=(15,10))

        self.status_frame = ctk.CTkFrame(status_card,
                                          fg_color=C["error"]+"11",
                                          corner_radius=10,
                                          border_width=1, border_color=C["error"]+"33")
        self.status_frame.pack(fill="x", padx=12, pady=(0,5))

        self.status_dot = ctk.CTkLabel(self.status_frame, text="●  OFFLINE",
            font=("Arial", 13, "bold"), text_color=C["error"])
        self.status_dot.pack(pady=10)

        btns = ctk.CTkFrame(status_card, fg_color="transparent")
        btns.pack(fill="x", padx=12, pady=(5,15))

        for text, color, hover, cmd in [
            ("▶  START",   C["success"],  "#059669", self._start),
            ("⏹  STOP",    C["error"],    "#dc2626", self._stop),
            ("🔄  RESTART", C["warning"], "#d97706", self._restart),
        ]:
            ctk.CTkButton(btns, text=text,
                font=("Arial", 12, "bold"),
                fg_color=color+"22", hover_color=color+"44",
                border_width=1, border_color=color+"66",
                text_color=color,
                height=40, corner_radius=10,
                command=cmd
            ).pack(fill="x", pady=3)

        # Backup card
        backup_card = NexusCard(left)
        backup_card.pack(fill="x", pady=(0,10))

        ctk.CTkLabel(backup_card, text="Backups",
            font=("Arial", 13, "bold"), text_color=C["white"]
        ).pack(anchor="w", padx=15, pady=(15,8))

        for text, cmd in [
            ("💾  Create Backup", self._backup),
            ("📂  Open Backup Folder", self._open_backups),
        ]:
            ctk.CTkButton(backup_card, text=text,
                font=("Arial", 11), fg_color=C["card2"],
                hover_color=C["card3"], border_width=1, border_color=C["border"],
                height=38, corner_radius=10, command=cmd
            ).pack(fill="x", padx=12, pady=3)

        ctk.CTkFrame(backup_card, fg_color="transparent", height=10).pack()

        # Quick actions
        quick_card = NexusCard(left)
        quick_card.pack(fill="x")

        ctk.CTkLabel(quick_card, text="Quick Actions",
            font=("Arial", 13, "bold"), text_color=C["white"]
        ).pack(anchor="w", padx=15, pady=(15,8))

        for text, cmd in [
            ("📝  Edit server.cfg", self._load_cfg),
            ("📁  Open Resources", self._open_res),
        ]:
            ctk.CTkButton(quick_card, text=text,
                font=("Arial", 11), fg_color=C["card2"],
                hover_color=C["card3"], border_width=1, border_color=C["border"],
                height=38, corner_radius=10, command=cmd
            ).pack(fill="x", padx=12, pady=3)

        ctk.CTkFrame(quick_card, fg_color="transparent", height=10).pack()

        # Right: cfg editor
        right = NexusCard(body)
        right.pack(side="right", fill="both", expand=True)

        r_hdr = ctk.CTkFrame(right, fg_color="transparent")
        r_hdr.pack(fill="x", padx=15, pady=(15,8))

        ctk.CTkLabel(r_hdr, text="server.cfg Editor",
            font=("Arial", 13, "bold"), text_color=C["white"]
        ).pack(side="left")

        for text, color, cmd in [
            ("📂 Load", C["card2"], self._load_cfg),
            ("💾 Save", C["accent"], self._save_cfg),
        ]:
            ctk.CTkButton(r_hdr, text=text,
                width=90, height=32, corner_radius=8,
                fg_color=color, hover_color=C["card3"],
                border_width=1, border_color=C["border"],
                font=("Arial", 11), command=cmd
            ).pack(side="right", padx=3)

        self.cfg_editor = ctk.CTkTextbox(right,
            font=("JetBrains Mono", 12), fg_color=C["bg"], corner_radius=8)
        self.cfg_editor.pack(fill="both", expand=True, padx=12, pady=(0,12))

    def _set_status(self, online):
        color = C["success"] if online else C["error"]
        text = "●  ONLINE" if online else "●  OFFLINE"
        self.status_dot.configure(text=text, text_color=color)
        self.status_frame.configure(fg_color=color+"11", border_color=color+"33")
        self.app.topbar.set_server(online)

    def _start(self): self.app.server_ctrl.start(); self._set_status(True)
    def _stop(self): self.app.server_ctrl.stop(); self._set_status(False)
    def _restart(self): self.app.server_ctrl.restart()
    def _backup(self): self.app.server_ctrl.backup(self.app.config.get("server_data",""))
    def _open_backups(self): Path("nexus_backups").mkdir(exist_ok=True); os.startfile("nexus_backups")
    def _open_res(self):
        p = self.app.config.get("resources_path","")
        if p and os.path.exists(p): os.startfile(p)

    def _load_cfg(self):
        p = os.path.join(self.app.config.get("server_data",""),"server.cfg")
        if os.path.exists(p):
            with open(p, encoding="utf-8", errors="ignore") as f: content = f.read()
            self.cfg_editor.delete("0.0","end")
            self.cfg_editor.insert("0.0", content)

    def _save_cfg(self):
        p = os.path.join(self.app.config.get("server_data",""),"server.cfg")
        if p:
            with open(p,"w",encoding="utf-8") as f: f.write(self.cfg_editor.get("0.0","end"))


class ConsolePage(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=C["bg"])
        self.app = app
        self._build()
        self.app.console_ref = self

    def _build(self):
        hdr = ctk.CTkFrame(self, fg_color=C["card"], corner_radius=0,
                            border_width=1, border_color=C["border"])
        hdr.pack(fill="x")

        hdr_i = ctk.CTkFrame(hdr, fg_color="transparent")
        hdr_i.pack(fill="x", padx=20, pady=12)

        ctk.CTkLabel(hdr_i, text="⬡  LIVE CONSOLE",
            font=("Arial", 16, "bold"), text_color=C["white"]
        ).pack(side="left")

        for text, color, cmd in [
            ("⚡ Fix All Errors", C["warning"], self._fix_errors),
            ("🗑️ Clear", C["card2"], self._clear),
        ]:
            ctk.CTkButton(hdr_i, text=text,
                width=130, height=34, corner_radius=10,
                fg_color=color+"22" if color != C["card2"] else color,
                hover_color=C["card3"],
                border_width=1, border_color=color+"55" if color != C["card2"] else C["border"],
                text_color=color if color != C["card2"] else C["text2"],
                font=("Arial", 11), command=cmd
            ).pack(side="right", padx=4, pady=0)

        self.console = LogConsole(self, wrap="word")
        self.console.pack(fill="both", expand=True, padx=10, pady=10)

    def append(self, agent, text):
        self.console.log(agent, text)

    def _clear(self): self.console.clear()

    def _fix_errors(self):
        content = self.console.get("0.0","end")
        errors = [l for l in content.split("\n") if "error" in l.lower()]
        if not errors: self.console.log("nexus","✅ No errors detected\n"); return
        err_txt = "\n".join(errors[:10])
        self.console.log("nexus",f"⚡ Sending {len(errors)} errors to debug team...\n")
        def _fix():
            fix = self.app.api.ask_claude(f"Fix these FiveM errors:\n{err_txt}", system=DEBUGGER_SYSTEM)
            self.after(0, lambda: self.console.log("claude", fix+"\n"))
        threading.Thread(target=_fix, daemon=True).start()


class FileManagerPage(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=C["bg"])
        self.app = app
        self.current_file = None
        self._build()

    def _build(self):
        hdr = ctk.CTkFrame(self, fg_color=C["card"], corner_radius=0,
                            border_width=1, border_color=C["border"])
        hdr.pack(fill="x")

        hdr_i = ctk.CTkFrame(hdr, fg_color="transparent")
        hdr_i.pack(fill="x", padx=20, pady=12)

        ctk.CTkLabel(hdr_i, text="⬡  FILE MANAGER",
            font=("Arial", 16, "bold"), text_color=C["white"]
        ).pack(side="left")

        ctk.CTkButton(hdr_i, text="🔄 Refresh",
            width=100, height=34, corner_radius=10,
            fg_color=C["card2"], hover_color=C["card3"],
            border_width=1, border_color=C["border"],
            font=("Arial", 11), command=self._refresh
        ).pack(side="right")

        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=15, pady=12)

        # File tree
        tree_card = NexusCard(body)
        tree_card.configure(width=280)
        tree_card.pack(side="left", fill="y", padx=(0,10))
        tree_card.pack_propagate(False)

        ctk.CTkLabel(tree_card, text="Resources",
            font=("Arial", 13, "bold"), text_color=C["white"]
        ).pack(anchor="w", padx=15, pady=(15,8))

        self.tree = ctk.CTkScrollableFrame(tree_card, fg_color="transparent")
        self.tree.pack(fill="both", expand=True, padx=5, pady=(0,10))

        # Editor
        editor_card = NexusCard(body)
        editor_card.pack(side="right", fill="both", expand=True)

        e_hdr = ctk.CTkFrame(editor_card, fg_color="transparent")
        e_hdr.pack(fill="x", padx=15, pady=(15,8))

        self.file_label = ctk.CTkLabel(e_hdr,
            text="Select a file to edit",
            font=("Arial", 12), text_color=C["text2"])
        self.file_label.pack(side="left")

        for text, color, cmd in [
            ("🤖 AI Fix", C["card2"], self._ai_fix),
            ("💾 Save", C["accent"], self._save_file),
        ]:
            ctk.CTkButton(e_hdr, text=text,
                width=100, height=32, corner_radius=8,
                fg_color=color, hover_color=C["card3"],
                border_width=1, border_color=C["border"],
                font=("Arial", 11), command=cmd
            ).pack(side="right", padx=3)

        self.editor = ctk.CTkTextbox(editor_card,
            font=("JetBrains Mono", 12), fg_color=C["bg"], corner_radius=8)
        self.editor.pack(fill="both", expand=True, padx=12, pady=(0,12))

        self._refresh()

    def _refresh(self):
        for w in self.tree.winfo_children(): w.destroy()
        res_path = self.app.config.get("resources_path","")
        if not res_path or not os.path.exists(res_path):
            ctk.CTkLabel(self.tree,
                text="No server path set\nGo to Setup ⚙️",
                font=("Arial", 12), text_color=C["text3"]
            ).pack(pady=30)
            return
        for item in sorted(Path(res_path).iterdir()):
            if item.is_dir():
                folder_btn = ctk.CTkButton(self.tree,
                    text=f"📁  {item.name}",
                    anchor="w", height=32, corner_radius=8,
                    fg_color="transparent", hover_color=C["card2"],
                    text_color=C["text"], font=("Arial", 11),
                    command=lambda p=item: self._expand(p)
                )
                folder_btn.pack(fill="x", pady=1)

    def _expand(self, path):
        exts = ["*.lua","*.html","*.js","*.json","*.cfg","*.sql"]
        for ext in exts:
            for file in sorted(path.rglob(ext)):
                ctk.CTkButton(self.tree,
                    text=f"    📄  {file.name}",
                    anchor="w", height=28, corner_radius=6,
                    fg_color="transparent", hover_color=C["card2"],
                    text_color=C["text2"], font=("Arial", 10),
                    command=lambda p=file: self._open(p)
                ).pack(fill="x", pady=1)

    def _open(self, path):
        self.current_file = path
        self.file_label.configure(text=str(path.name), text_color=C["accent2"])
        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
            self.editor.delete("0.0","end")
            self.editor.insert("0.0", content)
        except Exception as e:
            self.editor.delete("0.0","end")
            self.editor.insert("0.0", f"Error: {e}")

    def _save_file(self):
        if not self.current_file: return
        with open(self.current_file,"w",encoding="utf-8") as f:
            f.write(self.editor.get("0.0","end"))

    def _ai_fix(self):
        if not self.current_file: return
        content = self.editor.get("0.0","end")
        def _fix():
            fixed = self.app.api.ask_claude(
                f"Fix all bugs in this file ({self.current_file.name}):\n{content}",
                system=DEBUGGER_SYSTEM)
            def _apply():
                self.editor.delete("0.0","end")
                self.editor.insert("0.0", fixed)
            self.after(0, _apply)
        threading.Thread(target=_fix, daemon=True).start()


class LibraryPage(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=C["bg"])
        self.app = app
        self._build()

    def _build(self):
        hdr = ctk.CTkFrame(self, fg_color=C["card"], corner_radius=0,
                            border_width=1, border_color=C["border"])
        hdr.pack(fill="x")

        hdr_i = ctk.CTkFrame(hdr, fg_color="transparent")
        hdr_i.pack(fill="x", padx=20, pady=12)

        ctk.CTkLabel(hdr_i, text="⬡  RESOURCE LIBRARY",
            font=("Arial", 16, "bold"), text_color=C["white"]
        ).pack(side="left")

        ctk.CTkButton(hdr_i, text="🔄 Refresh",
            width=100, height=34, corner_radius=10,
            fg_color=C["card2"], hover_color=C["card3"],
            border_width=1, border_color=C["border"],
            font=("Arial", 11), command=self._load
        ).pack(side="right")

        self.scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.scroll.pack(fill="both", expand=True, padx=15, pady=12)
        self._load()

    def _load(self):
        for w in self.scroll.winfo_children(): w.destroy()
        lib = load_json(LIBRARY_FILE, [])
        if not lib:
            empty = NexusCard(self.scroll)
            empty.pack(fill="x", pady=20, padx=20)
            ctk.CTkLabel(empty,
                text="📚\n\nNo saved resources yet\nBuild something in Nexus AI Core first!",
                font=("Arial", 14), text_color=C["text2"], justify="center"
            ).pack(pady=40)
            return

        for entry in reversed(lib):
            card = NexusCard(self.scroll)
            card.pack(fill="x", pady=5)

            top = ctk.CTkFrame(card, fg_color="transparent")
            top.pack(fill="x", padx=18, pady=(15,5))

            ctk.CTkLabel(top,
                text=entry.get("task","Unknown")[:70],
                font=("Arial", 13, "bold"), text_color=C["accent2"]
            ).pack(side="left")

            ctk.CTkLabel(top,
                text=entry.get("created","")[:10],
                font=("Arial", 11), text_color=C["text3"]
            ).pack(side="right")

            files_frame = ctk.CTkFrame(card, fg_color="transparent")
            files_frame.pack(fill="x", padx=15, pady=(0,15))

            for f in entry.get("files",[]):
                pill = ctk.CTkFrame(files_frame, fg_color=C["card2"],
                                     corner_radius=8, border_width=1,
                                     border_color=C["border"])
                pill.pack(side="left", padx=3)
                ctk.CTkLabel(pill, text=f"📄 {f}",
                    font=("Arial", 10), text_color=C["text2"]
                ).pack(padx=8, pady=4)


class SetupPage(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color=C["bg"])
        self.app = app
        self.entries = {}
        self._build()

    def _build(self):
        hdr = ctk.CTkFrame(self, fg_color=C["card"], corner_radius=0,
                            border_width=1, border_color=C["border"])
        hdr.pack(fill="x")
        ctk.CTkLabel(hdr, text="⬡  SETUP",
            font=("Arial", 16, "bold"), text_color=C["white"]
        ).pack(side="left", padx=20, pady=14)

        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=40, pady=20)

        # API Keys
        SectionLabel(scroll, "  API KEYS").pack(anchor="w", pady=(10,8))

        api_keys = [
            ("claude",     "Claude (Anthropic)", C["claude"],     "console.anthropic.com"),
            ("openai",     "GPT-4o (OpenAI)",    C["gpt"],        "platform.openai.com"),
            ("grok",       "Grok (xAI)",         C["grok"],       "console.x.ai"),
            ("gemini",     "Gemini (Google)",    C["gemini"],     "aistudio.google.com"),
            ("perplexity", "Perplexity",         C["perplexity"], "perplexity.ai/settings/api"),
        ]

        keys = load_json(KEYS_FILE, {})
        for key, label, color, hint in api_keys:
            card = NexusCard(scroll)
            card.pack(fill="x", pady=4)

            inner = ctk.CTkFrame(card, fg_color="transparent")
            inner.pack(fill="x", padx=18, pady=14)

            left = ctk.CTkFrame(inner, fg_color="transparent")
            left.pack(side="left", fill="y")

            dot = ctk.CTkFrame(left, width=10, height=10,
                                corner_radius=5, fg_color=color)
            dot.pack(pady=8)

            right_side = ctk.CTkFrame(inner, fg_color="transparent")
            right_side.pack(side="left", fill="both", expand=True, padx=12)

            top_row = ctk.CTkFrame(right_side, fg_color="transparent")
            top_row.pack(fill="x")

            ctk.CTkLabel(top_row, text=label,
                font=("Arial", 12, "bold"), text_color=color
            ).pack(side="left")

            ctk.CTkLabel(top_row, text=f"  →  {hint}",
                font=("Arial", 10), text_color=C["text3"]
            ).pack(side="left")

            e = ctk.CTkEntry(right_side,
                placeholder_text="Paste API key here...",
                show="*", height=36, corner_radius=8,
                fg_color=C["bg2"], border_width=1, border_color=C["border"],
                font=("Arial", 12))
            e.pack(fill="x", pady=(6,0))
            if key in keys: e.insert(0, keys[key])
            self.entries[key] = e

        # Paths
        SectionLabel(scroll, "  SERVER PATHS").pack(anchor="w", pady=(20,8))

        cfg = load_json(CONFIG_FILE, {})
        paths = [
            ("fxserver_exe",   "FXServer.exe",      "Full path to FXServer.exe"),
            ("server_data",    "Server Data Folder", "Folder containing server.cfg"),
            ("resources_path", "Resources Folder",   "Your resources directory"),
        ]

        for key, label, hint in paths:
            card = NexusCard(scroll)
            card.pack(fill="x", pady=4)

            inner = ctk.CTkFrame(card, fg_color="transparent")
            inner.pack(fill="x", padx=18, pady=14)

            ctk.CTkLabel(inner, text=label,
                font=("Arial", 12, "bold"), text_color=C["white"]
            ).pack(anchor="w")
            ctk.CTkLabel(inner, text=hint,
                font=("Arial", 10), text_color=C["text3"]
            ).pack(anchor="w")

            row = ctk.CTkFrame(inner, fg_color="transparent")
            row.pack(fill="x", pady=(6,0))

            e = ctk.CTkEntry(row, placeholder_text="Enter path...",
                height=36, corner_radius=8,
                fg_color=C["bg2"], border_width=1, border_color=C["border"],
                font=("Arial", 12))
            e.pack(side="left", fill="x", expand=True)
            if key in cfg: e.insert(0, cfg[key])
            self.entries[key] = e

            ctk.CTkButton(row, text="Browse",
                width=90, height=36, corner_radius=8,
                fg_color=C["card2"], hover_color=C["card3"],
                border_width=1, border_color=C["border"],
                font=("Arial", 11),
                command=lambda k=key, en=e: self._browse(k, en)
            ).pack(side="left", padx=(6,0))

        # Save button
        save_btn = ctk.CTkButton(scroll,
            text="💾  SAVE ALL SETTINGS",
            font=("Arial", 14, "bold"),
            fg_color=C["accent"], hover_color=C["accent_hover"],
            height=52, corner_radius=14,
            command=self._save
        )
        save_btn.pack(fill="x", pady=20)

        self.status_label = ctk.CTkLabel(scroll, text="",
            font=("Arial", 12), text_color=C["success"])
        self.status_label.pack()

    def _browse(self, key, entry):
        path = (filedialog.askopenfilename(filetypes=[("EXE","*.exe"),("All","*.*")])
                if "exe" in key else filedialog.askdirectory())
        if path: entry.delete(0,"end"); entry.insert(0, path)

    def _save(self):
        key_names = {"claude","openai","grok","gemini","perplexity"}
        cfg_names = {"fxserver_exe","server_data","resources_path"}
        keys, cfg = {}, {}
        for k, e in self.entries.items():
            v = e.get().strip()
            if k in key_names: keys[k] = v
            elif k in cfg_names: cfg[k] = v
        save_json(KEYS_FILE, keys)
        save_json(CONFIG_FILE, cfg)
        self.app.keys = keys
        self.app.config = cfg
        self.app.api = NexusAPI(keys)
        self.app.server_ctrl = ServerCtrl(
            cfg.get("fxserver_exe",""), cfg.get("server_data",""),
            self.app._console_out)
        self.status_label.configure(text="✅  Settings saved and applied!")


# ══════════════════════════════════════════════════════
#  MAIN APP
# ══════════════════════════════════════════════════════

class NexusSuite(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("⬡ NEXUS SUITE — FiveM AI Dev Platform")
        self.geometry("1500x900")
        self.minsize(1200,720)
        self.configure(fg_color=C["bg"])

        self.keys = load_json(KEYS_FILE, {})
        self.config = load_json(CONFIG_FILE, {})
        self.server_context = {}
        self.console_ref = None

        self.api = NexusAPI(self.keys)
        self.server_ctrl = ServerCtrl(
            self.config.get("fxserver_exe",""),
            self.config.get("server_data",""),
            self._console_out
        )

        self.pages = {}
        self.current_page = None
        self._build()
        self.sidebar.set_active("home")

    def _build(self):
        self.topbar = TopBar(self)
        self.topbar.pack(fill="x", side="top")

        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True)

        self.sidebar = Sidebar(body, on_nav=self.navigate)
        self.sidebar.pack(side="left", fill="y")

        self.content = ctk.CTkFrame(body, fg_color=C["bg"], corner_radius=0)
        self.content.pack(side="right", fill="both", expand=True)

        self.pages = {
            "home":    HomePage(self.content, self),
            "ai":      AICorePage(self.content, self),
            "panel":   ServerPanelPage(self.content, self),
            "console": ConsolePage(self.content, self),
            "files":   FileManagerPage(self.content, self),
            "library": LibraryPage(self.content, self),
            "setup":   SetupPage(self.content, self),
        }

    def navigate(self, key):
        if self.current_page: self.pages[self.current_page].pack_forget()
        self.pages[key].pack(fill="both", expand=True)
        self.current_page = key

    def _console_out(self, agent, text):
        def _do():
            if self.console_ref: self.console_ref.append(agent, text)
        self.after(0, _do)

if __name__ == "__main__":
    app = NexusSuite()
    app.mainloop()
