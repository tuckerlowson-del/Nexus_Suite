@echo off
title NEXUS SUITE — Auto Setup
color 0A

echo.
echo  ==========================================
echo   NEXUS SUITE — Full Auto Setup
echo  ==========================================
echo.

:: ── CHECK AND AUTO INSTALL PYTHON ─────────────────
echo [1/4] Checking for Python...
python --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    python3 --version >nul 2>&1
    IF %ERRORLEVEL% NEQ 0 (
        echo [!] Python not found — downloading and installing automatically...
        echo     Please wait, this may take a few minutes...
        echo.

        :: Download Python installer using PowerShell
        powershell -Command "& {Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe' -OutFile 'python_installer.exe'}"

        IF NOT EXIST python_installer.exe (
            echo [ERROR] Could not download Python installer.
            echo         Check your internet connection and try again.
            pause
            exit /b 1
        )

        echo [!] Installing Python silently with PATH enabled...
        python_installer.exe /quiet InstallAllUsers=1 PrependPath=1 Include_test=0

        :: Wait for install to finish
        timeout /t 10 /nobreak >nul

        :: Clean up installer
        del python_installer.exe >nul 2>&1

        :: Refresh PATH in current session
        call refreshenv >nul 2>&1

        :: Try again
        python --version >nul 2>&1
        IF %ERRORLEVEL% NEQ 0 (
            echo.
            echo [!] Python installed but PATH not refreshed yet.
            echo     Relaunching setup to apply changes...
            echo.
            :: Relaunch this bat file in a new CMD with updated PATH
            start "" /wait cmd /c "%~f0"
            exit /b
        )

        echo [OK] Python installed successfully.
    ) ELSE (
        set PYTHON=python3
        echo [OK] Python3 found.
    )
) ELSE (
    set PYTHON=python
    echo [OK] Python found.
)

:: Set PYTHON var if not already set
IF NOT DEFINED PYTHON (
    python --version >nul 2>&1
    IF %ERRORLEVEL% EQU 0 ( set PYTHON=python ) ELSE ( set PYTHON=python3 )
)

:: ── CHECK PIP ─────────────────────────────────────
echo.
echo [2/4] Checking pip...
%PYTHON% -m pip --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [!] pip not found — installing pip...
    %PYTHON% -m ensurepip --upgrade >nul 2>&1
    %PYTHON% -m pip install --upgrade pip >nul 2>&1
)
echo [OK] pip ready.

:: ── CHECK AND INSTALL LIBRARIES ───────────────────
echo.
echo [3/4] Checking required libraries...
echo.

%PYTHON% -c "import customtkinter" >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [!] customtkinter not found — installing...
    %PYTHON% -m pip install customtkinter
) ELSE (
    echo [OK] customtkinter already installed.
)

%PYTHON% -c "import anthropic" >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [!] anthropic not found — installing...
    %PYTHON% -m pip install anthropic
) ELSE (
    echo [OK] anthropic already installed.
)

%PYTHON% -c "import openai" >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [!] openai not found — installing...
    %PYTHON% -m pip install openai
) ELSE (
    echo [OK] openai already installed.
)

%PYTHON% -c "import PyInstaller" >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [!] pyinstaller not found — installing...
    %PYTHON% -m pip install pyinstaller
) ELSE (
    echo [OK] pyinstaller already installed.
)

:: ── LAUNCH APP ────────────────────────────────────
echo.
echo [4/4] All dependencies ready — launching NEXUS SUITE...
echo.
echo  ==========================================
echo   NEXUS SUITE is starting...
echo   Run build.bat to create a standalone EXE
echo  ==========================================
echo.
%PYTHON% main.py

IF %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] App crashed — Error code: %ERRORLEVEL%
    echo         Screenshot this window and send it for help.
    echo.
    pause
)
